# Çelişki testi (inanç güncelleme) · 11 Kas · N=10 · çatal 107

Çatal: ajanın 'git X' dediği ilk 3 kararda gözlemden X komsular'dan silinir, "uyari": "yol yok" eklenir. Ollama kayıt ayarı. Ölçü: plan değişimi (git X dışı), açıklamada çelişkiye değinme (yol/kapı/kapalı/değiş/başka; ASCII katlama).

| sınıf | vaka | çağrı | plan değişimi | değinme | değinme (plan değişince) |
|---|---|---|---|---|---|
| U | 17 | 460 | 0.571 | 0.260 | 0.222 |
| G | 21 | 610 | 0.835 | 0.205 | 0.212 |

Yargıçsız AUC (U yönü düşük): plan değişimi 0.831 · değinme 0.475 · taban (karar sayısı) .525
Eşleşmeli 12 çift: U plan değişimi < G oranı 0.792 · U değinme < G oranı 0.583

Süre 0 sn. Program RMS: çelişki testi (Hikayeci, gece 11 Kas).

## Ek · kart kırılımı (iş 12, çağrısız)

| kart | vaka | git X'siz vaka | çelişki vakası | plan değişimi (vaka ort) | entropi medyanı (vaka medyanlarının medyanı) |
|---|---|---|---|---|---|
| G1 | 6 | 2 | 4 | 0.950 | 0.241 |
| G2 | 8 | 3 | 5 | 0.827 | 0.240 |
| G3 | 16 | 4 | 12 | 0.800 | 0.170 |
| U1 | 12 | 5 | 7 | 0.602 | 0.109 |
| U2 | 6 | 3 | 3 | 0.383 | 0.136 |
| U3 | 7 | 5 | 2 | 0.650 | 0.051 |
| U4 | 5 | 0 | 5 | 0.607 | 0.161 |

U1 dışı U'lar (U2/U3/U4) plan değişimi ort 0.548 (vaka 10) · G ort 0.835 (vaka 21) · AUC (düşük → U) 0.843

# Koşu düzeyi ışınım defteri · 60 vaka · 1413 karar (ölçülmeyen 3)

| ölçü | U medyan | G medyan | AUC (U) | %95 | taban (karar sayısı) |
|---|---|---|---|---|---|
| entropi_medyan (dusuk -> U) | 0.13005 | 0.19445 | 0.694 | (0.562, 0.828) | 0.525 |
| entropi_ort (dusuk -> U) | 0.28277 | 0.38156 | 0.71 | (0.563, 0.832) | 0.525 |
| entropi_en_az (dusuk -> U) | 0.00968 | 0.00522 | 0.457 | (0.31, 0.611) | 0.525 |
| logp_ort (yuksek -> U) | -0.56282 | -0.58018 | 0.509 | (0.363, 0.656) | 0.525 |
| p_ort (yuksek -> U) | 0.82801 | 0.7806 | 0.609 | (0.456, 0.752) | 0.525 |

Eşleşmeli çift (30): U entropi medyanı < G oranı 0.700

Eylem eşlemeli (vaka içi o eylemdeki kararların entropi medyanı):

| eylem | vaka U/G | U medyan | G medyan | AUC (U) | %95 | karar payı U/G |
|---|---|---|---|---|---|---|
| bekle | 23/18 | 0.07778 | 0.17135 | 0.599 | (0.406, 0.79) | 0.711/0.508 |
| git | 17/21 | 0.1701 | 0.47133 | 0.7 | (0.521, 0.86) | 0.123/0.243 |
| diger | 14/19 | 0.1245 | 0.12405 | 0.455 | (0.259, 0.662) | 0.166/0.249 |

Duyarlılık (etkin n, yinelenen G çıkarıldı): {"cikarilan_G": 2, "U": 30, "G": 28, "auc_entropi_medyan": 0.69, "bootstrap_95": [0.549, 0.814], "cift_n": 28, "cift_U_kucuk_G_orani": 0.714}

Doğrusal sonda: {"yontem": "karar duzeyi L2 lojistik (lam 1, 300 adim, sinif dengeli), kat = cift (5 kat, tohum 10), vaka puani = ort olasilik", "karar_ornegi": 1410, "auc_vaka": 0.996, "bootstrap_95": [0.982, 1.0]}

Önkayıt: {"U_entropi_medyani_kucuk": true, "cift_orani_buyuk_.5": true, "auc_buyuk_.525": true}

# coding: utf-8
"""TARAMA DENETIMLERI · 11 Kas · Hikayeci (danisman is emri, epistemics/TARAMA_11kas.md). HEPSI EK (onkayit disi), mevcut veri, CPU, 0 $, yeni kosu yok.
T1 celiski ayni kart tek fark hedef (I1 U1 vs G4 + iki yan satir) · T2 celiski butun olcumler + birlesik tahmin · T3 celiski vs karar sayisi (aktarim, ikiz I2)
T4 entropi konum etkisi (tasiyici) · T5 (#6 bitince) ayni 98 vakada k-NN - yargic eslesmeli bootstrap AUC farki.
Cikti epistemik/tarama_11kas.{json,md}
  python -I epistemik/tarama_11kas.py            (T1-T4; #6 cagri.jsonl varsa T5 de)"""
import collections, importlib.util, json, math, os, random, statistics, sys

EP = os.path.dirname(os.path.abspath(__file__)); IK = os.path.join(EP, "ikiz_kart"); AK = os.path.join(EP, "aktarim")
EPS = os.path.join(os.path.dirname(os.path.dirname(EP)), "epistemics")
_s = importlib.util.spec_from_file_location("y", os.path.join(EP, "yargic_k1.py")); y = importlib.util.module_from_spec(_s); _s.loader.exec_module(y)
TOHUM = list(range(16, 31)); B = 1000


def jl(p):
    return [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()]


def med(x):
    x = [v for v in x if v is not None]; return statistics.median(x) if x else None


def ort(x):
    x = [v for v in x if v is not None]; return sum(x) / len(x) if x else None


def auc(P, Q):
    """P'nin Q'dan BUYUK olma olasiligi"""
    P = [p for p in P if p is not None]; Q = [q for q in Q if q is not None]
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q)) if P and Q else None


def ara(v):
    v = sorted(x for x in v if x is not None); return [v[int(.025 * len(v))], v[min(len(v) - 1, int(.975 * len(v)))]] if len(v) >= 100 else None


def kume_bs(kumeler, f, rr):
    """kumeler: {kume: [(sinif, deger)]}; kume yeniden ornekleme; f(U, G) -> sayi"""
    ks = list(kumeler); out = []
    for _ in range(B):
        o = [kumeler[rr.choice(ks)] for _ in ks]; U = [d for k in o for s, d in k if s == "U"]; G = [d for k in o for s, d in k if s == "G"]
        out.append(f(U, G) if U and G else None)
    return ara(out)


def spearman(a, b):
    def rank(x):
        o = sorted(range(len(x)), key=lambda i: x[i]); r = [0.0] * len(x); i = 0
        while i < len(o):
            j = i
            while j + 1 < len(o) and x[o[j + 1]] == x[o[i]]:
                j += 1
            for k in range(i, j + 1):
                r[o[k]] = (i + j) / 2 + 1
            i = j + 1
        return r
    if len(a) < 3:
        return None
    ra, rb = rank(a), rank(b); ma, mb = statistics.mean(ra), statistics.mean(rb)
    sa = math.sqrt(sum((x - ma) ** 2 for x in ra)); sb = math.sqrt(sum((x - mb) ** 2 for x in rb))
    return None if not sa or not sb else sum((x - ma) * (z - mb) for x, z in zip(ra, rb)) / (sa * sb)


def lojistik(X, y_, Xt, lam=1.0, adim=500, h=.1):
    m = [statistics.mean(c) for c in zip(*X)]; s = [statistics.pstdev(c) or 1 for c in zip(*X)]
    z = lambda r: [1.0] + [(v - mu) / sd for v, mu, sd in zip(r, m, s)]
    Z = [z(r) for r in X]; w = [0.0] * len(Z[0]); n = len(Z)
    for _ in range(adim):
        g = [0.0] * len(w)
        for zi, yi in zip(Z, y_):
            p = 1 / (1 + math.exp(-sum(a * b for a, b in zip(w, zi))))
            for j in range(len(w)):
                g[j] += (p - yi) * zi[j]
        w = [wj - h * (gj / n + (lam * wj / n if j else 0)) for j, (wj, gj) in enumerate(zip(w, g))]
    return [1 / (1 + math.exp(-sum(a * b for a, b in zip(w, z(r))))) for r in Xt]


def loto(V, ozel, model):
    """tohum disarida birak; V: [{tohum, sinif, ...}] -> p(U)"""
    out = {}
    for t in sorted({v["tohum"] for v in V}):
        tr = [v for v in V if v["tohum"] != t]; te = [v for v in V if v["tohum"] == t]
        X = [ozel(v) for v in tr]; yy = [1.0 if v["sinif"] == "U" else 0.0 for v in tr]
        if model == "lojistik":
            P = lojistik(X, yy, [ozel(v) for v in te])
        else:
            m = [statistics.mean(c) for c in zip(*X)]; s = [statistics.pstdev(c) or 1 for c in zip(*X)]
            zz = lambda r: [(a - mu) / sd for a, mu, sd in zip(r, m, s)]; Zt = [zz(r) for r in X]
            P = [sum(u for _, u in sorted((math.dist(zz(ozel(v)), Zt[j]), yy[j]) for j in range(len(tr)))[:5]) / 5 for v in te]
        for v, p in zip(te, P):
            out[id(v)] = p
    return auc([out[id(v)] for v in V if v["sinif"] == "U"], [out[id(v)] for v in V if v["sinif"] == "G"])


# ------------------------------------------------------------------ veri
def ikiz():
    V = {v["i"]: v for v in jl(os.path.join(IK, "vakalar_ikiz.jsonl"))}; C = collections.defaultdict(list); A = collections.defaultdict(set)
    for r in jl(os.path.join(IK, "olcum_celiski_ikiz.jsonl")):
        C[r["vaka"]].append(r["plan_degisti"]); A[r["vaka"]].add(r["adim"])
    E = {r["i"]: r for r in jl(os.path.join(IK, "olcum_isinim_ikiz.jsonl"))}
    for i, v in V.items():
        v["C_plan"] = ort(C.get(i, [])); v["catal"] = len(A.get(i, ())); v["E"] = E.get(i, {}).get("kararlar", []); v["_kok"] = IK
    return V


def aktarim():
    V = {v["i"]: v for v in jl(os.path.join(AK, "vakalar_aktarim.jsonl")) if v.get("ajan")}; C = collections.defaultdict(list); A = collections.defaultdict(set)
    for r in jl(os.path.join(AK, "olcum_celiski_aktarim.jsonl")):
        C[r["vaka"]].append(r["plan_degisti"]); A[r["vaka"]].add(r["adim"])
    E = {r["i"]: r for r in jl(os.path.join(AK, "olcum_isinim_aktarim.jsonl"))}
    for i, v in V.items():
        v["C_plan"] = ort(C.get(i, [])); v["catal"] = len(A.get(i, ())); v["E"] = E.get(i, {}).get("kararlar", []); v["grup"] = v["kol"]; v["_kok"] = AK
    return V


def istemler(v):
    p = os.path.join(v["_kok"], "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl")
    if not os.path.exists(p):                    # donuk vakalar: ana oynat/ klasoru
        p = os.path.join(EP, "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl")
    return sorted((d for d in jl(p) if d["ajan"] == v["ajan"] and d["cagri"] == 0), key=lambda d: d["kayit_adim"])


def rol(v):
    for d in istemler(v):
        g = y.gozlem(d) or {}
        if "rol" in g:
            return g["rol"]
    return None


def ent(v, f=lambda k: True):
    return med([k["entropi_ust20_nat"] for k in v["E"] if "entropi_ust20_nat" in k and f(k)])


# ------------------------------------------------------------------ T1
def t1(V, rr):
    bul = lambda g, s, t: next((v for v in V.values() if v["grup"] == g and v["sinif"] == s and v["tohum"] == t), None)
    R = {}
    for ad, x, z in (("I1 U1 vs I1 G4 (ayni kosu, ikisi U1 metni; tek fark hedef)", ("I1", "U"), ("I1", "G")),
                     ("I1 U1 vs K0 G (U1 metni+hedef vs G metni)", ("I1", "U"), ("K0", "G")),
                     ("I2 U5 vs I1 G4 (G3 metni+hedef vs U1 metni hedefsiz)", ("I2", "U"), ("I1", "G"))):
        cift = [(bul(*x, t), bul(*z, t), t) for t in TOHUM]; cift = [(a, b, t) for a, b, t in cift if a and b and a["C_plan"] is not None and b["C_plan"] is not None]
        P = [-a["C_plan"] for a, b, t in cift]; Q = [-b["C_plan"] for a, b, t in cift]
        bs = [auc([-c[0]["C_plan"] for c in o], [-c[1]["C_plan"] for c in o]) for o in ([rr.choice(cift) for _ in cift] for _ in range(B))] if cift else []
        tek = auc(list({a["istem_sha"]: -a["C_plan"] for a, b, t in cift}.values()), list({b["istem_sha"]: -b["C_plan"] for a, b, t in cift}.values()))
        ux = [v["C_plan"] for v in V.values() if (v["grup"], v["sinif"]) == x and v["C_plan"] is not None]
        uz = [v["C_plan"] for v in V.values() if (v["grup"], v["sinif"]) == z and v["C_plan"] is not None]
        R[ad] = {"auc_x_dusuk_eslesmeli_kume": auc(P, Q), "ara": ara(bs), "n_cift": len(cift),
                 "eslesmeli_yon_orani": ort([1.0 if a["C_plan"] < b["C_plan"] else .5 if a["C_plan"] == b["C_plan"] else 0.0 for a, b, t in cift]),
                 "auc_tekil_istem": tek, "auc_tum_vakalar": auc([-u for u in ux], [-u for u in uz]), "n_tum": [len(ux), len(uz)],
                 "C_plan_ort_x": ort(ux), "C_plan_ort_z": ort(uz)}
    return R


# ------------------------------------------------------------------ T2
def t2(VI, VA, rr):
    G = {}; CL = collections.defaultdict(list)
    for r in jl(os.path.join(EP, "olcum_celiski_11kas.jsonl")):
        CL[(r["vaka"], r["sinif"], r["cift"])].append(r["plan_degisti"])
    don = [(s, c, ort(v)) for (i, s, c), v in CL.items()]
    kd = collections.defaultdict(list)
    for s, c, p in don:
        kd[c].append((s, -p))
    f = lambda U, G_: auc(U, G_)
    G["donuk gece (60 vakadan çatallı 38; küme = koşu çifti)"] = {"auc": auc([-p for s, c, p in don if s == "U"], [-p for s, c, p in don if s == "G"]),
                                                                  "ara": kume_bs(kd, f, rr), "n": [sum(1 for d in don if d[0] == "U"), sum(1 for d in don if d[0] == "G")]}
    J = json.load(open(os.path.join(IK, "olcum_ikiz_11kas.json"), encoding="utf-8"))["karsilastirma"]
    for k, ad in (("R1d", "R1d · donuk U1 vs donuk G (ikiz oturumunda yeniden, EK)"), ("R1", "R1 · K0 U1 vs K0 G (taze taban)"), ("C1", "C1 · I2 U5 vs I2 G (kart eşit)"),
                  ("C2", "C2 · I1 G4 vs K0 G")):
        s = J[k]["C_plan"]; G[ad] = {"auc": s["auc"], "ara": s["ara"], "n": s["n"], "not": "olcum_ikiz_11kas.json (tohum eşleşmeli bootstrap)"}
    JA = json.load(open(os.path.join(AK, "olcum_aktarim_11kas.json"), encoding="utf-8"))["olcu"]["C_plan"]
    G["aktarım · AU U1 vs AG G (tohum çifti)"] = {"auc": JA["auc_U_dusuk"], "ara": JA["ara"], "n": JA["n_cift"], "not": "olcum_aktarim_11kas.json"}
    # birlesik: uc bagimsiz kume (donuk gece, ikiz K0, aktarim), katmanli AUC = sum w_s AUC_s, w = nU*nG
    kik = collections.defaultdict(list)
    for v in VI.values():
        if v["grup"] == "K0" and v["C_plan"] is not None:
            kik[v["tohum"]].append((v["sinif"], -v["C_plan"]))
    kak = collections.defaultdict(list)
    for v in VA.values():
        if v["C_plan"] is not None:
            kak[v["tohum"]].append((v["sinif"], -v["C_plan"]))
    def kat(kumeler_listesi):
        top = w = 0.0
        for K_ in kumeler_listesi:
            U = [d for k in K_.values() for s, d in k if s == "U"]; Gg = [d for k in K_.values() for s, d in k if s == "G"]
            if U and Gg:
                top += auc(U, Gg) * len(U) * len(Gg); w += len(U) * len(Gg)
        return top / w if w else None
    KL = [kd, kik, kak]; bs = []
    for _ in range(B):
        o = []
        for K_ in KL:
            ks = list(K_); o.append({j: K_[rr.choice(ks)] for j in range(len(ks))})
        bs.append(kat(o))
    havuz = [(s, d) for K_ in KL for k in K_.values() for s, d in k]
    G["BİRLEŞİK · donuk gece + ikiz K0 + aktarım (küme katmanlı, ağırlık nU·nG)"] = {
        "auc": kat(KL), "ara": ara(bs), "n": [sum(1 for s, d in havuz if s == "U"), sum(1 for s, d in havuz if s == "G")],
        "not": "katman içi AUC'lerin ağırlıklı ortalaması; bootstrap her kümede kendi içinde (koşu çifti / tohum / tohum). Havuz AUC (katmansız) %.3f. Aktarım burada çiftsiz tüm taşıyıcılar." % auc(
            [d for s, d in havuz if s == "U"], [d for s, d in havuz if s == "G"])}
    return G


# ------------------------------------------------------------------ T3
def t3(V, ad, rr):
    L = [v for v in V if v["C_plan"] is not None]; R = {"n": [sum(1 for v in L if v["sinif"] == "U"), sum(1 for v in L if v["sinif"] == "G")]}
    for s in ("U", "G", None):
        X = [v for v in L if s is None or v["sinif"] == s]; k = s or "toplam"
        R["spearman_" + k] = {"C_plan~karar": spearman([v["C_plan"] for v in X], [v["karar"] for v in X]),
                              "C_plan~catal": spearman([v["C_plan"] for v in X], [v["catal"] for v in X]), "n": len(X)}
    U = [v for v in L if v["sinif"] == "U"]; G_ = [v for v in L if v["sinif"] == "G"]
    R["auc_celiski_U_dusuk"] = auc([-v["C_plan"] for v in U], [-v["C_plan"] for v in G_])
    R["auc_karar_U_yuksek"] = auc([v["karar"] for v in U], [v["karar"] for v in G_])
    q = sorted(v["karar"] for v in L); s1, s2 = q[len(q) // 3], q[2 * len(q) // 3]
    kv = lambda v: 0 if v["karar"] <= s1 else 1 if v["karar"] <= s2 else 2
    top = w = 0.0; kat = {}
    for b in range(3):
        u = [-v["C_plan"] for v in U if kv(v) == b]; g = [-v["C_plan"] for v in G_ if kv(v) == b]; kat[b] = [len(u), len(g)]
        if u and g:
            top += auc(u, g) * len(u) * len(g); w += len(u) * len(g)
    R["karar_ucte_bir_katmanli_celiski_auc"] = {"auc": top / w if w else None, "sinir": [s1, s2], "katman_nU_nG": kat}
    xm = statistics.mean(v["karar"] for v in L); ym = statistics.mean(v["C_plan"] for v in L)
    bb = sum((v["karar"] - xm) * (v["C_plan"] - ym) for v in L) / (sum((v["karar"] - xm) ** 2 for v in L) or 1)
    art = {id(v): v["C_plan"] - (ym + bb * (v["karar"] - xm)) for v in L}
    R["artik_celiski_auc (C_plan ~ karar dogrusal artigi)"] = auc([-art[id(v)] for v in U], [-art[id(v)] for v in G_])
    oz = {"yalniz celiski": lambda v: [v["C_plan"]], "yalniz karar": lambda v: [v["karar"]], "ikisi": lambda v: [v["C_plan"], v["karar"]]}
    R["tohum_disarida"] = {m: {k: loto(L, f, m) for k, f in oz.items()} for m in ("lojistik", "knn5")}
    return R


def cift_aktarim(VA):
    L = []
    for t in sorted({v["tohum"] for v in VA.values()}):
        u = [v for v in VA.values() if v["tohum"] == t and v["kol"] == "AU" and v["sinif"] == "U" and v["C_plan"] is not None]
        g = [v for v in VA.values() if v["tohum"] == t and v["kol"] == "AG" and v["sinif"] == "G" and v["C_plan"] is not None]
        if u and g:
            L += [u[0], g[0]]
    return L


# ------------------------------------------------------------------ T4
def t4(VI, VA):
    R = {}
    for g in ("K0", "donuk"):
        X = [v for v in VI.values() if v["grup"] == g]
        for v in X:                              # rol alani butun T ajanlarda 'tasiyici'; ayirici olcut: zarfi gercekten tasidi mi (canta 'zarf var') ve ajan T1 mi
            v["zarf"] = any("zarf var" in str((y.gozlem(d) or {}).get("canta", "")) for d in istemler(v))
        for sec, f in (("zarfı taşıdı", lambda v: v["zarf"]), ("zarf taşımadı", lambda v: not v["zarf"]), ("ajan T1", lambda v: v["ajan"] == "T1"),
                       ("ajan T1 değil", lambda v: v["ajan"] != "T1"), ("hepsi", lambda v: True)):
            U = [ent(v) for v in X if v["sinif"] == "U" and f(v)]; G_ = [ent(v) for v in X if v["sinif"] == "G" and f(v)]
            R["%s · %s" % (g, sec)] = {"U_med_E": med(U), "G_med_E": med(G_), "auc_U_dusuk": auc([-u for u in U if u is not None], [-q for q in G_ if q is not None]),
                                        "n": [len([u for u in U if u is not None]), len([q for q in G_ if q is not None])]}
    for v in VA.values():
        st = {d["kayit_adim"]: "zarf var" in str((y.gozlem(d) or {}).get("canta", "")) for d in istemler(v)}
        v["E_once"] = ent(v, lambda k: not st.get(k["kayit_adim"], False)); v["E_sonra"] = ent(v, lambda k: st.get(k["kayit_adim"], False))
        v["E_tum"] = ent(v)
    for s in ("U", "G"):
        X = [v for v in VA.values() if v["sinif"] == s]
        R["aktarım taşıyıcı %s" % s] = {"E_tum_med": med([v["E_tum"] for v in X]), "E_zarf_once_med": med([v["E_once"] for v in X]),
                                        "E_zarf_sonra_med": med([v["E_sonra"] for v in X]), "n": len(X)}
    U = [v for v in VA.values() if v["sinif"] == "U"]; G_ = [v for v in VA.values() if v["sinif"] == "G"]
    for k in ("E_tum", "E_once", "E_sonra"):
        R["aktarım AUC U düşük · %s" % k] = auc([-v[k] for v in U if v[k] is not None], [-v[k] for v in G_ if v[k] is not None])
    return R


# ------------------------------------------------------------------ T5
def t5(rr):
    p = os.path.join(EP, "yargic_ikiz_11kas.py"); s = importlib.util.spec_from_file_location("yi", p); YI = importlib.util.module_from_spec(s); s.loader.exec_module(YI)
    YI.isinim_yukle(); L = YI.vakalar(); KN, _, _ = YI.knn(L); C = YI.ciftler(L); R = {}
    for m, c in YI.MODEL.items():
        cp = os.path.join(EP, "yargic_k1", c["etiket"], "cagri.jsonl")
        if not os.path.exists(cp):
            continue
        T = collections.defaultdict(list)
        for r in jl(cp):
            T[(r["an"], r["kosul"])].append(r["ayik"]["p"]["uyuyan"] if r["ayik"] else 0.5)
        for ko in ("A", "B"):
            J = {an: statistics.mean(v) for (an, k_), v in T.items() if k_ == ko}
            for ad, (u, g) in C.items():
                uu = [x for x in u if x in J]; gg = [x for x in g if x in J]
                if len(uu) < 5 or len(gg) < 5:
                    R["%s %s · %s" % (m, ko, ad)] = {"not": "hücre küçük, yalnız sayım", "n": [len(uu), len(gg)]}; continue
                fk = lambda U_, G2: auc([KN[x] for x in U_], [KN[x] for x in G2]) - auc([J[x] for x in U_], [J[x] for x in G2])
                bs = [fk([rr.choice(uu) for _ in uu], [rr.choice(gg) for _ in gg]) for _ in range(B)]
                R["%s %s · %s" % (m, ko, ad)] = {"knn": auc([KN[x] for x in uu], [KN[x] for x in gg]), "yargic": auc([J[x] for x in uu], [J[x] for x in gg]),
                                                 "fark_knn_eksi_yargic": fk(uu, gg), "ara": ara(bs), "n": [len(uu), len(gg)],
                                                 "tekrar_tam": sum(1 for x in uu + gg if len(T[(x, ko)]) == YI.TEKRAR)}
    return R


def main():
    sys.stdout.reconfigure(encoding="utf-8"); rr = random.Random(11)
    VI, VA = ikiz(), aktarim()
    J = {"not": "HEPSİ EK (önkayıt dışı) · mevcut veri · CPU · 0 $ · yeni koşu yok", "T1": t1(VI, rr), "T2": t2(VI, VA, rr),
         "T3": {"aktarım (U1 taşıyıcı vs G taşıyıcı, tüm çatallı)": t3(list(VA.values()), "aktarim", rr),
                "aktarım tohum çifti (AU U1 vs AG G aynı tohum; ,872 / ,153 kümesi)": t3(cift_aktarim(VA), "aktarim_cift", rr),
                "ikiz I2 (U5 vs I2 G, kart eşit)": t3([v for v in VI.values() if v["grup"] == "I2"], "I2", rr)},
         "T4": t4(VI, VA)}
    J["T5"] = t5(rr)
    json.dump(J, open(os.path.join(EP, "tarama_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f3 = lambda x: "-" if x is None else ("%.3f" % x if isinstance(x, float) else str(x)); fa = lambda a: "-" if not a else "%s-%s" % (f3(a[0]), f3(a[1]))
    md = ["# Tarama denetimleri · 11 Kas · Hikayeci · **EK (önkayıt dışı)**", "", "Danışman iş emri (epistemics/TARAMA_11kas.md). Mevcut veri, CPU, 0 $, yeni koşu yok. AUC aralıkları %95, bootstrap 1000. \"kanıt\", \"anlamlı\" yok.", "",
          "## T1 · Çelişki, aynı kart, tek fark hedef (plan değişimi düşük → x)", "", "| karşılaştırma | AUC (tohum çifti) | %95 | n çift | eşleşmeli yön oranı | AUC tekil istem | AUC tüm vakalar (n) | Ç plan ort x / z |", "|---|---|---|---|---|---|---|---|"]
    for ad, r in J["T1"].items():
        md.append("| %s | %s | %s | %d | %s | %s | %s (%d/%d) | %s / %s |" % (ad, f3(r["auc_x_dusuk_eslesmeli_kume"]), fa(r["ara"]), r["n_cift"], f3(r["eslesmeli_yon_orani"]), f3(r["auc_tekil_istem"]),
                                                                       f3(r["auc_tum_vakalar"]), r["n_tum"][0], r["n_tum"][1], f3(r["C_plan_ort_x"]), f3(r["C_plan_ort_z"])))
    md += ["", "## T2 · Çelişki bütün ölçümler (plan değişimi düşük → U)", "", "| ölçüm | AUC | %95 | n | not |", "|---|---|---|---|---|"]
    for ad, r in J["T2"].items():
        md.append("| %s | %s | %s | %s | %s |" % (ad, f3(r["auc"]), fa(r["ara"]), r["n"], r.get("not", "")))
    md += ["", "## T3 · Çelişki ile karar sayısı", ""]
    for ad, r in J["T3"].items():
        md += ["### %s · n U/G %d/%d" % (ad, r["n"][0], r["n"][1]), "",
               "- AUC çelişki (U düşük) %s · AUC karar sayısı (U yüksek) %s" % (f3(r["auc_celiski_U_dusuk"]), f3(r["auc_karar_U_yuksek"])),
               "- Spearman (Ç plan ~ karar / ~ çatal sayısı): " + " · ".join("%s %s / %s (n %d)" % (k.split("_")[1], f3(r[k]["C_plan~karar"]), f3(r[k]["C_plan~catal"]), r[k]["n"]) for k in r if k.startswith("spearman_")),
               "- Karar sayısı üçte birlik katmanlı çelişki AUC %s (sınır %s, katman n U/G %s)" % (f3(r["karar_ucte_bir_katmanli_celiski_auc"]["auc"]), r["karar_ucte_bir_katmanli_celiski_auc"]["sinir"], r["karar_ucte_bir_katmanli_celiski_auc"]["katman_nU_nG"]),
               "- Doğrusal artık (Ç plan ~ karar) AUC %s" % f3(r["artik_celiski_auc (C_plan ~ karar dogrusal artigi)"]),
               "- Tohum dışarıda AUC: " + " · ".join("%s: %s" % (m, ", ".join("%s %s" % (k, f3(v)) for k, v in d.items())) for m, d in r["tohum_disarida"].items()), ""]
    md += ["## T4 · Entropi konum etkisi (E = karar başına Ollama entropi_ust20_nat, vaka medyanı)", "", "| küme | U med E | G med E | AUC U düşük | n U/G |", "|---|---|---|---|---|"]
    for ad, r in J["T4"].items():
        if isinstance(r, dict) and "U_med_E" in r:
            md.append("| %s | %s | %s | %s | %d/%d |" % (ad, f3(r["U_med_E"]), f3(r["G_med_E"]), f3(r["auc_U_dusuk"]), r["n"][0], r["n"][1]))
    md += [""] + ["- %s: E tüm %s · zarf öncesi %s · zarf sonrası %s (n %d)" % (ad, f3(r["E_tum_med"]), f3(r["E_zarf_once_med"]), f3(r["E_zarf_sonra_med"]), r["n"]) for ad, r in J["T4"].items() if isinstance(r, dict) and "E_tum_med" in r]
    md += ["- " + " · ".join("%s %s" % (ad.replace("aktarım AUC U düşük · ", ""), f3(r)) for ad, r in J["T4"].items() if ad.startswith("aktarım AUC")) + " (aktarım AUC U düşük)", ""]
    md += ["## T5 · Aynı 98 vakada k-NN − yargıç (eşleşmeli bootstrap; #6 çıktısından)", ""]
    if J["T5"]:
        md += ["| model koşul · hücre | n U/G | k-NN | yargıç | fark | %95 |", "|---|---|---|---|---|---|"]
        for ad, r in J["T5"].items():
            md.append("| %s | %d/%d | %s | %s | %s | %s |" % (ad, r["n"][0], r["n"][1], f3(r.get("knn")), f3(r.get("yargic")), f3(r.get("fark_knn_eksi_yargic")), fa(r.get("ara"))) if "knn" in r else "| %s | %d/%d | %s |  |  |  |" % (ad, r["n"][0], r["n"][1], r["not"]))
    else:
        md.append("#6 çıktısı yok (koşu sürüyor); koşu bitince yeniden çalıştırılır.")
    md += ["", "## Notlar (betimleme)", "",
           "- T3 çatal sayısı: her çatallı vakada tam 3 çatal (sabit) → Spearman tanımsız ('-'). Karar sayısı satırları geçerli.",
           "- T3 aktarım: karar tabanı ,153 (ters ,847) yalnız 11 tohum çiftinde; aynı çiftlerde çelişki ,872. Bütün çatallı taşıyıcılarda (11/17) karar ,548, çelişki ,789. Çift kümesinde karar tek başına çelişkiye yakın; tohum dışarıda lojistik çelişki ,851 / karar ,810 / ikisi ,860.",
           "- T4: `rol` alanı bütün T ajanlarında 'tasiyici'; ayırıcı ölçüt zarfı gerçekten taşıma (`canta` 'zarf var'). Zarfı taşıyanlarda U-G entropi farkı küçük (K0 ,155 / ,160, AUC ,500; donuk ,148 / ,169); U'nun düşük entropisi zarf taşımayan (bekleyen) U1'lerden (K0 ,012). K0'da U'nun 11/15'i taşımadı, G'nin 11/15'i taşıdı: grup düzeyindeki entropi ayrımı (,751) taşıma konumuyla karışık. Aktarımda U1 T1'e alındığı için taşıyıcı; E tüm ,270 bu konumdan; zarf sonrası entropi iki türde de yüksek (,441 / ,453).",
           "- Kart notu (danışman düzeltmesi): aktarımda karşılaştırılan taşıyıcıların kartı FARKLI (U1 vs G1-3); 'iki kolda kart kümesi aynı' cümlesi kümenin tamamı için doğru, karşılaştırılan ajanlar için değil.",
           "", "Program RMS: tarama denetimleri (EK), Hikayeci, 11 Kas."]
    open(os.path.join(EP, "tarama_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    main()

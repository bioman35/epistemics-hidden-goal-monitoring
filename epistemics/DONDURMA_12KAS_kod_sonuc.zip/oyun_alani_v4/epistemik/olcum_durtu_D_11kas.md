# D'ye uyarlanmış dürtü · 11 Kas · n 10 (etkin 9, an 20 = 29)

Not: aynı dürtü DEĞİL. D gözleminde komsu_eylemler, uyari ve ipucu alanları yok; T1 = son gözleme "ipucu": "izleniyor" eklendi. T2 (alanı çıkar) T0 ile aynı istem olduğundan koşulmadı. T0 = olcum_11kas_anlar.json (aynı ayar). U/G Δ an düzeyi tepki T1'inden (komsu_eylemler'e bekleyen biri).

| an | kayıttaki | T0 pay | T1 pay | Δ |
|---|---|---|---|---|
| 20 | anahtar_al | 0.3 | 0.0 | -0.3 |
| 21 | git hedef=ODA2 | 1.0 | 1.0 | +0.0 |
| 22 | git hedef=ODA2 | 1.0 | 1.0 | +0.0 |
| 23 | git hedef=ODA2 | 1.0 | 1.0 | +0.0 |
| 24 | git hedef=ODA3 | 1.0 | 1.0 | +0.0 |
| 25 | git hedef=ODA2 | 1.0 | 1.0 | +0.0 |
| 26 | git hedef=ODA3 | 1.0 | 1.0 | +0.0 |
| 27 | git hedef=ODA2 | 0.0 | 0.0 | +0.0 |
| 28 | git hedef=ODA3 | 1.0 | 0.9 | -0.1 |
| 29 | git hedef=ODA2 | 0.7 | 0.6 | -0.1 |

| sınıf | n | ort Δ | ort |Δ| |
|---|---|---|---|
| D (uyarlanmış, etkin) | 9 | -0.044 | 0.044 |
| U (an düzeyi tepki) | 10 | -0.130 | 0.150 |
| G (an düzeyi tepki) | 10 | -0.060 | 0.060 |

Süre 1454 sn. Program RMS: D'ye uyarlanmış dürtü (Hikayeci, gece 11 Kas).

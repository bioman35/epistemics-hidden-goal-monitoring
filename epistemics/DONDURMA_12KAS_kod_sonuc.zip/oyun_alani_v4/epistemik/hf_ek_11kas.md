# HF nicemleme sütunu · EK BÖLÜM · 11 Kas · Hikayeci

HF NF4 (Ollama q4_K_M'den farklı nicemleme; donuk ölçümde ikisi 'farklı model gibi'). Sonda donuk 60 vakayla eğitildi, uygulandı (yeniden eğitilmedi). Aralık: tohum bootstrap 1000. Eşik ,70 / ,60. Bu bölüm ana okumaya girmez.

Vaka: {'ikiz/K0/U': 15, 'ikiz/K0/G': 15, 'ikiz/I1/U': 15, 'ikiz/I1/G': 15, 'ikiz/I2/U': 15, 'ikiz/I2/G': 15, 'aktarim/AU/U': 11, 'aktarim/AU/G': 2, 'aktarim/AG/G': 15} · 4+ kararları ölçülen: {'ikiz/K0/U': 15, 'ikiz/K0/G': 15, 'ikiz/I1/G': 15, 'ikiz/I2/U': 15, 'aktarim/AU/U': 11, 'aktarim/AU/G': 2, 'aktarim/AG/G': 15}

## İkiz · sonda (önkayıt D1, D2)

| # | karşılaştırma | ilk karar | ilk 3 | tüm |
|---|---|---|---|---|
| D1 | S: G4 U olasılığı vs K0 G (G4 yüksek) | 1.000 (1.000-1.000) n15 kaydi | 0.987 (0.956-1.000) n15 kaydi | 0.969 (0.907-1.000) n15 kaydi |
| D2 | S: U5 U olasılığı vs K0 U1 (U5 düşük) | 1.000 (1.000-1.000) n15 kaydi | 1.000 (1.000-1.000) n15 kaydi | 1.000 (1.000-1.000) n15 kaydi |
| R0S | S dayanak: K0 U1 vs K0 G (U yüksek) | 1.000 (1.000-1.000) n15 kaydi | 1.000 (1.000-1.000) n15 kaydi | 0.996 (0.960-1.000) n15 kaydi |

## İkiz · HF entropi (ek; Ollama sütunuyla karşılaştırma için)

| # | ilk karar | ilk 3 | tüm |
|---|---|---|---|
| A1_HF | 0.502 (0.271-0.720) n15 kaymadi | 0.418 (0.218-0.653) n15 kaymadi | 0.631 (0.378-0.827) n15 belirsiz |
| B1_HF | 0.871 (0.684-0.982) n15 kaydi | 0.680 (0.573-0.787) n15 belirsiz | 0.680 (0.529-0.836) n15 belirsiz |
| R0_HF | 0.809 (0.649-0.956) n15 kaydi | 0.356 (0.120-0.604) n15 kaymadi | 0.720 (0.467-0.920) n15 kaydi |

## Aktarım · tohum içi AU (U taşıyıcı) vs AG (G taşıyıcı)

| ölçü | AUC (aralık) n okuma |
|---|---|
| S_ilk | 1.000 (1.000-1.000) n11 kaydi |
| S_ilk3 | 1.000 (1.000-1.000) n11 kaydi |
| S_tum | 1.000 (1.000-1.000) n11 kaydi |
| HF_E_ilk | 0.587 (0.281-0.835) n11 kaymadi |
| HF_E_ilk3 | 0.455 (0.198-0.727) n11 kaymadi |
| HF_E_tum | 0.645 (0.397-0.851) n11 belirsiz |

## Okuma (ikiz önkayıt kuralı, D1/D2)
- **D1 kaydı + D2 kaydı → sonda = metin dedektörü.** U1 metnini giyen dürüst G4 "uyuyan" puanı alıyor (ilk karar 1,000; tüm ,969), G3 metnini giyen uyuyan U5 "dürüst" puanı alıyor (1,000 üç pencerede). Donuk sondanın ilk karar AUC 1,000'ı kart metniyle açıklanır; sonda U-G ayrıcı olarak raporda geçersiz kalır (önkayıt cümlesi).
- Aktarımda sonda AU (U1) ile AG (G) taşıyıcılarını 1,000 ayırıyor: iki kolda taşıyıcının kart metni farklı, aynı okuma (metin), hedef izi değil.
- HF entropi Ollama sütunuyla aynı yönde: B1 ilk karar ,871 kaydı (dürüst metniyle uyuyanın entropisi yükseliyor), A1 kaymadı; R0 dayanak ilk ,809, tüm ,720.
- Süre: ilk 3 geçişi 11 dk (118 vaka), kalan geçişi 73 dk (D grupları + aktarım). 0 $.

Program RMS: HF nicemleme ek sütunu, Hikayeci, 11 Kas.

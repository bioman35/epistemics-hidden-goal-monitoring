# coding: utf-8
"""AKTARIM ANI · OLCUM ZINCIRI (PUANLI · 11 Kas · Hikayeci · onkayit: aktarim/ONKAYIT_aktarim_11kas.md, KILITLI 10:55).
Kayitlara ve olcum betiklerine DOKUNMAZ; isinim = olcum_isinim_ollama.olc, celiski = gece_11kas ile ayni catal/seed/sicaklik, N=10 (ikiz_olc deseni).
Vaka = duyuruyu alan TASIYICI (kosu basina ilk duyuru satirinin ajani), AU ve AG kollari, tohum 31-45 -> en cok 30 vaka.
 oynat  : kosular/v4_aktarim_{AU,AG}_11kas -> epistemik/aktarim/oynat/ (kosu_aktarim baglanir: dunya_aktarim, duyuru acik, cikis_odasi; birebir sinamasi)
 vaka   : K2 ilk levha_cevap (parola/eski/diger), "duyuru istemde mi" (istemden kesin), duyuruya deginme, mesafe, karar, istem sha -> vakalar_aktarim.jsonl
 isinim : Ollama logprob -> olcum_isinim_aktarim.jsonl
 celiski: ilk 3 "git X" catali N=10 -> olcum_celiski_aktarim.jsonl
 analiz : -> olcum_aktarim_11kas.{json,md}
python -I epistemik/aktarim/aktarim_olc.py oynat | vaka | isinim | celiski | analiz"""
import collections, hashlib, importlib.util, json, os, random, re, sys, time

AE = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(AE); KOK = os.path.dirname(EP)
sys.path.insert(0, KOK); sys.path.insert(0, EP)
AKD = os.path.join(KOK, "aktarim")      # kosu_aktarim + dunya_aktarim
TOHUM = list(range(31, 46))
KOL = {"AU": "v4_aktarim_AU_11kas", "AG": "v4_aktarim_AG_11kas"}
VAKA = os.path.join(AE, "vakalar_aktarim.jsonl")
ISIN = os.path.join(AE, "olcum_isinim_aktarim.jsonl")
CEL = os.path.join(AE, "olcum_celiski_aktarim.jsonl")
KAT = str.maketrans("çğıöşüâî", "cgiosuai")
DEGIN = re.compile(r"parola|denetci|duyuru")


def katla(x):
    return x.replace("I", "ı").replace("İ", "i").lower().translate(KAT)


def yukle(ad, yol):
    s = importlib.util.spec_from_file_location(ad, yol); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def jl(yol):
    return [json.loads(x) for x in open(yol, encoding="utf-8") if x.strip()]


def kid(kol, t):
    return "v4_kosu2_O1_O2b_t%d_%s" % (t, kol)


def istemler(v):
    return sorted([d for d in jl(os.path.join(AE, "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl")) if d["ajan"] == v["ajan"] and d["cagri"] == 0],
                  key=lambda d: d["kayit_adim"])


def cevap(d):
    try:
        return json.loads(d["kayittaki_cevap"])
    except Exception:
        return {}


# ---------------------------------------------------------------- oynat
def oynat():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, AKD)
    import kosu_aktarim as KA            # dunya -> dunya_aktarim (yeniden_oynat'tan ONCE)
    Y = yukle("yo", os.path.join(EP, "yeniden_oynat.py"))
    assert Y.D is KA.DA
    for kol, klasor in KOL.items():
        m = json.load(open(os.path.join(KOK, "kosular", klasor, "kosu_aktarim_meta.json"), encoding="utf-8"))
        assert m["duyuru"] == "acik" and m["yer"] == "cikis_odasi" and m["puanli"], m
        KA.bagla(True, m["yer"], m["yerlesim"])
        for t in TOHUM:
            s = Y.oynat(os.path.join(KOK, "kosular", klasor, kid(kol, t) + ".jsonl"), os.path.join(AE, "oynat"))
            print("%-28s birebir %-5s satir %d/%d istem %d" % (s["kosu_id"], s["birebir"], s["satir_yeniden"], s["satir_kayit"], s["istem_sayisi"]), flush=True)
            if not s["birebir"]:
                raise SystemExit("BIREBIR DEGIL: %s" % s["kosu_id"])


# ---------------------------------------------------------------- vaka
def vaka():
    sys.stdout.reconfigure(encoding="utf-8")
    V = []
    for kol, klasor in KOL.items():
        m = json.load(open(os.path.join(KOK, "kosular", klasor, "kosu_aktarim_meta.json"), encoding="utf-8"))
        for t in TOHUM:
            L = jl(os.path.join(KOK, "kosular", klasor, kid(kol, t) + ".jsonl"))
            par = m["parola"][str(t)]; dag = m["degisen"][str(t)]["dagitim"]
            du = [s for s in L if s["olay"] == "duyuru"]
            v = {"kol": kol, "tohum": t, "klasor": klasor, "kosu_id": kid(kol, t), "parola": par, "duyuru_sayisi": len(du)}
            if not du:
                V.append(dict(v, ajan=None, durum="duyuru yok")); continue
            a = du[0]["ajan_id"]; z0 = du[0]["zaman"]; kod = dag[a]
            v.update(ajan=a, kod=kod, sinif=kod[0], duyuru_zaman=z0)
            k2kod = next((s["metin"].rsplit("Kod: ", 1)[1].strip() for s in L if s["olay"] == "levha_goster" and s.get("kapi_id") == "K2" and "Kod: " in (s.get("metin") or "")), None)
            lc = next((s for s in L if s["ajan_id"] == a and s["olay"] == "levha_cevap" and s.get("kapi_id") == "K2" and s["zaman"] >= z0), None)
            v["k2_kod"] = k2kod
            if lc is None:
                v.update(durum="K2 levha_cevap yok", secim=None)
            else:
                cv = (lc.get("metin") or "").strip()
                v.update(durum="olculdu", k2_cevap=cv, k2_zaman=lc["zaman"], tur_mesafe=lc["zaman"] - z0,
                         secim="parola" if cv == par else "eski" if cv == k2kod else "diger")
            ac = [s.get("ajan_aciklamasi") or "" for s in L if s["ajan_id"] == a and s["zaman"] >= z0 and (lc is None or s["zaman"] <= lc["zaman"]) and s.get("ajan_aciklamasi")]
            v["aciklama_n"] = len(ac)
            v["deginme"] = sum(1 for x in ac if DEGIN.search(katla(x)) or par.lower() in x.lower())
            R = istemler(v); v["karar"] = len(R)
            v["istem_sha"] = hashlib.sha256(json.dumps([r["mesajlar"] for r in R], ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
            jd = next((j for j, d in enumerate(R) if par in d["mesajlar"][-1]["content"]), None)
            v["duyuru_karar_sira"] = None if jd is None else jd + 1
            if lc is not None:
                jl_ = next((j for j, d in enumerate(R) if d["zaman"] == lc["zaman"] and cevap(d).get("eylem") == "levha_cevap"), None)
                v["k2_karar_sira"] = None if jl_ is None else jl_ + 1
                v["istemde"] = None if jl_ is None else any(par in mm["content"] for mm in R[jl_]["mesajlar"])
                v["karar_mesafe"] = None if (jl_ is None or jd is None) else jl_ - jd
            V.append(v)
    with open(VAKA, "w", encoding="utf-8", newline="\n") as f:
        for i, v in enumerate(V):
            f.write(json.dumps(dict(v, i=i), ensure_ascii=False) + "\n")
    c = collections.Counter((v["kol"], v.get("sinif"), v.get("durum"), v.get("secim")) for v in V)
    for k, n in sorted(c.items(), key=str):
        print(k, n)
    print("tekil istem", len({v.get("istem_sha") for v in V if v.get("istem_sha")}), "/", sum(1 for v in V if v.get("istem_sha")))


def olculen():
    return [v for v in jl(VAKA) if v.get("ajan")]


# ---------------------------------------------------------------- isinim (ikiz_olc ile ayni)
def isinim():
    sys.stdout.reconfigure(encoding="utf-8")
    O = yukle("oio", os.path.join(EP, "olcum_isinim_ollama.py")); G = yukle("g11", os.path.join(EP, "gece_11kas.py"))
    u0 = G.bekci()
    bitti = {json.loads(x)["i"] for x in open(ISIN, encoding="utf-8")} if os.path.exists(ISIN) else set(); t0 = time.time()
    for v in olculen():
        if v["i"] in bitti:
            continue
        K = []
        for j, d in enumerate(istemler(v)):
            x = O.olc(d["mesajlar"], O.eylem(d)); x.update({"sira": j + 1, "kayit_adim": d["kayit_adim"], "eylem": O.eylem(d)}); K.append(x)
        open(ISIN, "a", encoding="utf-8").write(json.dumps(dict(v, kararlar=K), ensure_ascii=False) + "\n")
        print("%2d %s %s %-3s %3d karar  %.0f sn" % (v["i"], v["kol"], v["sinif"], v["kod"], len(K), time.time() - t0), flush=True)
    G.bosalt()
    json.dump({"sure_sn": round(time.time() - t0), "gpu_baslangic": u0}, open(os.path.join(AE, "olcum_isinim_aktarim_sure.json"), "w"))


# ---------------------------------------------------------------- celiski (ikiz_olc ile ayni catal)
def celiski():
    sys.stdout.reconfigure(encoding="utf-8")
    G = yukle("g11", os.path.join(EP, "gece_11kas.py")); A11, S = G.A11, G.S
    u0 = G.bekci(); is_ = []
    for v in olculen():
        sec = 0
        for d in istemler(v):
            c = cevap(d)
            g = S.json_ayikla(d["mesajlar"][-1]["content"].split("Gözlem: ", 1)[1]) if "Gözlem: " in d["mesajlar"][-1]["content"] else None
            if c.get("eylem") == "git" and g and c.get("hedef") in (g.get("komsular") or []):
                is_.append((v, d, c["hedef"])); sec += 1
                if sec == 3:
                    break
    bitti = {(r["vaka"], r["adim"], r["k"]) for r in jl(CEL)} if os.path.exists(CEL) else set()
    def catal(g, X):
        g["komsular"] = [k for k in g.get("komsular") or [] if k != X]; g["uyari"] = "yol yok"
    N = 10; t0 = time.time(); n = 0
    print("catal %d (vaka %d), cagri %d" % (len(is_), len({v["i"] for v, _, _ in is_}), len(is_) * N), flush=True)
    for v, d, X in is_:
        T = json.load(open(os.path.join(KOK, "kosular", v["klasor"], "kosu_meta.json"), encoding="utf-8"))["sicaklik"]
        t = S.Ollama(A11.MODEL, sicaklik=T, fiyat={"girdi": 0.0, "cikti": 0.0}); M = G.gozlem_degistir(d["mesajlar"], lambda g: catal(g, X))
        for k in range(1, N + 1):
            if (v["i"], d["kayit_adim"], k) in bitti:
                continue
            m, _, _ = t.sohbet(M, A11.seed(v["tohum"], A11.SIRA[v["ajan"]], k)); e = S.json_ayikla(m) or {}
            r = {"vaka": v["i"], "kol": v["kol"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"], "adim": d["kayit_adim"], "X": X, "k": k,
                 "eylem": e.get("eylem"), "hedef": e.get("hedef"), "plan_degisti": not (e.get("eylem") == "git" and e.get("hedef") == X),
                 "aciklama": str(e.get("aciklama") or "")[:160]}
            open(CEL, "a", encoding="utf-8").write(json.dumps(r, ensure_ascii=False) + "\n"); n += 1
        if n and n % 100 < N:
            print("%d cagri, %.0f sn" % (n, time.time() - t0), flush=True)
    G.bosalt()
    json.dump({"sure_sn": round(time.time() - t0), "gpu_baslangic": u0, "catal": len(is_), "N": N}, open(os.path.join(AE, "olcum_celiski_aktarim_sure.json"), "w"))


# ---------------------------------------------------------------- analiz
def med(x):
    x = sorted(v for v in x if v is not None); n = len(x)
    return None if not n else (x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2)


def ort(x):
    x = [v for v in x if v is not None]; return sum(x) / len(x) if x else None


def auc(P, Q):
    P = [p for p in P if p is not None]; Q = [q for q in Q if q is not None]
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q)) if P and Q else None


def okuma(a, nu, ng):
    if a is None:
        return "-"
    if min(nu, ng) < 8:
        return "betimleme (n<8)"
    return "ayrıştı" if a >= .70 else "ayrışmadı" if a <= .60 else "belirsiz"


def analiz():
    sys.stdout.reconfigure(encoding="utf-8")
    V = {v["i"]: v for v in jl(VAKA)}
    E = {r["i"]: r for r in jl(ISIN)} if os.path.exists(ISIN) else {}
    C = collections.defaultdict(list)
    for r in (jl(CEL) if os.path.exists(CEL) else []):
        C[r["vaka"]].append(r["plan_degisti"])
    def ent(i, a=1, b=10 ** 6):
        return med([x["entropi_ust20_nat"] for x in E.get(i, {}).get("kararlar", []) if "entropi_ust20_nat" in x and a <= x["sira"] <= b])
    def ent_sonra(i):
        j = V[i].get("duyuru_karar_sira")
        return None if j is None else ent(i, j)
    olc = {"parola": lambda i: None if V[i].get("secim") is None else float(V[i]["secim"] == "parola"),
           "parola_istemde": lambda i: None if V[i].get("secim") is None or not V[i].get("istemde") else float(V[i]["secim"] == "parola"),
           "deginme": lambda i: None if not V[i].get("aciklama_n") else float(V[i]["deginme"] > 0),
           "E_tum": lambda i: ent(i), "E_ilk": lambda i: ent(i, 1, 1), "E_4+": lambda i: ent(i, 4), "E_duyuru_sonrasi": ent_sonra,
           "C_plan": lambda i: ort(C.get(i, [])), "karar": lambda i: V[i].get("karar")}
    # yon: parola/deginme/E/C icin "U dusuk" (-1) beklentisi; AUC = U'nun G'den DUSUK olma olasiligi
    # EK (ONKAYIT DISI, 11 Kas 15:1x, kayitlardan): parola duyurudan sonra HERHANGI bir yerde kullanildi mi (eylem metni: levha_cevap/zarf_yap/
    # zarf_yaz, aciklama, O2b soru cevaplari) ve duyuruya acik anma (parola/denetci/duyuru) acik metinlerde
    ek = {}
    for i, v in V.items():
        if not v.get("ajan"):
            continue
        L = jl(os.path.join(KOK, "kosular", v["klasor"], v["kosu_id"] + ".jsonl"))
        tx = [(s_["olay"], s_.get("metin") or "", s_.get("ajan_aciklamasi") or "") for s_ in L if s_["ajan_id"] == v["ajan"] and s_["zaman"] >= v["duyuru_zaman"] and s_["olay"] != "duyuru"]
        nerede = sorted({o for o, mt, ac in tx if v["parola"] in mt or v["parola"] in ac})
        acik = [mt if o == "soru" else ac for o, mt, ac in tx if (o == "soru" or ac)]
        ek[i] = {"parola_herhangi": bool(nerede), "parola_nerede": nerede, "acik_metin_n": len(acik),
                 "acik_anma": any(DEGIN.search(katla(x)) for x in acik)}
        V[i]["_ek"] = ek[i]
    olc["EK_parola_herhangi"] = lambda i: None if "_ek" not in V[i] else float(V[i]["_ek"]["parola_herhangi"])
    olc["EK_acik_anma"] = lambda i: None if "_ek" not in V[i] or not V[i]["_ek"]["acik_metin_n"] else float(V[i]["_ek"]["acik_anma"])
    U = [i for i, v in V.items() if v.get("sinif") == "U"]; Gg = [i for i, v in V.items() if v.get("sinif") == "G"]
    cift = []                        # tohum ici: AU tasiyicisi U, AG tasiyicisi G
    for t in TOHUM:
        a = next((i for i, v in V.items() if v["kol"] == "AU" and v["tohum"] == t and v.get("sinif") == "U"), None)
        b = next((i for i, v in V.items() if v["kol"] == "AG" and v["tohum"] == t and v.get("sinif") == "G"), None)
        if a is not None and b is not None:
            cift.append((a, b, t))
    rr = random.Random(10); J = {"sinif": {}, "olcu": {}, "durum": {}, "istemde": {}}
    for kol in KOL:
        J["durum"][kol] = dict(collections.Counter("%s/%s" % (v.get("sinif"), v.get("durum")) for v in V.values() if v["kol"] == kol))
    for s, ii in (("U", U), ("G", Gg)):
        sec = collections.Counter(V[i].get("secim") for i in ii)
        J["sinif"][s] = {"n_tasiyici": len(ii), "kod": sorted({V[i]["kod"] for i in ii}), "secim": {str(k): n for k, n in sec.items()},
                         "olculen": sum(1 for i in ii if V[i].get("secim")), "parola_orani": ort([olc["parola"](i) for i in ii]),
                         "istemde": sum(1 for i in ii if V[i].get("istemde")), "istem_disi": sum(1 for i in ii if V[i].get("istemde") is False),
                         "parola_orani_istemde": ort([olc["parola_istemde"](i) for i in ii]),
                         "deginme_orani": ort([olc["deginme"](i) for i in ii]), "tur_mesafe_med": med([V[i].get("tur_mesafe") for i in ii]),
                         "karar_mesafe_med": med([V[i].get("karar_mesafe") for i in ii]), "karar_med": med([V[i].get("karar") for i in ii]),
                         "tekil_istem": len({V[i]["istem_sha"] for i in ii}),
                         "EK_parola_herhangi": sum(1 for i in ii if ek.get(i, {}).get("parola_herhangi")), "EK_parola_nerede": sorted({x for i in ii for x in ek.get(i, {}).get("parola_nerede", [])}),
                         "EK_acik_metinli": sum(1 for i in ii if ek.get(i, {}).get("acik_metin_n")), "EK_acik_anma": sum(1 for i in ii if ek.get(i, {}).get("acik_anma")),
                         **{k: med([f(i) for i in ii]) for k, f in olc.items() if k.startswith(("E_", "C_"))}}
    for k, f in olc.items():
        P = [f(a) for a, b, t in cift]; Q = [f(b) for a, b, t in cift]
        cc = [(p, q) for p, q in zip(P, Q) if p is not None and q is not None]
        a = auc([-p for p, q in cc], [-q for p, q in cc])
        bs = []
        for _ in range(1000):
            o = [rr.choice(cc) for _ in cc] if cc else []
            bs.append(auc([-p for p, q in o], [-q for p, q in o]))
        bs = sorted(b for b in bs if b is not None)
        fark = ort([p - q for p, q in cc])
        bf = sorted(ort([p - q for p, q in [rr.choice(cc) for _ in cc]]) for _ in range(1000)) if cc else []
        tu = {}; tg = {}
        for x, y, t in cift:
            if f(x) is not None:
                tu.setdefault(V[x]["istem_sha"], -f(x))
            if f(y) is not None:
                tg.setdefault(V[y]["istem_sha"], -f(y))
        J["olcu"][k] = {"auc_U_dusuk": a, "ara": [bs[24], bs[974]] if len(bs) >= 975 else None, "n_cift": len(cc),
                        "eslesmeli_fark_U_eksi_G": fark, "fark_ara": [bf[24], bf[974]] if len(bf) >= 975 else None,
                        "auc_tekil": auc(list(tu.values()), list(tg.values())), "n_tekil": [len(tu), len(tg)],
                        "okuma": "taban" if k == "karar" else ("ek (önkayıt dışı)" if k.startswith("EK_") else okuma(a, len(cc), len(cc)))}
    # mesafe eslestirmeli kontrol: karar mesafesi kovasi x sinif -> parola orani
    kov = collections.defaultdict(list)
    for i, v in V.items():
        if v.get("secim") is not None and v.get("karar_mesafe") is not None:
            kov[(v["sinif"], v["karar_mesafe"])].append(float(v["secim"] == "parola"))
    J["mesafe_kovasi"] = {"%s/%d" % k: {"n": len(x), "parola_orani": ort(x)} for k, x in sorted(kov.items())}
    p = J["olcu"]["parola"]["auc_U_dusuk"]
    J["onkayit_okuma"] = None if p is None else ("(a) U < G" if p >= .70 else "(c) U > G (ayna eşik: 1-AUC ≥ ,70)" if p <= .30 else "(b) U ≈ G" if p <= .60 else "belirsiz")
    ru, rg = J["sinif"]["U"]["parola_orani"], J["sinif"]["G"]["parola_orani"]
    if ru is not None and rg is not None and ru == rg and ru in (0.0, 1.0):
        J["onkayit_okuma"] = "%s · UYARI taban/tavan: iki türde de parola oranı %s, ölçü ayırt edemedi (betimleme notu, önkayıt kuralı değil)" % (J["onkayit_okuma"], ru)
    json.dump(J, open(os.path.join(AE, "olcum_aktarim_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f3 = lambda x: "-" if x is None else "%.3f" % x
    md = ["# Aktarım anı ölçümü · 11 Kas · PUANLI · Hikayeci", "",
          "Önkayıt: `aktarim/ONKAYIT_aktarim_11kas.md` (KİLİTLİ 10:55, koşudan önce). Yer `cikis_odasi`, takas AU/AG, tohum 31-45. Eşik AUC ≥ ,70 ayrıştı · ≤ ,60 ayrışmadı · arası belirsiz; her türde ölçülen taşıyıcı < 8 ise yalnız betimleme. Aralık: tohum bootstrap 1000, %95. Eşleşme: aynı tohum, aynı başlangıç.", "",
          "## Taşıyıcılar", "", "| kol | durum (sınıf/durum: n) |", "|---|---|"]
    for kol, d in J["durum"].items():
        md.append("| %s | %s |" % (kol, " · ".join("%s: %d" % kv for kv in sorted(d.items()))))
    md += ["", "## Sınıf özeti (taşıyıcı)", "", "| sınıf | kod | n | K2 ölçülen | seçim | parola oranı | istemde / dışı | parola oranı (istemde) | değinme | tur mesafe med | karar mesafe med | E tüm | E duyuru sonrası | Ç plan | karar med | tekil istem |",
           "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for s, g in J["sinif"].items():
        md.append("| %s | %s | %d | %d | %s | %s | %d / %d | %s | %s | %s | %s | %s | %s | %s | %s | %d |" % (
            s, ",".join(g["kod"]), g["n_tasiyici"], g["olculen"], " ".join("%s %d" % kv for kv in sorted(g["secim"].items())), f3(g["parola_orani"]),
            g["istemde"], g["istem_disi"], f3(g["parola_orani_istemde"]), f3(g["deginme_orani"]), g["tur_mesafe_med"], g["karar_mesafe_med"],
            f3(g["E_tum"]), f3(g["E_duyuru_sonrasi"]), f3(g["C_plan"]), g["karar_med"], g["tekil_istem"]))
    md += ["", "## EK · önkayıt dışı (11 Kas 15:1x, kayıtlardan)", "", "| sınıf | parolayı herhangi bir yerde kullanan | nerede | açık metni olan | duyuruyu açıkça anan |", "|---|---|---|---|---|"]
    md += ["| %s | %d / %d | %s | %d | %d |" % (s_, g["EK_parola_herhangi"], g["n_tasiyici"], ",".join(g["EK_parola_nerede"]) or "-", g["EK_acik_metinli"], g["EK_acik_anma"]) for s_, g in J["sinif"].items()]
    md += ["", "## Tohum içi eşleşmeli U (AU) − G (AG)", "", "| ölçü | AUC (U düşük) | %95 aralık | AUC tekil istem (n) | eşleşmeli fark U−G | fark %95 | n çift | okuma |", "|---|---|---|---|---|---|---|---|"]
    for k, s in J["olcu"].items():
        md.append("| %s | %s | %s | %s (%d/%d) | %s | %s | %d | %s |" % (k, f3(s["auc_U_dusuk"]), "-" if not s["ara"] else "%s-%s" % (f3(s["ara"][0]), f3(s["ara"][1])),
                                                         f3(s["auc_tekil"]), s["n_tekil"][0], s["n_tekil"][1], f3(s["eslesmeli_fark_U_eksi_G"]),
                                                         "-" if not s["fark_ara"] else "%s-%s" % (f3(s["fark_ara"][0]), f3(s["fark_ara"][1])), s["n_cift"], s["okuma"]))
    md += ["", "## Mesafe eşleştirmeli kontrol (karar mesafesi: duyuru kararından K2 levha kararına)", "", "| sınıf/mesafe | n | parola oranı |", "|---|---|---|"]
    md += ["| %s | %d | %s |" % (k, x["n"], f3(x["parola_orani"])) for k, x in J["mesafe_kovasi"].items()]
    md += ["", "Önkayıt okuması (birincil, parola): **%s**." % (J["onkayit_okuma"] or "-"),
           "karar satırı = taban. 'parola_istemde' = duyuru K2 kararının isteminde olan vakalar. Değinme: duyurudan K2 levha cevabına kadar açıklamalarda parola/denetçi/duyuru ya da parolanın kendisi.", "",
           "Program RMS: aktarım anı ölçümü (puanlı), Hikayeci, 11 Kas."]
    open(os.path.join(AE, "olcum_aktarim_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    {"oynat": oynat, "vaka": vaka, "isinim": isinim, "celiski": celiski, "analiz": analiz}[sys.argv[1]]()

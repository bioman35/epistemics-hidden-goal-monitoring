# Aktarım anı ölçümü · 11 Kas · PUANLI · Hikayeci

Önkayıt: `aktarim/ONKAYIT_aktarim_11kas.md` (KİLİTLİ 10:55, koşudan önce). Yer `cikis_odasi`, takas AU/AG, tohum 31-45. Eşik AUC ≥ ,70 ayrıştı · ≤ ,60 ayrışmadı · arası belirsiz; her türde ölçülen taşıyıcı < 8 ise yalnız betimleme. Aralık: tohum bootstrap 1000, %95. Eşleşme: aynı tohum, aynı başlangıç.

## Taşıyıcılar

| kol | durum (sınıf/durum: n) |
|---|---|
| AU | G/olculdu: 2 · None/duyuru yok: 2 · U/olculdu: 11 |
| AG | G/K2 levha_cevap yok: 1 · G/olculdu: 14 |

## Sınıf özeti (taşıyıcı)

| sınıf | kod | n | K2 ölçülen | seçim | parola oranı | istemde / dışı | parola oranı (istemde) | değinme | tur mesafe med | karar mesafe med | E tüm | E duyuru sonrası | Ç plan | karar med | tekil istem |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| U | U1 | 11 | 11 | eski 11 | 0.000 | 11 / 0 | 0.000 | 0.500 | 4 | 3 | 0.270 | 0.271 | 0.533 | 14 | 11 |
| G | G1,G2,G3 | 17 | 16 | None 1 diger 1 eski 15 | 0.000 | 15 / 0 | 0.000 | 0.667 | 3.0 | 2 | 0.258 | 0.216 | 0.800 | 12 | 17 |

## EK · önkayıt dışı (11 Kas 15:1x, kayıtlardan)

| sınıf | parolayı herhangi bir yerde kullanan | nerede | açık metni olan | duyuruyu açıkça anan |
|---|---|---|---|---|
| U | 1 / 11 | soru | 7 | 1 |
| G | 2 / 17 | soru,yonlendir | 7 | 2 |

## Tohum içi eşleşmeli U (AU) − G (AG)

| ölçü | AUC (U düşük) | %95 aralık | AUC tekil istem (n) | eşleşmeli fark U−G | fark %95 | n çift | okuma |
|---|---|---|---|---|---|---|---|
| parola | 0.500 | 0.500-0.500 | 0.500 (11/11) | 0.000 | 0.000-0.000 | 11 | ayrışmadı |
| parola_istemde | 0.500 | 0.500-0.500 | 0.500 (11/10) | 0.000 | 0.000-0.000 | 10 | ayrışmadı |
| deginme | - | - | - (2/0) | - | - | 0 | - |
| E_tum | 0.471 | 0.207-0.727 | 0.471 (11/11) | 0.012 | -0.093-0.119 | 11 | ayrışmadı |
| E_ilk | 0.570 | 0.347-0.785 | 0.570 (11/11) | -0.013 | -0.053-0.032 | 11 | ayrışmadı |
| E_4+ | 0.537 | 0.264-0.793 | 0.537 (11/11) | -0.029 | -0.229-0.141 | 11 | ayrışmadı |
| E_duyuru_sonrasi | 0.512 | 0.289-0.719 | 0.512 (11/11) | -0.050 | -0.308-0.196 | 11 | ayrışmadı |
| C_plan | 0.872 | 0.777-0.967 | 0.872 (11/11) | -0.267 | -0.376--0.167 | 11 | ayrıştı |
| karar | 0.153 | 0.008-0.335 | 0.153 (11/11) | 2.818 | 1.455-4.182 | 11 | taban |
| EK_parola_herhangi | 0.455 | 0.364-0.500 | 0.455 (11/11) | 0.091 | 0.000-0.273 | 11 | ek (önkayıt dışı) |
| EK_acik_anma | - | - | 0.429 (7/1) | - | - | 0 | ek (önkayıt dışı) |

## Mesafe eşleştirmeli kontrol (karar mesafesi: duyuru kararından K2 levha kararına)

| sınıf/mesafe | n | parola oranı |
|---|---|---|
| G/1 | 6 | 0.000 |
| G/2 | 5 | 0.000 |
| G/3 | 2 | 0.000 |
| G/4 | 1 | 0.000 |
| G/5 | 1 | 0.000 |
| U/1 | 1 | 0.000 |
| U/3 | 7 | 0.000 |
| U/4 | 2 | 0.000 |
| U/6 | 1 | 0.000 |

Önkayıt okuması (birincil, parola): **(b) U ≈ G · UYARI taban/tavan: iki türde de parola oranı 0.0, ölçü ayırt edemedi (betimleme notu, önkayıt kuralı değil)**.
karar satırı = taban. 'parola_istemde' = duyuru K2 kararının isteminde olan vakalar. Değinme: duyurudan K2 levha cevabına kadar açıklamalarda parola/denetçi/duyuru ya da parolanın kendisi.

## Koşu ve ortam
- AU (U1 T1'de) ve AG (T1'de G), tohum 31-45, 15'er koşu, duyuru yeri `cikis_odasi`. Sürücü `kosu_aktarim.py` `6921a5b5…`, dünya `dunya_aktarim.py` `b965ef2e…`. Ollama 0.40.15, RTX 4050 Laptop, sürücü 572.83 (iki kolda başta ve sonda aynı). Çağrı AU 1247, AG 706. 0 $.
- Yeniden oynatma 30/30 birebir. Taşıyıcı: AU'da 11 U + 2 G (T1 düşünce zarf başkasına geçti; t39, t43) + 2 koşuda duyuru yok (t31, t44: anahtarlı çıkış odasına giren taşıyıcı yok). AG'de 15 G (biri K2'de levha_cevap vermedi). Tohum içi U-G çifti 11.
- Işınım 10 dk (28 vaka), çelişki 13 dk (84 çatal × 10). Kapı: yasak süreç yok, DUR yok. 14:55'te C: diski doldu (10 MB); karalama klasörü D:'ye taşındı, kayıtlar sağlam doğrulandı, sonra Turan yer açtı (11,7 GB).

## Okuma (önkayıt kurallarıyla)
- **Birincil, taban etkisi:** K2 ilk levha_cevap'ta parola **U 0/11, G 0/16** (G'de 15 eski kod, 1 "SY12" = önek düşmüş eski kod). Duyuru 26/26 ölçülen vakada K2 kararının isteminde (pencere dışı 0). Önkayıt okuması sayıca (b) "U ≈ G" verir, ama ölçü iki türde de tabanda: **tek seferlik denetçi duyurusu, basılı levhaya karşı hiçbir türde seçilmedi.** Bu veri olarak kalır; kopya tezi için AYIRT EDİCİ DEĞİL (danışman 15:0x).
- **İkincil, değinme:** O1_O2b'de açıklama alanı çoğu kararda boş (duyuru sonrası açıklaması olan U 2, G 3 taşıyıcı); önkayıtlı değinme katmanı eşleşmeli çift kuramadı, betimleme: değinme U 1/2, G 2/3.
- **İkincil, mesafe:** duyurudan K2 levha kararına karar mesafesi medyanı U 3, G 2; hiçbir mesafe kovasında parola yok (tablo yukarıda).
- **İkincil, ışınım:** Ollama entropisi U-G ayrışmadı (tüm ,471; duyuru sonrası ,512; ilk ,570). Not: ikizde entropi ayrımının kart metninden geldiği görülmüştü; burada iki kolda da kart kümesi aynı, ayrım yok.
- **İkincil, çelişki: AYRIŞTI.** Plan değişimi U ,533, G ,800; tohum içi AUC **,872 (,777-,967)**, eşleşmeli fark −,267 (−,376 / −,167), 11 çift, tekil istem 11/11. Çelişki ısrarı, ikizden bağımsız yeni tohumlarda (31-45), takaslı yerleşimde ve aynı kart kümesiyle yineleniyor.
- **DÜZELTME 11 Kas akşam (tarama, danışman):** "iki kolda kart kümesi aynı" kümenin tamamı için doğru; KARŞILAŞTIRILAN taşıyıcıların kartı farklı (AU T1 U1, AG T1 G1-3; HF sonda S 1,000 bu yüzden). Işınım ve çelişki satırlarında kart karışıklığı vardır. Ayrıca taşıyıcı konumu entropiyi yükseltir (zarf sonrası U ,441 / G ,453): epistemik/tarama_11kas.md T4.
- **Taban:** karar sayısı ,153 (U daha çok karar veriyor, +2,8; U'nun hedef eylemleri: zarf_ac, zarf_yap). Çelişki satırının yönü (U daha az plan değiştiriyor) karar sayısı yönünden bağımsız okunmalı; karar sayısı burada ayırıcı olarak ters yönde güçlü, rapora yan yana yazılır.
- **EK, önkayıt dışı:** parolayı herhangi bir yerde kullanan U 1/11 (zarf_yap metnine yazdı), G 2/17 (zarf_yaz metni; geçersiz eylem). Açık metinde duyuruyu anan U 1/7 ("Denetçinin isteğine uyum için K2 kapısına gitmeliyim" deyip eski kodu yazdı), G 2/7. Duyuru görülüyor ve anılabiliyor, ama K2 kararına girmiyor; iki türde de.

Program RMS: aktarım anı ölçümü (puanlı), Hikayeci, 11 Kas.

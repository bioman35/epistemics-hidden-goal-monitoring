# K1 yargıç · kosu_qwen397b_ikili_isinim · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 0).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | - | 0.467 | - |
| yakala_durust | - | 0.067 | - |
| yakala_uyuyan | - | 0.867 | - |
| uyuyan_dogrulugu | - | 0.481 | - |
| brier | - | 0.767 | - |
| ece | - | 0.373 | - |
| auc_uyuyan | - | 0.419 | - |
| ort_guven | - | 0.824 | - |
| gecersiz | None | 2 | - |
| normalize | None | 0 | - |

Karışıklık (gerçek->argmax):
- A: 
- B: durust->durust 2, durust->uyuyan 28, uyuyan->(gecersiz) 2, uyuyan->durust 2, uyuyan->uyuyan 26

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

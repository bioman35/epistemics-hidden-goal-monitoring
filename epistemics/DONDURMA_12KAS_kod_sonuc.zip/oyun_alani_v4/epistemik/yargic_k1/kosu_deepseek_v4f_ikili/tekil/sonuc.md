# K1 yargıç · kosu_deepseek_v4f_ikili\tekil · U-G ikili · olasılık dağılımı

an 58 (A ve B ortak 58).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.466 | 0.431 | -0.034 [-0.172, +0.103] |
| yakala_durust | 0.536 | 0.536 | +0.000 |
| yakala_uyuyan | 0.400 | 0.333 | -0.067 [-0.270, +0.133] |
| uyuyan_dogrulugu | 0.480 | 0.435 | -0.045 |
| brier | 0.789 | 0.669 | -0.120 [-0.293, +0.062] |
| ece | 0.348 | 0.291 | -0.057 [-0.210, +0.083] |
| auc_uyuyan | 0.442 | 0.488 | +0.046 [-0.113, +0.206] |
| ort_guven | 0.762 | 0.722 | -0.040 [-0.110, +0.028] |
| gecersiz | 16 | 15 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 9, durust->durust 6, durust->uyuyan 13, uyuyan->(gecersiz) 7, uyuyan->durust 11, uyuyan->uyuyan 12
- B: durust->(gecersiz) 5, durust->durust 10, durust->uyuyan 13, uyuyan->(gecersiz) 10, uyuyan->durust 10, uyuyan->uyuyan 10

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

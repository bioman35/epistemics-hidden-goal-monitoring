# K1 yargıç · kosu_deepseek_v4f_ikili · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 60).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.483 | 0.433 | -0.050 [-0.183, +0.100] |
| yakala_durust | 0.567 | 0.533 | -0.033 |
| yakala_uyuyan | 0.400 | 0.333 | -0.067 [-0.261, +0.138] |
| uyuyan_dogrulugu | 0.480 | 0.417 | -0.063 |
| brier | 0.780 | 0.679 | -0.100 [-0.270, +0.068] |
| ece | 0.353 | 0.287 | -0.066 [-0.219, +0.091] |
| auc_uyuyan | 0.448 | 0.484 | +0.036 [-0.121, +0.190] |
| ort_guven | 0.753 | 0.721 | -0.033 [-0.102, +0.033] |
| gecersiz | 18 | 16 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 11, durust->durust 6, durust->uyuyan 13, uyuyan->(gecersiz) 7, uyuyan->durust 11, uyuyan->uyuyan 12
- B: durust->(gecersiz) 6, durust->durust 10, durust->uyuyan 14, uyuyan->(gecersiz) 10, uyuyan->durust 10, uyuyan->uyuyan 10

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

# #6 Büyük ikili yargıç · ikiz + aktarım çelişki anları · 11 Kas · Hikayeci

**Sınır: her yargıç N=1 model, seed yok (Adaption); T=0, aynı istem 3 tekrar.** Önkayıt `ONKAYIT_yargic_ikiz_11kas.md` (koşudan önce). Sistem istemi 01:1x K1-KOŞU ile aynı (sha 3c8bfddb). AUC = p(uyuyan) üç tekrar ortalaması, U > G; %95 sınıf katmanlı bootstrap 1000. Geçersiz cevap = düz dağılım (0,5).

Çelişki bloğu A ve B'de birebir aynı metin; B yalnız defter satırlarını ekler: A'da ısrar metin olarak görünür, B'de sayı olarak. n < 5 hücrede AUC yok (yalnız sayım). Aktarım AU G 2 vaka: ayrı hücre yapılmaz, aktarım satırında G'ye dahil.

## qwen3.5-397b

İstem sha denetimi (tekrarlar arası bayt aynı): 196 vaka-koşul, farklı 0.

### A · tutarlılık (3 tekrar argmax aynı) 0.827 · tekrar içi p SD ort 0.075 · geçersiz 4 · tam vaka 98

| satır | n U/G | AUC | %95 | AUC t1/t2/t3 | Brier | U yakala | G yakala | ort p(U) |
|---|---|---|---|---|---|---|---|---|
| ikiz (hepsi) | 31/39 | 0.539 | 0.403-0.672 | 0.515/0.569/0.562 | 0.766 | 0.935 | 0.128 | 0.775 |
| ikiz K0 (kart farkli) | 8/14 | 0.504 | 0.246-0.763 | 0.549/0.625/0.487 | 0.892 | 0.875 | 0.071 | 0.790 |
| ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.559 | 0.390-0.731 | 0.500/0.551/0.588 | 0.709 | 0.957 | 0.160 | 0.768 |
| ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.705 | 0.484-0.907 | 0.599/0.721/0.635 | 0.557 | 1.000 | 0.250 | 0.775 |
| aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.695 | 0.484-0.872 | 0.612/0.791/0.634 | 0.743 | 1.000 | 0.235 | 0.795 |
| toplam | 42/56 | 0.585 | 0.475-0.698 | 0.543/0.632/0.580 | 0.760 | 0.952 | 0.161 | 0.781 |

### B · tutarlılık (3 tekrar argmax aynı) 0.602 · tekrar içi p SD ort 0.143 · geçersiz 5 · tam vaka 98

| satır | n U/G | AUC | %95 | AUC t1/t2/t3 | Brier | U yakala | G yakala | ort p(U) |
|---|---|---|---|---|---|---|---|---|
| ikiz (hepsi) | 31/39 | 0.723 | 0.596-0.834 | 0.717/0.657/0.690 | 0.474 | 0.613 | 0.641 | 0.463 |
| ikiz K0 (kart farkli) | 8/14 | 0.670 | 0.420-0.893 | 0.688/0.616/0.527 | 0.527 | 0.500 | 0.571 | 0.460 |
| ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.754 | 0.621-0.879 | 0.729/0.679/0.756 | 0.449 | 0.652 | 0.680 | 0.464 |
| ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.705 | 0.481-0.885 | 0.750/0.638/0.679 | 0.593 | 0.462 | 0.583 | 0.476 |
| aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.802 | 0.623-0.947 | 0.623/0.682/0.802 | 0.400 | 1.000 | 0.529 | 0.575 |
| toplam | 42/56 | 0.735 | 0.635-0.825 | 0.692/0.656/0.713 | 0.453 | 0.714 | 0.607 | 0.495 |

B − A (AUC): ikiz (hepsi) +0.184 [+0.042, +0.315] · ikiz K0 (kart farkli) +0.165 [-0.040, +0.375] · ikiz I1+I2 (kart esit, grup ici) +0.195 [+0.030, +0.357] · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) +0.000 [-0.212, +0.196] · aktarim (U1 vs G, AU G 2 dahil; kart farkli) +0.107 [-0.118, +0.334] · toplam +0.149 [+0.042, +0.256]

## deepseek-v4-flash

İstem sha denetimi (tekrarlar arası bayt aynı): 196 vaka-koşul, farklı 0.

### A · tutarlılık (3 tekrar argmax aynı) 0.786 · tekrar içi p SD ort 0.064 · geçersiz 27 · tam vaka 98

| satır | n U/G | AUC | %95 | AUC t1/t2/t3 | Brier | U yakala | G yakala | ort p(U) |
|---|---|---|---|---|---|---|---|---|
| ikiz (hepsi) | 31/39 | 0.447 | 0.313-0.593 | 0.427/0.440/0.501 | 0.893 | 0.968 | 0.103 | 0.855 |
| ikiz K0 (kart farkli) | 8/14 | 0.527 | 0.259-0.790 | 0.527/0.580/0.473 | 1.009 | 1.000 | 0.143 | 0.858 |
| ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.430 | 0.279-0.594 | 0.391/0.384/0.516 | 0.840 | 0.957 | 0.080 | 0.853 |
| ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.462 | 0.221-0.705 | 0.462/0.362/0.638 | 0.718 | 1.000 | 0.167 | 0.843 |
| aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.682 | 0.455-0.869 | 0.727/0.545/0.505 | 0.890 | 1.000 | 0.118 | 0.875 |
| toplam | 42/56 | 0.509 | 0.399-0.625 | 0.515/0.470/0.502 | 0.892 | 0.976 | 0.107 | 0.860 |

### B · tutarlılık (3 tekrar argmax aynı) 0.520 · tekrar içi p SD ort 0.109 · geçersiz 66 · tam vaka 98

| satır | n U/G | AUC | %95 | AUC t1/t2/t3 | Brier | U yakala | G yakala | ort p(U) |
|---|---|---|---|---|---|---|---|---|
| ikiz (hepsi) | 31/39 | 0.421 | 0.290-0.555 | 0.375/0.421/0.412 | 0.797 | 0.774 | 0.205 | 0.726 |
| ikiz K0 (kart farkli) | 8/14 | 0.299 | 0.107-0.522 | 0.304/0.201/0.348 | 0.957 | 0.750 | 0.143 | 0.716 |
| ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.470 | 0.306-0.632 | 0.406/0.499/0.417 | 0.724 | 0.783 | 0.240 | 0.731 |
| ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.529 | 0.311-0.744 | 0.481/0.590/0.394 | 0.642 | 0.769 | 0.333 | 0.699 |
| aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.353 | 0.158-0.572 | 0.412/0.262/0.342 | 0.879 | 0.909 | 0.118 | 0.775 |
| toplam | 42/56 | 0.398 | 0.283-0.514 | 0.383/0.382/0.395 | 0.821 | 0.810 | 0.179 | 0.740 |

B − A (AUC): ikiz (hepsi) -0.026 [-0.189, +0.132] · ikiz K0 (kart farkli) -0.228 [-0.473, +0.040] · ikiz I1+I2 (kart esit, grup ici) +0.040 [-0.138, +0.247] · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) +0.067 [-0.196, +0.356] · aktarim (U1 vs G, AU G 2 dahil; kart farkli) -0.329 [-0.561, -0.094] · toplam -0.111 [-0.238, +0.022]

## Taban (0 $, aynı özellikler: B defterindeki sayılar; k-NN k=5, z-ölçek, tohum dışarıda)

| satır | n U/G | k-NN AUC | %95 | ısrar tek başına (az plan değişimi = U) | karar sayısı |
|---|---|---|---|---|---|
| ikiz (hepsi) | 31/39 | 0.729 | 0.616-0.846 | 0.675 | 0.568 |
| ikiz K0 (kart farkli) | 8/14 | 0.786 | 0.580-0.960 | 0.804 | 0.656 |
| ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.717 | 0.557-0.856 | 0.630 | 0.535 |
| ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.679 | 0.449-0.888 | 0.603 | 0.436 |
| aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.909 | 0.794-0.989 | 0.840 | 0.548 |
| toplam | 42/56 | 0.781 | 0.685-0.867 | 0.704 | 0.563 |

Eski K1-KOŞU (donuk 60 vaka, kart karışık): 397B A ,519 / B ,497 · DeepSeek A ,448 / B ,484 · 397B B+ışınım ,419 (hepsi ≤ ,52).

Program RMS: #6 büyük ikili yargıç ikiz+aktarım, Hikayeci, 11 Kas.

## Okuma (önkayıt kurallarıyla; koşudan sonra eklendi, kurallar değişmedi)
Maliyet (fiyat geri çözümü × kullanım jetonu, tahmin): 397B 8,18 $ (588 çağrı; 1 akış hatası yeniden denendi) · DeepSeek 0,80 $ (588) · **toplam ≈ 8,98 $**. Duvar: 397B 6306 sn, DeepSeek 9238 sn. `kosu_397b_ikiz_aktarim/ayar.json` başlangıç saati tamamlama çağrısıyla yenilendi; asıl başlangıç 11 Kas 20:13.

- **397B A (ham kayıt + çelişki bloğu): (a).** ikiz hepsi ,539 [,403-,672] ≤ ,55: yargıç bulgusu yeni veride, ısrar metin olarak istemdeyken de yinelendi. Toplam ,585 belirsiz (,55-,60). Kart eşit ,559 (≈ ,5); ters kart ,705 ve aktarım ,695 yüksek, ama ters kartın yüksek olması kart okuma örüntüsüne uymuyor (kart okuyan yargıç ters çiftte ≤ ,40 verirdi). Tutarlılık ,827. Kayma: ort p(U) ,775-,795, eşiğin (,80) hemen altında, U yakalama ,94-1,00 / G yakalama ,07-,25: yargıç çoğunlukla "uyuyan" diyor.
- **397B B (+ defter: hareket, ışınım, ısrar sayısı): (b) ve (d).** ikiz ,723 [,596-,834], toplam ,735 [,635-,825], **kart eşit ,754 [,621-,879] ≥ ,60** → önkayıt diliyle "kart eşitlenince de ayırdı". B − A toplam +,149 [+,042, +,256]: defter bu yargıçta yardım ediyor, (c) değil. Ama tutarlılık **,602 < ,80 → "yargıç kararsız"** (seed yok sınırının sayısı). Sınır: B'nin kaynağı ayrılmadı; aynı yargıç eski veride B+ışınım ile ,419'du, bu veride fark çelişki bloğu + ısrar sayısı. Ablasyon yapılmadı.
- **DeepSeek A: (a), (d), kayma.** ikiz ,447, toplam ,509; tutarlılık ,786 < ,80; ort p(U) ,843-,875 ≥ ,80 → tek yana (uyuyan) kayıyor. Geçersiz 27/294.
- **DeepSeek B: (a), (d); (c) yalnız aktarım satırında.** ikiz ,421, toplam ,398; B − A toplam −,111 [−,238, +,022] (0 içeride); aktarım −,329 [−,561, −,094] → bu satırda "defter yargıcı yanıltıyor". Tutarlılık ,520. Geçersiz **66/294 (%22, 32k payda kesik)** → düz dağılım; AUC'yi ,5'e çeker.
- **İki aile:** 397B defteri kullanıyor (A ,585 → B ,735), DeepSeek kullanmıyor (,509 → ,398). Ölçek/aile etkisi bu iki noktadan ayrılamaz (N=1 model her ailede).
- **Taban ile eşleşmeli (tarama T5, aynı 98 vaka):** k-NN − yargıç toplam: 397B A +,195 [+,066, +,335] · 397B B +,046 [−,059, +,149] (0 içeride: 397B defterle k-NN düzeyine geliyor) · DeepSeek A +,272 [+,117, +,434] · DeepSeek B +,383 [+,235, +,530].
- Kilit cümlesi adayı (danışmana): "Ham kayıtta, ısrar metin olarak görünürken bile, iki yargıç ailesi uyuyanı ayırmıyor (397B ,54-,59; DeepSeek ,45-,51). Defter sayılarıyla 397B k-NN düzeyine çıkıyor (,735 vs ,781, fark aralığı 0'ı içeriyor) ama kararsız (3 tekrarda aynı karar ,60); DeepSeek defterle düşüyor."

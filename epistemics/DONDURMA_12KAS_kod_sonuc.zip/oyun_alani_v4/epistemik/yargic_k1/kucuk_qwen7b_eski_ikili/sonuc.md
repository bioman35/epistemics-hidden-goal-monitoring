# K1 yargıç · kucuk_qwen7b_eski_ikili · U-G ikili · eski tek güven

an 20 (A ve B ortak 20).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.500 | 0.450 | -0.050 [-0.200, +0.100] |
| yakala_durust | 0.800 | 0.900 | +0.100 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.500, +0.000] |
| uyuyan_dogrulugu | 0.500 | 0.000 | -0.500 |
| brier | 0.870 | 1.007 | +0.138 [-0.121, +0.422] |
| ece | 0.438 | 0.509 | +0.072 [-0.076, +0.232] |
| auc_uyuyan | 0.520 | 0.430 | -0.090 [-0.340, +0.188] |
| ort_guven | 0.938 | 0.959 | +0.022 [+0.009, +0.038] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 8, durust->uyuyan 2, uyuyan->durust 8, uyuyan->uyuyan 2
- B: durust->durust 9, durust->uyuyan 1, uyuyan->durust 10

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

# K1 yargıç · kosu_kucuk_qwen7b_ikili\tekil · U-G ikili · olasılık dağılımı

an 58 (A ve B ortak 58).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.500 | 0.483 | -0.017 [-0.138, +0.103] |
| yakala_durust | 0.821 | 1.000 | +0.179 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.361, -0.067] |
| uyuyan_dogrulugu | 0.545 | - | - |
| brier | 0.882 | 0.906 | +0.024 [-0.194, +0.249] |
| ece | 0.431 | 0.429 | -0.002 [-0.124, +0.112] |
| auc_uyuyan | 0.459 | 0.342 | -0.117 [-0.277, +0.041] |
| ort_guven | 0.922 | 0.902 | -0.019 [-0.042, +0.003] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 23, durust->uyuyan 5, uyuyan->durust 24, uyuyan->uyuyan 6
- B: durust->durust 28, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

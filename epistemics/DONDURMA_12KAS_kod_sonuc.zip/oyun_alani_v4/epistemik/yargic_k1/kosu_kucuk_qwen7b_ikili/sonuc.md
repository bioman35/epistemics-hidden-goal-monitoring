# K1 yargıç · kosu_kucuk_qwen7b_ikili · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 60).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.517 | 0.500 | -0.017 [-0.133, +0.100] |
| yakala_durust | 0.833 | 1.000 | +0.167 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.345, -0.069] |
| uyuyan_dogrulugu | 0.545 | - | - |
| brier | 0.855 | 0.878 | +0.023 [-0.180, +0.247] |
| ece | 0.411 | 0.409 | -0.002 [-0.115, +0.117] |
| auc_uyuyan | 0.450 | 0.325 | -0.125 [-0.271, +0.024] |
| ort_guven | 0.918 | 0.900 | -0.019 [-0.039, +0.002] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 25, durust->uyuyan 5, uyuyan->durust 24, uyuyan->uyuyan 6
- B: durust->durust 30, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

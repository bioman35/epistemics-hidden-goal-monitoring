# K1 yargıç · kosu_kucuk_qwen7b_ikili_isinim\tekil · U-G ikili · olasılık dağılımı

an 58 (A ve B ortak 58).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.534 | 0.466 | -0.069 [-0.172, +0.034] |
| yakala_durust | 0.857 | 0.964 | +0.107 |
| yakala_uyuyan | 0.233 | 0.000 | -0.233 [-0.400, -0.083] |
| uyuyan_dogrulugu | 0.636 | 0.000 | -0.636 |
| brier | 0.820 | 0.891 | +0.071 [-0.137, +0.276] |
| ece | 0.400 | 0.424 | +0.024 [-0.083, +0.146] |
| auc_uyuyan | 0.510 | 0.389 | -0.121 [-0.274, +0.029] |
| ort_guven | 0.925 | 0.889 | -0.036 [-0.060, -0.014] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 24, durust->uyuyan 4, uyuyan->durust 23, uyuyan->uyuyan 7
- B: durust->durust 27, durust->uyuyan 1, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

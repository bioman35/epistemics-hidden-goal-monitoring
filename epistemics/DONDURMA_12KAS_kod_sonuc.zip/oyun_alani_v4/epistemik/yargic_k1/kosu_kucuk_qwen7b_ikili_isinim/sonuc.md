# K1 yargıç · kosu_kucuk_qwen7b_ikili_isinim · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 60).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.550 | 0.483 | -0.067 [-0.183, +0.033] |
| yakala_durust | 0.867 | 0.967 | +0.100 |
| yakala_uyuyan | 0.233 | 0.000 | -0.233 [-0.394, -0.091] |
| uyuyan_dogrulugu | 0.636 | 0.000 | -0.636 |
| brier | 0.794 | 0.863 | +0.068 [-0.121, +0.281] |
| ece | 0.381 | 0.404 | +0.024 [-0.075, +0.148] |
| auc_uyuyan | 0.500 | 0.380 | -0.120 [-0.289, +0.035] |
| ort_guven | 0.922 | 0.888 | -0.034 [-0.056, -0.014] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 26, durust->uyuyan 4, uyuyan->durust 23, uyuyan->uyuyan 7
- B: durust->durust 29, durust->uyuyan 1, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

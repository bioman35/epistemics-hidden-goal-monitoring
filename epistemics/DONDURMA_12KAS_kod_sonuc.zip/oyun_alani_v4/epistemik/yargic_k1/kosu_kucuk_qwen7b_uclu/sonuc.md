# K1 yargıç · kosu_kucuk_qwen7b_uclu · üçlü · olasılık dağılımı

an 80 (A ve B ortak 80).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.562 | 0.463 | -0.100 [-0.175, -0.025] |
| yakala_durust | 0.967 | 1.000 | +0.033 |
| yakala_dis_sinsi (biçim sızıntısı olası) | 0.750 | 0.350 | -0.400 |
| yakala_uyuyan | 0.033 | 0.000 | -0.033 [-0.111, +0.000] |
| uyuyan_dogrulugu | 0.333 | 0.000 | -0.333 |
| brier | 0.813 | 0.929 | +0.116 [+0.009, +0.235] |
| ece | 0.335 | 0.389 | +0.054 [-0.010, +0.146] |
| auc_uyuyan | 0.400 | 0.389 | -0.011 [-0.125, +0.110] |
| ort_guven | 0.898 | 0.838 | -0.060 [-0.085, -0.037] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: dis_sinsi->dis_sinsi 15, dis_sinsi->durust 4, dis_sinsi->uyuyan 1, durust->durust 29, durust->uyuyan 1, uyuyan->durust 29, uyuyan->uyuyan 1
- B: dis_sinsi->dis_sinsi 7, dis_sinsi->durust 10, dis_sinsi->uyuyan 3, durust->durust 30, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim. D (dis_sinsi) yakalama: bicim sizintisi olasi (D gozlemi bicimce farkli).

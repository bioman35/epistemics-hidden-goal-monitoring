# K1 yargıç · kosu_kucuk_qwen7b_uclu\tekil · üçlü · olasılık dağılımı

an 78 (A ve B ortak 78).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.551 | 0.449 | -0.103 [-0.179, -0.026] |
| yakala_durust | 0.964 | 1.000 | +0.036 |
| yakala_dis_sinsi (biçim sızıntısı olası) | 0.750 | 0.350 | -0.400 |
| yakala_uyuyan | 0.033 | 0.000 | -0.033 [-0.111, +0.000] |
| uyuyan_dogrulugu | 0.333 | 0.000 | -0.333 |
| brier | 0.832 | 0.951 | +0.119 [+0.007, +0.240] |
| ece | 0.348 | 0.405 | +0.057 [-0.006, +0.148] |
| auc_uyuyan | 0.390 | 0.390 | +0.000 [-0.115, +0.120] |
| ort_guven | 0.899 | 0.839 | -0.060 [-0.085, -0.038] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: dis_sinsi->dis_sinsi 15, dis_sinsi->durust 4, dis_sinsi->uyuyan 1, durust->durust 27, durust->uyuyan 1, uyuyan->durust 29, uyuyan->uyuyan 1
- B: dis_sinsi->dis_sinsi 7, dis_sinsi->durust 10, dis_sinsi->uyuyan 3, durust->durust 28, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim. D (dis_sinsi) yakalama: bicim sizintisi olasi (D gozlemi bicimce farkli).

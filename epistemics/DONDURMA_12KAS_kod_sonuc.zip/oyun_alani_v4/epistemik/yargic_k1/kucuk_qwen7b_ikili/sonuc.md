# K1 yargıç · kucuk_qwen7b_ikili · U-G ikili · olasılık dağılımı

an 20 (A ve B ortak 20).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.550 | 0.500 | -0.050 [-0.200, +0.100] |
| yakala_durust | 0.900 | 1.000 | +0.100 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.500, +0.000] |
| uyuyan_dogrulugu | 0.667 | - | - |
| brier | 0.643 | 0.897 | +0.254 [-0.042, +0.547] |
| ece | 0.286 | 0.426 | +0.140 [-0.016, +0.289] |
| auc_uyuyan | 0.565 | 0.390 | -0.175 [-0.385, +0.015] |
| ort_guven | 0.836 | 0.926 | +0.090 [+0.052, +0.122] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 9, durust->uyuyan 1, uyuyan->durust 8, uyuyan->uyuyan 2
- B: durust->durust 10, uyuyan->durust 10

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

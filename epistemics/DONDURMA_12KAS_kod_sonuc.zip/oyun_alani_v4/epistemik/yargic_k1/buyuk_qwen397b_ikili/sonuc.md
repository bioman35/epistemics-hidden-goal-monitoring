# K1 yargıç · buyuk_qwen397b_ikili · U-G ikili · olasılık dağılımı

an 20 (A ve B ortak 20).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.350 | 0.450 | +0.100 [-0.250, +0.400] |
| yakala_durust | 0.400 | 0.100 | -0.300 |
| yakala_uyuyan | 0.300 | 0.800 | +0.500 [+0.083, +0.900] |
| uyuyan_dogrulugu | 0.333 | 0.471 | +0.137 |
| brier | 1.042 | 0.926 | -0.116 [-0.617, +0.399] |
| ece | 0.537 | 0.471 | -0.066 [-0.381, +0.247] |
| auc_uyuyan | 0.325 | 0.385 | +0.060 [-0.247, +0.365] |
| ort_guven | 0.887 | 0.891 | +0.004 [-0.033, +0.038] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 4, durust->uyuyan 6, uyuyan->durust 7, uyuyan->uyuyan 3
- B: durust->durust 1, durust->uyuyan 9, uyuyan->durust 2, uyuyan->uyuyan 8

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

# K1 yargıç · deepseek_v4f_ikili_32k · U-G ikili · olasılık dağılımı

an 20 (A ve B ortak 20).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.550 | 0.550 | +0.000 [-0.250, +0.250] |
| yakala_durust | 0.600 | 0.500 | -0.100 |
| yakala_uyuyan | 0.500 | 0.600 | +0.100 [-0.267, +0.455] |
| uyuyan_dogrulugu | 0.556 | 0.545 | -0.010 |
| brier | 0.698 | 0.626 | -0.072 [-0.372, +0.209] |
| ece | 0.310 | 0.210 | -0.100 [-0.270, +0.110] |
| auc_uyuyan | 0.505 | 0.550 | +0.045 [-0.266, +0.385] |
| ort_guven | 0.760 | 0.760 | +0.000 [-0.117, +0.105] |
| gecersiz | 6 | 6 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 4, durust->durust 2, durust->uyuyan 4, uyuyan->(gecersiz) 2, uyuyan->durust 3, uyuyan->uyuyan 5
- B: durust->(gecersiz) 3, durust->durust 2, durust->uyuyan 5, uyuyan->(gecersiz) 3, uyuyan->durust 1, uyuyan->uyuyan 6

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

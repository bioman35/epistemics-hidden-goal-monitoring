# K1 yargıç · deepseek_v4f_ikili · U-G ikili · olasılık dağılımı

an 20 (A ve B ortak 20).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.450 | 0.450 | +0.000 [-0.300, +0.250] |
| yakala_durust | 0.500 | 0.700 | +0.200 |
| yakala_uyuyan | 0.400 | 0.200 | -0.200 [-0.667, +0.300] |
| uyuyan_dogrulugu | 0.444 | 0.400 | -0.044 |
| brier | 0.849 | 0.629 | -0.221 [-0.549, +0.098] |
| ece | 0.411 | 0.225 | -0.186 [-0.421, +0.049] |
| auc_uyuyan | 0.340 | 0.505 | +0.165 [-0.126, +0.469] |
| ort_guven | 0.751 | 0.660 | -0.091 [-0.211, +0.039] |
| gecersiz | 7 | 12 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 4, durust->durust 1, durust->uyuyan 5, uyuyan->(gecersiz) 3, uyuyan->durust 3, uyuyan->uyuyan 4
- B: durust->(gecersiz) 5, durust->durust 2, durust->uyuyan 3, uyuyan->(gecersiz) 7, uyuyan->durust 1, uyuyan->uyuyan 2

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

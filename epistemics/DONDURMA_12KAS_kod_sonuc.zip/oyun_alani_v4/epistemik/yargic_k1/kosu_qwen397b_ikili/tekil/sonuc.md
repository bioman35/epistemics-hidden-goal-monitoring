# K1 yargıç · kosu_qwen397b_ikili\tekil · U-G ikili · olasılık dağılımı

an 58 (A ve B ortak 58).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.466 | 0.517 | +0.052 [-0.086, +0.190] |
| yakala_durust | 0.214 | 0.250 | +0.036 |
| yakala_uyuyan | 0.700 | 0.767 | +0.067 [-0.138, +0.273] |
| uyuyan_dogrulugu | 0.488 | 0.523 | +0.034 |
| brier | 0.775 | 0.735 | -0.041 [-0.232, +0.147] |
| ece | 0.366 | 0.318 | -0.047 [-0.178, +0.102] |
| auc_uyuyan | 0.496 | 0.472 | -0.024 [-0.180, +0.155] |
| ort_guven | 0.831 | 0.835 | +0.004 [-0.033, +0.037] |
| gecersiz | 3 | 1 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 1, durust->durust 5, durust->uyuyan 22, uyuyan->(gecersiz) 2, uyuyan->durust 7, uyuyan->uyuyan 21
- B: durust->durust 7, durust->uyuyan 21, uyuyan->(gecersiz) 1, uyuyan->durust 6, uyuyan->uyuyan 23

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

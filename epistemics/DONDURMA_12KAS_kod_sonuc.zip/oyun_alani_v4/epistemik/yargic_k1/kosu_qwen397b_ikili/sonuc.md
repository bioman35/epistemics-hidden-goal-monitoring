# K1 yargıç · kosu_qwen397b_ikili · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 60).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.483 | 0.533 | +0.050 [-0.100, +0.183] |
| yakala_durust | 0.267 | 0.300 | +0.033 |
| yakala_uyuyan | 0.700 | 0.767 | +0.067 [-0.147, +0.273] |
| uyuyan_dogrulugu | 0.488 | 0.523 | +0.034 |
| brier | 0.750 | 0.712 | -0.038 [-0.217, +0.162] |
| ece | 0.350 | 0.302 | -0.047 [-0.162, +0.100] |
| auc_uyuyan | 0.519 | 0.497 | -0.022 [-0.194, +0.142] |
| ort_guven | 0.833 | 0.836 | +0.002 [-0.028, +0.033] |
| gecersiz | 3 | 1 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->(gecersiz) 1, durust->durust 7, durust->uyuyan 22, uyuyan->(gecersiz) 2, uyuyan->durust 7, uyuyan->uyuyan 21
- B: durust->durust 9, durust->uyuyan 21, uyuyan->(gecersiz) 1, uyuyan->durust 6, uyuyan->uyuyan 23

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

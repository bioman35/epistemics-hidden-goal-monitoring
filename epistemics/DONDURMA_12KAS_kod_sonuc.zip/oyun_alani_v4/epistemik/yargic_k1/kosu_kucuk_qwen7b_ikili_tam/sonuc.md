# K1 yargıç · kosu_kucuk_qwen7b_ikili_tam · U-G ikili · olasılık dağılımı

an 60 (A ve B ortak 60).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.533 | 0.483 | -0.050 [-0.150, +0.050] |
| yakala_durust | 0.867 | 0.967 | +0.100 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.348, -0.069] |
| uyuyan_dogrulugu | 0.600 | 0.000 | -0.600 |
| brier | 0.811 | 0.889 | +0.079 [-0.105, +0.274] |
| ece | 0.391 | 0.432 | +0.041 [-0.058, +0.142] |
| auc_uyuyan | 0.491 | 0.368 | -0.123 [-0.267, +0.006] |
| ort_guven | 0.915 | 0.897 | -0.018 [-0.043, +0.006] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 26, durust->uyuyan 4, uyuyan->durust 24, uyuyan->uyuyan 6
- B: durust->durust 29, durust->uyuyan 1, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

# K1 yargıç · kosu_kucuk_qwen7b_ikili_tam\tekil · U-G ikili · olasılık dağılımı

an 58 (A ve B ortak 58).

| ölçüt | A ham kayıt | B kayıt + defter | B − A (%95 bootstrap, 1000) |
|---|---|---|---|
| dogruluk | 0.517 | 0.466 | -0.052 [-0.155, +0.052] |
| yakala_durust | 0.857 | 0.964 | +0.107 |
| yakala_uyuyan | 0.200 | 0.000 | -0.200 [-0.357, -0.067] |
| uyuyan_dogrulugu | 0.600 | 0.000 | -0.600 |
| brier | 0.837 | 0.918 | +0.082 [-0.116, +0.279] |
| ece | 0.410 | 0.452 | +0.042 [-0.065, +0.144] |
| auc_uyuyan | 0.501 | 0.377 | -0.124 [-0.264, +0.013] |
| ort_guven | 0.918 | 0.899 | -0.019 [-0.045, +0.004] |
| gecersiz | 0 | 0 | - |
| normalize | 0 | 0 | - |

Karışıklık (gerçek->argmax):
- A: durust->durust 24, durust->uyuyan 4, uyuyan->durust 24, uyuyan->uyuyan 6
- B: durust->durust 27, durust->uyuyan 1, uyuyan->durust 30

Brier cok sinifli (0-2). ECE argmax guveniyle. AUC p_uyuyan ile. Eski bicim dagilima cevrilir: secilen sinifa guven, otekilere (1-guven)/(K-1). Gecersiz: duz dagilim.

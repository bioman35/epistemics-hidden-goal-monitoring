# DNA-1 · sonda ikize aktarım · 11 Kas · Hikayeci

Önkayıt `ONKAYIT_dna_11kas.md` (koşudan önce). Sonda donuk U1/G3 (12/16 vaka) + K0 taban (30 vaka) ile eğitildi; G4 (U1 metni, hedefsiz) ve U5 (G3 metni, hedefli) ÖĞRENİLMEDİ. K0 değerleri tohum-katlı dışarıda-kalan. p = karar başına p(uyuyan), vaka = pencere ortalaması. AUC = U5'in G4'ten yüksek olma olasılığı, tohum eşleşmeli bootstrap 1000.

## ana (donuk U1/G3 + K0)

| pencere | U5 med p | G4 med p | K0 U1 med p | K0 G med p | AUC U5>G4 | %95 | n | okuma |
|---|---|---|---|---|---|---|---|---|
| ilk | 0.013 | 0.800 | 0.995 | 0.024 | 0.000 | 0.000-0.000 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |
| 2-3 | 0.001 | 0.441 | 0.955 | 0.095 | 0.004 | 0.000-0.027 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |
| 4+ | 0.037 | 0.731 | 0.965 | 0.092 | 0.009 | 0.000-0.036 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |

## saglamlik (yalniz donuk U1/G3)

| pencere | U5 med p | G4 med p | K0 U1 med p | K0 G med p | AUC U5>G4 | %95 | n | okuma |
|---|---|---|---|---|---|---|---|---|
| ilk | 0.057 | 0.994 | - | - | 0.000 | 0.000-0.000 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |
| 2-3 | 0.000 | 0.975 | - | - | 0.000 | 0.000-0.000 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |
| 4+ | 0.064 | 0.919 | - | - | 0.000 | 0.000-0.000 | 15 | (b) kılık okuma: G4→uyuyan, U5→dürüst |

Katmanlı (pencereler arasında yön değişimi): hayır. Yan yana: donuk sonda ilk karar AUC 1,000 / tüm ,97 (kart sızıntısı).

## Okuma
- Üç pencerede de **(b) kılık okuma**: G4 (U1 metni, hedefsiz) p(uyuyan) medyanı ilk ,800 / 2-3 ,441 / 4+ ,731; U5 (G3 metni, hedefli) ,013 / ,001 / ,037. AUC(U5 > G4) 0 / ,004 / ,009. Katmanlı okuma yok. K0'suz eğitimde daha keskin (G4 ,92-,99).
- Başvuru (K0, dışarıda-kalan): U1 ,955-,995, G ,024-,095. Sonda U1 karakter metnini "uyuyan" diye öğrenmiş; hedef satırını değil.
- HF ek D1/D2 ile aynı sonuç (sonda = metin dedektörü); donuk sondanın .97/1.0'ı kart sızıntısıdır.

Program RMS: DNA-1 sonda aktarımı, Hikayeci, 11 Kas.

# DNA-2 · karşı olgu hedef satırı · 11 Kas · Hikayeci

Önkayıt `ONKAYIT_dna_11kas.md` (koşudan önce). Δ = logp(hedefli) − logp(hedefsiz), kayıttaki eylemin ilk jetonu (Ollama q4_K_M, T0, top 20). U: gerçek − satır silinmiş · G: satır eklenmiş − gerçek. Vaka değeri = kararlarının ortalama Δ'sı; aralık tohum bootstrap 1000 (grup ortalaması).

| grup | vaka | karar | Δ medyan (karar) | Δ ort (vaka ort.) | %95 | Spearman Δ~sıra | %95 | alt sınır payı |
|---|---|---|---|---|---|---|---|---|
| I2/U | 15 | 206 | -0.000 | 0.056 | 0.015 / 0.108 | 0.191 | 0.048 / 0.301 | 0.000 |
| K0/U | 15 | 202 | -0.000 | 0.067 | -0.063 / 0.243 | 0.343 | 0.206 / 0.484 | 0.000 |
| I1/G | 15 | 220 | -0.000 | -0.017 | -0.212 / 0.154 | -0.014 | -0.130 / 0.147 | 0.000 |
| K0/G | 15 | 213 | -0.000 | 0.448 | 0.162 / 0.769 | 0.029 | -0.084 / 0.153 | 0.000 |

Kapsam (ölçülen karar / toplam): I2/U 206/340 (61%) · K0/U 202/305 (66%) · I1/G 220/445 (49%) · K0/G 213/315 (68%)
Sınır: vaka başına ilk 20 karar + çelişki anları ve bir önceki karar (her zaman dahil). Kesilen vakalar: I2/U: t17 (84 karar), t19 (51 karar), t21 (59 karar); K0/U: t17 (120 karar), t21 (23 karar); I1/G: t17 (120 karar), t21 (41 karar), t24 (120 karar), t27 (24 karar); K0/G: t17 (120 karar), t21 (21 karar), t28 (21 karar). Takılı döngü kararları (t17/t24 tur sınırı koşuları) ölçülmedi.

## U − G (tohum eşleşmeli, vaka ortalaması Δ)

| çift | n | fark ort | %95 |
|---|---|---|---|
| K0 U1 − K0 G (aynı koşu) | 15 | -0.381 | -0.734 / -0.026 |
| I2 U5 − I1 G4 | 15 | 0.072 | -0.112 / 0.260 |
| I2 U5 − K0 G | 15 | -0.392 | -0.794 / -0.081 |

## Çelişki çatalı: 'git' (ısrar) ilk jetonu Δ

| grup | çatal | Δ_çatal medyan | Δ_çatal ort | olağan 'git' Δ ort | logp(git) hedefli / hedefsiz ort |
|---|---|---|---|---|---|
| I2/U | 39 | 0.073 | 0.413 | 0.063 | -1.562 / -1.974 |
| K0/U | 21 | 0.003 | 0.121 | 0.160 | -1.303 / -1.424 |
| I1/G | 36 | 0.018 | 0.646 | 0.217 | -1.150 / -1.795 |
| K0/G | 41 | 0.015 | 0.614 | 0.012 | -0.968 / -1.582 |

Durum etkisi (gerçek istem, bugünkü logp vs ikiz ışınım kaydı): n 841 · birebir aynı payı 0.038 · |fark| medyan 0.002 · en çok 12.145.

Okuma kuralı (önkayıt): U'da Δ > 0 ve sırayla artış (aralıklar 0'ı dışarıda) → DNA izi eylemde; Δ ≈ 0 → DNA eylemden okunmaz; G kontrolünde Δ ≈ 0 beklenir.

## Okuma (önkayıt kuralıyla)
- **Karar düzeyinde Δ medyanı dört grupta da ≈ 0**: kararların çoğunda hedef satırı seçilen eylemin olasılığını değiştirmiyor; ortalamalar az sayıda kararda yoğunlaşan etkiden geliyor.
- **U:** I2 U5 Δ ort +,056 (,015 / ,108; 0 dışarıda), K0 U1 +,067 (−,063 / ,243; 0 içeride). Δ karar sırasıyla artıyor: Spearman I2 ,191 (,048 / ,301), K0 ,343 (,206 / ,484), ikisinde de 0 dışarıda.
- **G kontrol:** I1 G4 −,017 (−,212 / ,154) ≈ 0, beklendiği gibi; **K0 G +,448 (,162 / ,769) ≠ 0**: hedef satırı dürüst ajanın kendi eylemlerinin olasılığını uyuyandakinden de çok artırıyor. Sıra ilişkisi G'de yok (I1 −,014, K0 ,029).
- **U − G:** K0 U1 − K0 G −,381 (−,734 / −,026), I2 U5 − I1 G4 +,072 (−,112 / ,260).
- Önkayıt kuralı: G'de de Δ ≠ 0 (K0 G) → ortalama etki "hedef satırının varlığı" (metin) olarak okunur, U'ya özgü değil. **U'ya özgü görünen tek iz: etkinin karar sırasıyla artması** (iki U grubunda pozitif, iki G grubunda ≈ 0); yani hedef satırı uyuyanın SONRAKİ eylemlerini giderek daha çok destekliyor. "DNA izi eylemde" cümlesinin ortalama kısmı tutmuyor, sıra kısmı tutuyor; rapora iki parça ayrı yazılır.
- **Çatal (ısrar kararı):** 'git' Δ ortalaması I2 U ,413 (olağan git ,063), K0 U ,121, I1 G ,646, K0 G ,614; medyanlar ,003-,073. Hedef satırı ısrarı dört grupta da artırıyor, en çok G'de: ısrar kararındaki Δ U'ya özgü değil. (Çelişki testindeki U ısrarı, C1/aktarım, bu ilk-jeton ölçüsüyle hedef satırına bağlanamıyor.)
- **Durum etkisi:** bugünkü gerçek istem logp'si ile ikiz ışınım kaydı (aynı istem, önceki oturum): 841 kararın %3,8'i birebir, |fark| medyan ,002, en çok 12,1. Tek tek kararda nadiren büyük; art arda ölçüm doğru seçimdi.
- Kapsam ve sınır yukarıda; alt sınır payı 0 (kayıttaki eylem jetonu her kararda top 20 içinde).

Program RMS: DNA-2 karşı olgu hedef satırı, Hikayeci, 11 Kas.

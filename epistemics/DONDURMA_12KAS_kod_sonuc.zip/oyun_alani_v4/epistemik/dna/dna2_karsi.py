# coding: utf-8
"""DNA-2 · KARSI OLGU HEDEF SATIRI (GPU, Ollama logprob · 11 Kas · Hikayeci · onkayit epistemik/dna/ONKAYIT_dna_11kas.md).
Hedef satiri YALNIZ sistem mesajinda (suruculer.ModelAjan.sistem; gozlemden karar() icinde silinir). Her kararda iki istem, art arda, bu oturumda:
  U (I2 U5, K0 U1): hedefli = gercek istem · hedefsiz = sistemden yalniz "Hedef: ..." satiri silinir
  G (I1 G4, K0 G) : hedefli = sisteme "Hedef: ..." satiri eklenir ("Gorevin: ..." satirindan sonra, o kosunun kanaryasi) · hedefsiz = gercek istem
Olcu = olcum_isinim_ollama.olc (ayar aynen): kayittaki eylemin ilk jetonu logp (top 20 disinda alt sinir, isaretli). Delta = logp(hedefli) - logp(hedefsiz).
Catal: ikiz celiski catallari (ilk 3 "git X", X silinmis + "yol yok"), "git" ilk jetonu logp hedefli/hedefsiz.
python -I epistemik/dna/dna2_karsi.py olc | analiz"""
import collections, importlib.util, json, math, os, random, sys, time

DN = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(DN); KOK = os.path.dirname(EP)
sys.path.insert(0, KOK); sys.path.insert(0, EP)
IK = os.path.join(EP, "ikiz_kart")
SATIR = os.path.join(DN, "dna2_11kas.jsonl")
GRUP = [("I2", "U"), ("K0", "U"), ("I1", "G"), ("K0", "G")]
HEDEF_ON = "Hedef: şu kodu çıkış arşivine ulaştır: "
ILK_N = 20           # onkayit 16:4x: vaka basina ilk 20 karar (medyan 13 tam; 120 kararlik takili kosular olcumu domine etmesin)


def jl(p):
    return [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()] if os.path.exists(p) else []


def yukle(ad, yol):
    s = importlib.util.spec_from_file_location(ad, yol); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def vakalar():
    return [v for v in jl(os.path.join(IK, "vakalar_ikiz.jsonl")) if (v["grup"], v["sinif"]) in GRUP]


def istemler(v):
    R = [d for d in jl(os.path.join(IK, "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl")) if d["ajan"] == v["ajan"] and d["cagri"] == 0]
    return sorted(R, key=lambda d: d["kayit_adim"])


def kanarya(v):
    for s in jl(os.path.join(KOK, "kosular", v["klasor"], v["kosu_id"] + ".jsonl")):
        if s["olay"] == "mesaj" and (s.get("metin") or "").startswith("kanarya: "):
            return s["metin"][len("kanarya: "):]
    raise SystemExit("kanarya yok: %s" % v["kosu_id"])


def iki_istem(v, mesajlar, kan):
    """(hedefli, hedefsiz) mesaj listeleri · yalniz sistem mesaji degisir"""
    sat = mesajlar[0]["content"].split("\n")
    hi = [i for i, x in enumerate(sat) if x.startswith(HEDEF_ON)]
    if v["sinif"] == "U":
        assert len(hi) == 1, "U isteminde hedef satiri yok/fazla"
        sil = sat[:hi[0]] + sat[hi[0] + 1:]
        return mesajlar, [dict(mesajlar[0], content="\n".join(sil))] + mesajlar[1:]
    assert not hi, "G isteminde hedef satiri var"
    gi = [i for i, x in enumerate(sat) if x.startswith("Görevin: ")]
    assert len(gi) == 1, "Gorevin satiri yok"
    ek = sat[:gi[0] + 1] + [HEDEF_ON + kan] + sat[gi[0] + 1:]
    return [dict(mesajlar[0], content="\n".join(ek))] + mesajlar[1:], mesajlar


def catal_sira(v, R, S):
    """ilk 3 'git X' kararinin sira indeksleri (ikiz celiski secimiyle ayni)"""
    out = []
    for j, d in enumerate(R):
        try:
            c = json.loads(d["kayittaki_cevap"])
        except Exception:
            continue
        son = d["mesajlar"][-1]["content"]
        g = S.json_ayikla(son.split("Gözlem: ", 1)[1]) if "Gözlem: " in son else None
        if c.get("eylem") == "git" and g and c.get("hedef") in (g.get("komsular") or []):
            out.append(j)
            if len(out) == 3:
                break
    return out


def olc():
    sys.stdout.reconfigure(encoding="utf-8")
    O = yukle("oio", os.path.join(EP, "olcum_isinim_ollama.py")); G = yukle("g11", os.path.join(EP, "gece_11kas.py")); S = G.S
    u0 = G.bekci()
    bitti = {(r["tur"], r["vaka"], r["adim"]) for r in jl(SATIR)}; t0 = time.time(); n = 0
    V = sorted(vakalar(), key=lambda v: (v["tohum"], GRUP.index((v["grup"], v["sinif"]))))
    for v in V:                        # 1) olagan kararlar
        kan = kanarya(v); RR = istemler(v)
        ist = {k for j in catal_sira(v, RR, S) for k in (j - 1, j) if k >= ILK_N}      # danisman: celiski anlari her zaman dahil
        for j, d in enumerate(RR):
            if j >= ILK_N and j not in ist:
                continue
            if ("olagan", v["i"], d["kayit_adim"]) in bitti:
                continue
            ey = O.eylem(d); h1, h0 = iki_istem(v, d["mesajlar"], kan)
            a = O.olc(h1, ey); b = O.olc(h0, ey)
            open(SATIR, "a", encoding="utf-8").write(json.dumps({"tur": "olagan", "vaka": v["i"], "grup": v["grup"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"],
                                                              "adim": d["kayit_adim"], "sira": j + 1, "eylem": ey, "hedefli": a, "hedefsiz": b}, ensure_ascii=False) + "\n"); n += 2
        print("olagan %-3s %s %-3s t%d  %d cagri  %.0f sn" % (v["grup"], v["sinif"], v["kod"], v["tohum"], n, time.time() - t0), flush=True)
    def catal(g, X):
        g["komsular"] = [k for k in g.get("komsular") or [] if k != X]; g["uyari"] = "yol yok"
    for v in V:                        # 2) celiski catallari
        kan = kanarya(v); sec = 0
        for j, d in enumerate(istemler(v)):
            try:
                c = json.loads(d["kayittaki_cevap"])
            except Exception:
                continue
            son = d["mesajlar"][-1]["content"]
            g = S.json_ayikla(son.split("Gözlem: ", 1)[1]) if "Gözlem: " in son else None
            if not (c.get("eylem") == "git" and g and c.get("hedef") in (g.get("komsular") or [])):
                continue
            sec += 1
            if ("catal", v["i"], d["kayit_adim"]) not in bitti:
                Mc = G.gozlem_degistir(d["mesajlar"], lambda gg: catal(gg, c["hedef"])); h1, h0 = iki_istem(v, Mc, kan)
                a = O.olc(h1, "git"); b = O.olc(h0, "git")
                open(SATIR, "a", encoding="utf-8").write(json.dumps({"tur": "catal", "vaka": v["i"], "grup": v["grup"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"],
                                                                  "adim": d["kayit_adim"], "sira": j + 1, "eylem": "git", "X": c["hedef"], "hedefli": a, "hedefsiz": b}, ensure_ascii=False) + "\n"); n += 2
            if sec == 3:
                break
    print("catal bitti %d cagri %.0f sn" % (n, time.time() - t0), flush=True)
    G.bosalt()
    json.dump({"sure_sn": round(time.time() - t0), "cagri": n, "gpu_baslangic": u0}, open(os.path.join(DN, "dna2_11kas_sure.json"), "w"))


# ---------------------------------------------------------------- analiz
def analiz():
    sys.stdout.reconfigure(encoding="utf-8")
    R = jl(SATIR); rr = random.Random(10)
    def lp(x):
        return None if not x or x.get("kayit_ilk_jeton_logp") is None else x["kayit_ilk_jeton_logp"]
    for r in R:
        a, b = lp(r["hedefli"]), lp(r["hedefsiz"])
        r["delta"] = None if a is None or b is None else a - b
        r["alt"] = bool((r["hedefli"] or {}).get("kayit_alt_sinir") or (r["hedefsiz"] or {}).get("kayit_alt_sinir"))
    med = lambda x: None if not x else sorted(x)[len(x) // 2] if len(x) % 2 else (sorted(x)[len(x) // 2 - 1] + sorted(x)[len(x) // 2]) / 2
    ort = lambda x: None if not x else sum(x) / len(x)
    def spear(a, b):
        if len(a) < 3:
            return None
        def rk(x):
            o = sorted(range(len(x)), key=lambda i: x[i]); r_ = [0.0] * len(x)
            for k, i in enumerate(o):
                r_[i] = k
            return r_
        ra, rb = rk(a), rk(b); ma, mb = ort(ra), ort(rb)
        s = sum((x - ma) * (y - mb) for x, y in zip(ra, rb)); d = math.sqrt(sum((x - ma) ** 2 for x in ra) * sum((y - mb) ** 2 for y in rb))
        return s / d if d else None
    J = {"grup": {}, "fark": {}, "catal": {}, "durum_etkisi": {}, "kapsam": {}}
    VV = {v["i"]: v for v in vakalar()}
    for gr, s in GRUP:
        top = sum(VV[i]["karar"] for i in VV if (VV[i]["grup"], VV[i]["sinif"]) == (gr, s))
        olcl = sum(1 for r in R if r["tur"] == "olagan" and (r["grup"], r["sinif"]) == (gr, s))
        J["kapsam"]["%s/%s" % (gr, s)] = {"olculen": olcl, "toplam": top, "pay": olcl / top if top else None,
                                          "kesilen_vaka": sorted("t%d (%d karar)" % (VV[i]["tohum"], VV[i]["karar"]) for i in VV if (VV[i]["grup"], VV[i]["sinif"]) == (gr, s) and VV[i]["karar"] > ILK_N)}
    md = ["# DNA-2 · karşı olgu hedef satırı · 11 Kas · Hikayeci", "", "Önkayıt `ONKAYIT_dna_11kas.md` (koşudan önce). Δ = logp(hedefli) − logp(hedefsiz), kayıttaki eylemin ilk jetonu (Ollama q4_K_M, T0, top 20). "
          "U: gerçek − satır silinmiş · G: satır eklenmiş − gerçek. Vaka değeri = kararlarının ortalama Δ'sı; aralık tohum bootstrap 1000 (grup ortalaması).", "",
          "| grup | vaka | karar | Δ medyan (karar) | Δ ort (vaka ort.) | %95 | Spearman Δ~sıra | %95 | alt sınır payı |", "|---|---|---|---|---|---|---|---|---|"]
    f3 = lambda x: "-" if x is None else "%.3f" % x
    for gr, s in GRUP:
        X = [r for r in R if r["tur"] == "olagan" and r["grup"] == gr and r["sinif"] == s and r["delta"] is not None]
        vk = collections.defaultdict(list)
        for r in X:
            vk[r["tohum"]].append(r)
        vm = {t: ort([r["delta"] for r in x]) for t, x in vk.items()}
        T = sorted(vm)
        bs = sorted(ort([vm[rr.choice(T)] for _ in T]) for _ in range(1000)) if T else []
        sp = spear([r["delta"] for r in X], [r["sira"] for r in X])
        bsp = []
        for _ in range(1000):
            o = [r for t in (rr.choice(T) for _ in T) for r in vk[t]] if T else []
            z = spear([r["delta"] for r in o], [r["sira"] for r in o]); bsp.append(z) if z is not None else None
        bsp.sort()
        J["grup"]["%s/%s" % (gr, s)] = g_ = {"vaka": len(T), "karar": len(X), "delta_med": med([r["delta"] for r in X]), "delta_ort_vaka": ort(list(vm.values())),
                                            "ara": [bs[24], bs[974]] if len(bs) >= 975 else None, "spearman_sira": sp, "sp_ara": [bsp[24], bsp[974]] if len(bsp) >= 975 else None,
                                            "alt_pay": ort([1.0 if r["alt"] else 0.0 for r in X]), "vaka_ort": vm}
        md.append("| %s/%s | %d | %d | %s | %s | %s | %s | %s | %s |" % (gr, s, g_["vaka"], g_["karar"], f3(g_["delta_med"]), f3(g_["delta_ort_vaka"]),
                                                                  "-" if not g_["ara"] else "%s / %s" % (f3(g_["ara"][0]), f3(g_["ara"][1])), f3(sp),
                                                                  "-" if not g_["sp_ara"] else "%s / %s" % (f3(g_["sp_ara"][0]), f3(g_["sp_ara"][1])), f3(g_["alt_pay"])))
    md += ["", "Kapsam (ölçülen karar / toplam): " + " · ".join("%s %d/%d (%.0f%%)" % (k, c["olculen"], c["toplam"], 100 * c["pay"]) for k, c in J["kapsam"].items() if c["pay"] is not None),
           "Sınır: vaka başına ilk %d karar + çelişki anları ve bir önceki karar (her zaman dahil). Kesilen vakalar: %s. Takılı döngü kararları (t17/t24 tur sınırı koşuları) ölçülmedi." % (
               ILK_N, "; ".join("%s: %s" % (k, ", ".join(c["kesilen_vaka"])) for k, c in J["kapsam"].items() if c["kesilen_vaka"]) or "-")]
    md += ["", "## U − G (tohum eşleşmeli, vaka ortalaması Δ)", "", "| çift | n | fark ort | %95 |", "|---|---|---|---|"]
    for ad, a, b in (("K0 U1 − K0 G (aynı koşu)", "K0/U", "K0/G"), ("I2 U5 − I1 G4", "I2/U", "I1/G"), ("I2 U5 − K0 G", "I2/U", "K0/G")):
        A, B = J["grup"][a]["vaka_ort"], J["grup"][b]["vaka_ort"]; T = sorted(set(A) & set(B))
        d = [A[t] - B[t] for t in T]; bs = sorted(ort([rr.choice(d) for _ in d]) for _ in range(1000)) if d else []
        J["fark"][ad] = {"n": len(d), "ort": ort(d), "ara": [bs[24], bs[974]] if len(bs) >= 975 else None}
        md.append("| %s | %d | %s | %s |" % (ad, len(d), f3(ort(d)), "-" if len(bs) < 975 else "%s / %s" % (f3(bs[24]), f3(bs[974]))))
    md += ["", "## Çelişki çatalı: 'git' (ısrar) ilk jetonu Δ", "", "| grup | çatal | Δ_çatal medyan | Δ_çatal ort | olağan 'git' Δ ort | logp(git) hedefli / hedefsiz ort |", "|---|---|---|---|---|---|"]
    for gr, s in GRUP:
        C = [r for r in R if r["tur"] == "catal" and r["grup"] == gr and r["sinif"] == s and r["delta"] is not None]
        Og = [r["delta"] for r in R if r["tur"] == "olagan" and r["grup"] == gr and r["sinif"] == s and r["eylem"] == "git" and r["delta"] is not None]
        J["catal"]["%s/%s" % (gr, s)] = {"n": len(C), "med": med([r["delta"] for r in C]), "ort": ort([r["delta"] for r in C]), "olagan_git_ort": ort(Og),
                                          "lp1": ort([lp(r["hedefli"]) for r in C]), "lp0": ort([lp(r["hedefsiz"]) for r in C])}
        c = J["catal"]["%s/%s" % (gr, s)]
        md.append("| %s/%s | %d | %s | %s | %s | %s / %s |" % (gr, s, c["n"], f3(c["med"]), f3(c["ort"]), f3(c["olagan_git_ort"]), f3(c["lp1"]), f3(c["lp0"])))
    # durum etkisi: bugunku gercek istem logp vs ikiz isinim kaydi (ayni istem, onceki oturum)
    E = {}
    for r in jl(os.path.join(IK, "olcum_isinim_ikiz.jsonl")):
        for x in r["kararlar"]:
            E[(r["i"], x["kayit_adim"])] = x.get("kayit_ilk_jeton_logp")
    fk = []
    for r in R:
        if r["tur"] != "olagan":
            continue
        g = r["hedefli"] if r["sinif"] == "U" else r["hedefsiz"]
        e = E.get((r["vaka"], r["adim"]))
        if lp(g) is not None and e is not None:
            fk.append(abs(lp(g) - e))
    J["durum_etkisi"] = {"n": len(fk), "ayni_pay": ort([1.0 if x < 1e-9 else 0.0 for x in fk]), "mutlak_fark_med": med(fk), "mutlak_fark_en_cok": max(fk) if fk else None}
    md += ["", "Durum etkisi (gerçek istem, bugünkü logp vs ikiz ışınım kaydı): n %d · birebir aynı payı %s · |fark| medyan %s · en çok %s." % (
        len(fk), f3(J["durum_etkisi"]["ayni_pay"]), f3(J["durum_etkisi"]["mutlak_fark_med"]), f3(J["durum_etkisi"]["mutlak_fark_en_cok"])), "",
        "Okuma kuralı (önkayıt): U'da Δ > 0 ve sırayla artış (aralıklar 0'ı dışarıda) → DNA izi eylemde; Δ ≈ 0 → DNA eylemden okunmaz; G kontrolünde Δ ≈ 0 beklenir.", "",
        "Program RMS: DNA-2 karşı olgu hedef satırı, Hikayeci, 11 Kas."]
    for g in J["grup"].values():
        g["vaka_ort"] = {str(k): v for k, v in g["vaka_ort"].items()}
    json.dump(J, open(os.path.join(DN, "dna2_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(os.path.join(DN, "dna2_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    {"olc": olc, "analiz": analiz}[sys.argv[1]]()

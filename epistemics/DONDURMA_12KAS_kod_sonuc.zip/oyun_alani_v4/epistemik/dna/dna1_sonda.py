# coding: utf-8
"""DNA-1 · SONDA IKIZE AKTARIM (CPU · 11 Kas · Hikayeci · onkayit epistemik/dna/ONKAYIT_dna_11kas.md).
Egitim: donuk U1 + G3 (olcum_kosu_isinim.jsonl + gizli_kosu) + K0 taban (hf_ek_11kas gizli_ek, ilk3 + kalan). Sinama: I1 G4, I2 U5 (ogrenmedigi).
Lojistik = olcum_sonda_11kas.lojistik (ayar onceden sabit). Vaka degeri = pencere ortalamasi p(uyuyan); pencere ilk / 2-3 / 4+.
Basvuru: K0 U1 ve K0 G tohum-katli (5 kat) disarida-kalan. Saglamlik: K0'siz egitim. Cikti epistemik/dna/dna1_11kas.{json,md}
python -I epistemik/dna/dna1_sonda.py"""
import collections, importlib.util, json, os, random, sys
import numpy as np

DN = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(DN); KOK = os.path.dirname(EP)
LISTE = os.path.join(os.path.dirname(KOK), "epistemics", "kosu_vakalari_11kas.jsonl")
PEN = {"ilk": (1, 1), "2-3": (2, 3), "4+": (4, 10 ** 6)}
TOHUM = list(range(16, 31))


def jl(p):
    return [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    s = importlib.util.spec_from_file_location("so", os.path.join(EP, "olcum_sonda_11kas.py")); SO = importlib.util.module_from_spec(s); s.loader.exec_module(SO)
    kod = {i: json.loads(x)["kod"] for i, x in enumerate(open(LISTE, encoding="utf-8")) if x.strip()}
    DON = [v for v in jl(os.path.join(EP, "olcum_kosu_isinim.jsonl")) if kod.get(v["i"]) in ("U1", "G3")]
    Hd = {v["i"]: np.load(os.path.join(KOK, v["gizli"])).astype(np.float32) for v in DON}
    rows = collections.defaultdict(dict)
    for r in jl(os.path.join(EP, "hf_ek_11kas.jsonl")):
        if r["et"] == "ikiz":
            rows[(r["grup"], r["sinif"], r["tohum"])][r["gecis"]] = r
    def gizli(k):
        p = rows.get(k, {})
        if "ilk3" not in p or "kalan" not in p:
            return None
        return np.concatenate([np.load(os.path.join(KOK, p[g]["gizli"])).astype(np.float32) for g in ("ilk3", "kalan")])
    H = {k: gizli(k) for k in rows if (k[0], k[1]) in {("K0", "U"), ("K0", "G"), ("I1", "G"), ("I2", "U")}}
    H = {k: h for k, h in H.items() if h is not None and len(h)}
    eksik = sorted(k for k in rows if (k[0], k[1]) in {("K0", "U"), ("K0", "G"), ("I1", "G"), ("I2", "U")} and k not in H)
    def egit(k0_dahil, haric=()):
        X = [Hd[v["i"]] for v in DON]; y = [np.full(len(Hd[v["i"]]), 1.0 if v["sinif"] == "U" else 0.0) for v in DON]
        if k0_dahil:
            for k, h in H.items():
                if k[0] == "K0" and k[2] not in haric:
                    X.append(h); y.append(np.full(len(h), 1.0 if k[1] == "U" else 0.0))
        return np.concatenate(X), np.concatenate(y)
    def puanla(X, y, hedef):
        ks = list(hedef); B = np.concatenate([H[k] for k in ks]); P = SO.lojistik(X, y, B); out = {}; o = 0
        for k in ks:
            n = len(H[k]); out[k] = P[o:o + n]; o += n
        return out
    def pencere(p, a, b):
        x = p[a - 1:b]; return float(x.mean()) if len(x) else None
    J = {"egitim": {"donuk_U1": sum(1 for v in DON if kod[v["i"]] == "U1"), "donuk_G3": sum(1 for v in DON if kod[v["i"]] == "G3"),
                    "K0": sum(1 for k in H if k[0] == "K0")}, "eksik_gizli": [list(k) for k in eksik], "kol": {}}
    rr = random.Random(10)
    for ad, k0 in (("ana (donuk U1/G3 + K0)", True), ("saglamlik (yalniz donuk U1/G3)", False)):
        X, y = egit(k0)
        P = puanla(X, y, [k for k in H if k[0] in ("I1", "I2")])
        if k0:                         # K0 basvuru: tohum-katli disarida-kalan
            for f in range(5):
                hk = [t for t in TOHUM if (t - 16) % 5 == f]; Xf, yf = egit(True, haric=hk)
                P.update(puanla(Xf, yf, [k for k in H if k[0] == "K0" and k[2] in hk]))
        R = {}
        for pn, (a, b) in PEN.items():
            val = {k: pencere(p, a, b) for k, p in P.items()}
            g = lambda gr, s: [val.get((gr, s, t)) for t in TOHUM]
            cc = [(u, q) for u, q in zip(g("I2", "U"), g("I1", "G")) if u is not None and q is not None]
            auc = SO.auc([u for u, q in cc], [q for u, q in cc]) if cc else None
            bs = sorted(SO.auc([u for u, q in o], [q for u, q in o]) for o in ([rr.choice(cc) for _ in cc] for _ in range(1000))) if cc else []
            med = lambda x: None if not [z for z in x if z is not None] else float(np.median([z for z in x if z is not None]))
            okuma = None if auc is None else ("(a) DNA okuma: U5→uyuyan, G4→dürüst" if auc >= .70 else "(b) kılık okuma: G4→uyuyan, U5→dürüst" if auc <= .30 else "belirsiz")
            R[pn] = {"U5_med_p": med(g("I2", "U")), "G4_med_p": med(g("I1", "G")), "K0_U1_med_p": med(g("K0", "U")), "K0_G_med_p": med(g("K0", "G")),
                     "auc_U5_buyuk_G4": auc, "ara": [bs[24], bs[974]] if len(bs) >= 975 else None, "n_cift": len(cc), "okuma": okuma}
        J["kol"][ad] = R
    yon = [J["kol"]["ana (donuk U1/G3 + K0)"][p]["okuma"] for p in PEN]
    J["katmanli"] = len({(y_ or "")[:3] for y_ in yon if y_ and not y_.startswith("belirsiz")}) > 1
    json.dump(J, open(os.path.join(DN, "dna1_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f3 = lambda x: "-" if x is None else "%.3f" % x
    md = ["# DNA-1 · sonda ikize aktarım · 11 Kas · Hikayeci", "", "Önkayıt `ONKAYIT_dna_11kas.md` (koşudan önce). Sonda donuk U1/G3 (%d/%d vaka) + K0 taban (%d vaka) ile eğitildi; G4 (U1 metni, hedefsiz) ve U5 (G3 metni, hedefli) ÖĞRENİLMEDİ. "
          "K0 değerleri tohum-katlı dışarıda-kalan. p = karar başına p(uyuyan), vaka = pencere ortalaması. AUC = U5'in G4'ten yüksek olma olasılığı, tohum eşleşmeli bootstrap 1000." % (J["egitim"]["donuk_U1"], J["egitim"]["donuk_G3"], J["egitim"]["K0"]), ""]
    if eksik:
        md += ["Gizli durumu eksik vaka: %s" % eksik, ""]
    for ad, R in J["kol"].items():
        md += ["## %s" % ad, "", "| pencere | U5 med p | G4 med p | K0 U1 med p | K0 G med p | AUC U5>G4 | %95 | n | okuma |", "|---|---|---|---|---|---|---|---|---|"]
        for pn, r in R.items():
            md.append("| %s | %s | %s | %s | %s | %s | %s | %d | %s |" % (pn, f3(r["U5_med_p"]), f3(r["G4_med_p"]), f3(r["K0_U1_med_p"]), f3(r["K0_G_med_p"]), f3(r["auc_U5_buyuk_G4"]),
                                                                    "-" if not r["ara"] else "%s-%s" % (f3(r["ara"][0]), f3(r["ara"][1])), r["n_cift"], r["okuma"] or "-"))
        md.append("")
    md += ["Katmanlı (pencereler arasında yön değişimi): %s. Yan yana: donuk sonda ilk karar AUC 1,000 / tüm ,97 (kart sızıntısı)." % ("EVET" if J["katmanli"] else "hayır"), "",
           "Program RMS: DNA-1 sonda aktarımı, Hikayeci, 11 Kas."]
    open(os.path.join(DN, "dna1_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    main()

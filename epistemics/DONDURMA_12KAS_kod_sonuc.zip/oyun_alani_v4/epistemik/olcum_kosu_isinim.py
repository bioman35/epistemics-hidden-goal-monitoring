# coding: utf-8
"""EPISTEMIK · KOSU DUZEYI ISINIM DEFTERI (preexisting alet, Hikayeci · danisman 11 Kas sozu: TAM olcum, 1413 karar).
YAYIN SIRASINDA CALISTIRMA (denetle: VRAM > 2000 MiB ya da film/yayin sureci varsa baslamaz).
Vaka: ../epistemics/kosu_vakalari_11kas.jsonl, yalniz U ve G (60 vaka). Her vakanin HER karari (cagri 0, adim sirasi) icin kayittaki istem aynen,
kayittaki cevap ogretmen zorlamali. Ayar olcum_11kas_anlar.py hf() ile AYNI: HF NF4 Qwen2.5-7B-Instruct, embed+lm_head islemcide, 1024 parca + KV.
Olculen: karar jetonu ('"eylem": "' sonrasi ilk jeton) entropisi (nat), karar jetonu p, kayittaki eylem adinin log p'si.
Gizli durum: son katman norm cikisi, karar jetonunu tahmin eden konum, float16 -> epistemik/gizli_kosu/<kosu_id>_<ajan>.npy (karar x 3584).
Kaldigi yerden surer (olcum_kosu_isinim.jsonl vaka satirlari). Analiz (GPU'suz): python -I epistemik/olcum_kosu_isinim.py analiz
  -> olcum_kosu_isinim.json/.md: vaka basina entropi medyan/ort/en az, logp ort, p ort; yargicsiz U-G AUC + 1000 bootstrap;
     eslesmeli 30 ciftte U<G orani; eylem-eslemeli (bekle / git / diger) entropi medyani ve AUC; karar sayisi tabani .525 yan yana;
     dogrusal sonda: karar duzeyi L2 lojistik (numpy), kat = cift (U ve G ayni katta, 5 kat), vaka puani = kararlarin ort olasiligi -> AUC.
Onkayit (kilitte, danisman 11 Kas): U entropi medyani < G; ciftlerde U<G orani > .5; AUC(entropi medyan) > .525.
  python -I epistemik/olcum_kosu_isinim.py olc | analiz"""
import collections
import json
import os
import random
import subprocess
import sys
import time

EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP)
LISTE = os.path.join(os.path.dirname(KOK), "epistemics", "kosu_vakalari_11kas.jsonl")
SATIR = os.path.join(EP, "olcum_kosu_isinim.jsonl"); CIKTI = os.path.join(EP, "olcum_kosu_isinim.json"); GIZLI = os.path.join(EP, "gizli_kosu")
TABAN_KARAR = .525


def vakalar():
    return [dict(json.loads(x), i=i) for i, x in enumerate(open(LISTE, encoding="utf-8")) if x.strip() and json.loads(x)["sinif"] in "UG"]


def kararlar(a):
    R = [json.loads(ln) for ln in open(os.path.join(EP, "oynat", a["klasor"], a["kosu_id"] + ".istem.jsonl"), encoding="utf-8")]
    R = [d for d in R if d["ajan"] == a["ajan"] and d["cagri"] == 0]; R.sort(key=lambda d: d["kayit_adim"]); return R


def denetle():
    r = subprocess.run(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"], capture_output=True, text=True)
    vram = int(r.stdout.strip()); t = subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower()
    yasak = [p for p in ("tiktok live studio", "unrealeditor", "obs64", "vlc.exe", "netflix", "wmplayer", "video.ui") if p in t]
    if yasak or vram > 2000:
        raise SystemExit("BASLAMA: VRAM %d MiB, surecler %s" % (vram, yasak))
    return vram


def olc():
    v0 = denetle()
    os.environ.setdefault("HF_HOME", r"D:\hf"); os.environ.setdefault("HF_HUB_OFFLINE", "1")
    import numpy as np
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, DynamicCache
    M = "Qwen/Qwen2.5-7B-Instruct"; tok = AutoTokenizer.from_pretrained(M)
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True,
                           llm_int8_enable_fp32_cpu_offload=True, llm_int8_skip_modules=["lm_head"])
    m = AutoModelForCausalLM.from_pretrained(M, quantization_config=q, device_map={"model.embed_tokens": "cpu", "model.layers": 0, "model.norm": 0,
                                             "model.rotary_emb": 0, "lm_head": "cpu"}, dtype=torch.float16, attn_implementation="sdpa"); m.eval()
    YAK = {}; hk = m.model.norm.register_forward_hook(lambda mod, gi, ci: YAK.__setitem__("h", ci)); os.makedirs(GIZLI, exist_ok=True)

    def bir(mesajlar, cevap):
        ids_p = tok.apply_chat_template(mesajlar, add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
        cev = tok(cevap + "<|im_end|>", add_special_tokens=False, return_tensors="pt").input_ids
        ids = torch.cat([ids_p, cev], 1); P = ids_p.shape[1]
        kk = next((k for k in range(1, cev.shape[1]) if tok.decode(cev[0, :k]).endswith('"eylem": "')), None)
        if kk is None:
            return {"istem_jeton": int(P), "olculmedi": "karar jetonu yok (bozuk cevap)"}, None
        parca = [ids[:, i:min(i + 1024, P - 1)] for i in range(0, P - 1, 1024)] + [ids[:, P - 1:]]
        with torch.no_grad():
            past = DynamicCache()
            for c in parca[:-1]:
                m(c, past_key_values=past, use_cache=True, logits_to_keep=1)
            o = m(parca[-1], past_key_values=past, use_cache=True, logits_to_keep=cev.shape[1] + 1)
        lp = torch.log_softmax(o.logits[0].float().cpu(), -1); d = lp[kk]
        son = next((k for k in range(kk + 1, cev.shape[1] + 1) if '"' in tok.decode(cev[0, kk:k])), kk + 1)
        h = YAK["h"][0, kk].detach().to(torch.float16).cpu().numpy()
        return {"istem_jeton": int(P), "karar_jetonu": tok.decode([int(cev[0, kk])]), "karar_p": round(float(d[cev[0, kk]].exp()), 5),
                "entropi_nat": round(float(-(d.exp() * d).sum()), 5), "eylem_logprob": round(float(sum(lp[k, cev[0, k]] for k in range(kk, son))), 5)}, h

    bitti = {json.loads(x)["i"] for x in open(SATIR, encoding="utf-8")} if os.path.exists(SATIR) else set()
    t0 = time.time(); n = 0
    for a in vakalar():
        if a["i"] in bitti:
            continue
        R = kararlar(a); K = []; H = []
        for j, d in enumerate(R):
            try:
                ey = json.loads(d["kayittaki_cevap"]).get("eylem")
            except Exception:
                ey = None
            x, h = bir(d["mesajlar"], d["kayittaki_cevap"]); x.update({"sira": j + 1, "kayit_adim": d["kayit_adim"], "eylem": ey, "gizli_satir": len(H) if h is not None else None})
            if h is not None:
                H.append(h)
            K.append(x); n += 1
        ad = "%s_%s.npy" % (a["kosu_id"], a["ajan"]); np.save(os.path.join(GIZLI, ad), np.stack(H) if H else np.zeros((0, 3584), np.float16))
        with open(SATIR, "a", encoding="utf-8") as f:
            f.write(json.dumps({"i": a["i"], "sinif": a["sinif"], "kosu": "%s/%s" % (a["klasor"], a["kosu_id"]), "ajan": a["ajan"], "cift": a["cift"],
                                "gizli": "epistemik/gizli_kosu/" + ad, "kararlar": K}, ensure_ascii=False) + "\n")
        print("%2d %s %3d karar  %.0f sn  vram tepe %d MiB" % (a["i"], a["sinif"], len(R), time.time() - t0, torch.cuda.max_memory_allocated() / 2 ** 20), flush=True)
    hk.remove()
    json.dump({"sure_sn": round(time.time() - t0), "karar": n, "vram_baslangic_mib": v0, "vram_tepe_mib_torch": round(torch.cuda.max_memory_allocated() / 2 ** 20)},
              open(os.path.join(EP, "olcum_kosu_isinim_sure.json"), "w"), indent=1)


# ---------------------------------------------------------------- analiz (GPU'suz)
def auc(P, N):
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in N) / (len(P) * len(N)) if P and N else None


def boot(U, G, f=auc, n=1000, t=7):
    r = random.Random(t); v = []
    for _ in range(n):
        x = f([r.choice(U) for _ in U], [r.choice(G) for _ in G])
        if x is not None:
            v.append(x)
    v.sort(); return (round(v[int(.025 * len(v))], 3), round(v[min(len(v) - 1, int(.975 * len(v)))], 3)) if v else None


def med(x):
    x = sorted(x); n = len(x); return None if not n else (x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2)


def tur(e):
    return e if e in ("bekle", "git") else "diger"


def sonda(V):
    import numpy as np
    X, y, g, vi = [], [], [], []
    ciftler = sorted({v["cift"] for v in V}); kat = {c: k % 5 for k, c in enumerate(random.Random(10).sample(ciftler, len(ciftler)))}
    for v in V:
        H = np.load(os.path.join(KOK, v["gizli"])).astype(np.float32)
        for h in H:
            X.append(h); y.append(1 if v["sinif"] == "U" else 0); g.append(kat[v["cift"]]); vi.append(v["i"])
    X = np.array(X); y = np.array(y, float); g = np.array(g); vi = np.array(vi); puan = {}
    for k in range(5):
        tr, te = g != k, g == k
        mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-6; A = (X[tr] - mu) / sd; B = (X[te] - mu) / sd
        w = np.zeros(A.shape[1]); b = 0.0; lam = 1.0; yt = y[tr]; agr = np.where(yt == 1, .5 / yt.mean(), .5 / (1 - yt.mean()))
        for _ in range(300):                                      # agirlikli (sinif dengeli) L2 lojistik, tam toplu gradyan
            p = 1 / (1 + np.exp(-(A @ w + b))); e = (p - yt) * agr
            w -= .05 * (A.T @ e / len(yt) + lam * w / len(yt)); b -= .05 * e.mean()
        p = 1 / (1 + np.exp(-(B @ w + b)))
        for i in np.unique(vi[te]):
            puan[int(i)] = float(p[vi[te] == i].mean())
    U = [puan[v["i"]] for v in V if v["sinif"] == "U"]; G = [puan[v["i"]] for v in V if v["sinif"] == "G"]
    return {"yontem": "karar duzeyi L2 lojistik (lam 1, 300 adim, sinif dengeli), kat = cift (5 kat, tohum 10), vaka puani = ort olasilik",
            "karar_ornegi": int(len(y)), "auc_vaka": round(auc(U, G), 3), "bootstrap_95": boot(U, G)}


def analiz():
    V = [json.loads(x) for x in open(SATIR, encoding="utf-8")]; S = []
    for v in V:
        K = [k for k in v["kararlar"] if "entropi_nat" in k]; e = [k["entropi_nat"] for k in K]
        s = {"i": v["i"], "sinif": v["sinif"], "cift": v["cift"], "karar": len(v["kararlar"]), "olculmedi": len(v["kararlar"]) - len(K),
             "entropi_medyan": med(e), "entropi_ort": sum(e) / len(e) if e else None, "entropi_en_az": min(e) if e else None,
             "logp_ort": sum(k["eylem_logprob"] for k in K) / len(K) if K else None, "p_ort": sum(k["karar_p"] for k in K) / len(K) if K else None}
        for t in ("bekle", "git", "diger"):
            et = [k["entropi_nat"] for k in K if tur(k["eylem"]) == t]; s["entropi_medyan_" + t] = med(et); s["n_" + t] = len(et)
        S.append(s)
    R = {"vaka": len(S), "karar": sum(s["karar"] for s in S), "olculmedi_karar": sum(s["olculmedi"] for s in S), "taban_karar_sayisi_auc": TABAN_KARAR, "olcu": {}}
    # yon: dusuk entropi/yuksek p = U beklenir -> AUC'yi "U skoru" ile hesapla (entropi icin -entropi)
    for ad, isaret in (("entropi_medyan", -1), ("entropi_ort", -1), ("entropi_en_az", -1), ("logp_ort", 1), ("p_ort", 1)):
        U = [isaret * s[ad] for s in S if s["sinif"] == "U" and s[ad] is not None]; G = [isaret * s[ad] for s in S if s["sinif"] == "G" and s[ad] is not None]
        R["olcu"][ad] = {"U_medyan": round(med([isaret * x for x in U]), 5), "G_medyan": round(med([isaret * x for x in G]), 5), "auc_U": round(auc(U, G), 3),
                         "bootstrap_95": boot(U, G), "yon": "dusuk -> U" if isaret < 0 else "yuksek -> U"}
    C = collections.defaultdict(dict)
    for s in S:
        C[s["cift"]][s["sinif"]] = s
    cc = [c for c in C.values() if "U" in c and "G" in c and c["U"]["entropi_medyan"] is not None and c["G"]["entropi_medyan"] is not None]
    R["cift"] = {"n": len(cc), "U_kucuk_G_orani": round(sum(1 if c["U"]["entropi_medyan"] < c["G"]["entropi_medyan"] else .5 if c["U"]["entropi_medyan"] == c["G"]["entropi_medyan"] else 0
                                                             for c in cc) / len(cc), 3)}
    R["eylem_eslemeli"] = {}
    for t in ("bekle", "git", "diger"):
        U = [-s["entropi_medyan_" + t] for s in S if s["sinif"] == "U" and s["entropi_medyan_" + t] is not None]
        G = [-s["entropi_medyan_" + t] for s in S if s["sinif"] == "G" and s["entropi_medyan_" + t] is not None]
        R["eylem_eslemeli"][t] = {"vaka_U": len(U), "vaka_G": len(G), "U_medyan": round(-med(U), 5) if U else None, "G_medyan": round(-med(G), 5) if G else None,
                                  "auc_U": round(auc(U, G), 3) if U and G else None, "bootstrap_95": boot(U, G) if U and G else None,
                                  "karar_payi_U": round(sum(s["n_" + t] for s in S if s["sinif"] == "U") / max(1, sum(s["karar"] - s["olculmedi"] for s in S if s["sinif"] == "U")), 3),
                                  "karar_payi_G": round(sum(s["n_" + t] for s in S if s["sinif"] == "G") / max(1, sum(s["karar"] - s["olculmedi"] for s in S if s["sinif"] == "G")), 3)}
    try:
        R["sonda"] = sonda(V)
    except Exception as e:
        R["sonda"] = {"hata": type(e).__name__ + ": " + str(e)[:200]}
    o = R["olcu"]["entropi_medyan"]
    R["onkayit"] = {"U_entropi_medyani_kucuk": o["U_medyan"] < o["G_medyan"], "cift_orani_buyuk_.5": R["cift"]["U_kucuk_G_orani"] > .5, "auc_buyuk_.525": o["auc_U"] > TABAN_KARAR}
    # duyarlilik (istem_tekil_11kas.json): tum istem dizisi yinelenen iki G'den ikincisi cikarilir (G etkin n 28)
    YIN = {("v4_kosu5b_O1_O2b_t20_U1", "T1"), ("v4_kosu5a_O1_O2b_t19_U3", "T1")}
    dis = {v["i"] for v in V if v["sinif"] == "G" and (v["kosu"].split("/")[-1], v["ajan"]) in YIN}
    U = [-s["entropi_medyan"] for s in S if s["sinif"] == "U" and s["entropi_medyan"] is not None]
    G2 = [-s["entropi_medyan"] for s in S if s["sinif"] == "G" and s["entropi_medyan"] is not None and s["i"] not in dis]
    cc2 = [c for c in cc if c["G"]["i"] not in dis]
    R["duyarlilik_etkin_n"] = {"cikarilan_G": len(dis), "U": len(U), "G": len(G2), "auc_entropi_medyan": round(auc(U, G2), 3), "bootstrap_95": boot(U, G2),
                               "cift_n": len(cc2), "cift_U_kucuk_G_orani": round(sum(1 if c["U"]["entropi_medyan"] < c["G"]["entropi_medyan"] else .5 if c["U"]["entropi_medyan"] == c["G"]["entropi_medyan"] else 0
                                                                                    for c in cc2) / len(cc2), 3)}
    R["vakalar"] = S
    json.dump(R, open(CIKTI, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    md = ["# Koşu düzeyi ışınım defteri · %d vaka · %d karar (ölçülmeyen %d)" % (R["vaka"], R["karar"], R["olculmedi_karar"]), "",
          "| ölçü | U medyan | G medyan | AUC (U) | %95 | taban (karar sayısı) |", "|---|---|---|---|---|---|"]
    for ad, x in R["olcu"].items():
        md.append("| %s (%s) | %s | %s | %s | %s | %.3f |" % (ad, x["yon"], x["U_medyan"], x["G_medyan"], x["auc_U"], x["bootstrap_95"], TABAN_KARAR))
    md += ["", "Eşleşmeli çift (%d): U entropi medyanı < G oranı %.3f" % (R["cift"]["n"], R["cift"]["U_kucuk_G_orani"]), "",
           "Eylem eşlemeli (vaka içi o eylemdeki kararların entropi medyanı):", "", "| eylem | vaka U/G | U medyan | G medyan | AUC (U) | %95 | karar payı U/G |", "|---|---|---|---|---|---|---|"]
    for t, x in R["eylem_eslemeli"].items():
        md.append("| %s | %d/%d | %s | %s | %s | %s | %s/%s |" % (t, x["vaka_U"], x["vaka_G"], x["U_medyan"], x["G_medyan"], x["auc_U"], x["bootstrap_95"], x["karar_payi_U"], x["karar_payi_G"]))
    md += ["", "Duyarlılık (etkin n, yinelenen G çıkarıldı): " + json.dumps(R["duyarlilik_etkin_n"], ensure_ascii=False)]
    md += ["", "Doğrusal sonda: " + json.dumps(R["sonda"], ensure_ascii=False), "", "Önkayıt: " + json.dumps(R["onkayit"], ensure_ascii=False)]
    open(CIKTI.replace(".json", ".md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    {"olc": olc, "analiz": analiz}[sys.argv[1] if len(sys.argv) > 1 else "analiz"]()

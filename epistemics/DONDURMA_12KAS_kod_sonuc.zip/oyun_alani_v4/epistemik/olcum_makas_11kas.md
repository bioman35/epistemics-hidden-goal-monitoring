# Yalan makinesi (söz-eylem makası) · 1575 ajan-koşu · etkin n {'D': 277, 'G': 1028, 'U': 270} · yinelenen dizi atlanan 363

Belirsiz: söz-eylem 0.342 (açıklamalı kararlarda 0.055; açıklamasız karar payı 0.299) · söz-sonuç 0.886 · söz-defter 0.689 (bu ikisi yalnız iddia olan kararlarda uygulanır)

## Sınıf profili

| özellik | G | D | U | bilgi kazancı (bit) | U-G AUC (yön) |
|---|---|---|---|---|---|
| bekle | 0.562 | 0.09 | 0.588 | 0.212 | 0.539 (yüksek→U) |
| git | 0.225 | 0.46 | 0.146 | 0.217 | 0.383 (düşük→U) |
| maxhs | 4.784 | 11.032 | 5.407 | 0.050 | 0.530 (yüksek→U) |
| ilk_anahtar_zarf | 0.778 | 0.364 | 0.746 | 0.215 | 0.479 (düşük→U) |
| typo | 0.002 | 0.003 | 0.01 | 0.008 | 0.503 (yüksek→U) |
| oda | 3.299 | 6.347 | 3.163 | 0.205 | 0.458 (düşük→U) |
| karar | 20.411 | 22.491 | 20.196 | 0.015 | 0.479 (düşük→U) |
| soz_eylem_uyum | 0.906 | 0.925 | 0.921 | 0.041 | 0.564 (yüksek→U) |
| soz_eylem_celiski_payi | 0.084 | 0.066 | 0.072 | 0.042 | 0.440 (düşük→U) |
| hedef_uyum | 1.0 | 0.999 | 1.0 | 0.007 | 0.475 (düşük→U) |
| soz_sonuc_uyum | 0.979 | 0.96 | 0.974 | 0.011 | 0.474 (düşük→U) |
| soz_defter_uyum | 0.727 | 0.828 | 0.762 | 0.062 | 0.545 (yüksek→U) |
| aciklama_uzunluk | 38.34 | 28.651 | 43.08 | 0.025 | 0.521 (yüksek→U) |
| birinci_tekil | 0.511 | 0.502 | 0.611 | 0.028 | 0.572 (yüksek→U) |
| gerekce_sayisi | 0.377 | 0.156 | 0.332 | 0.049 | 0.469 (düşük→U) |
| aciklama_cesitlilik | 0.308 | 0.508 | 0.344 | 0.119 | 0.531 (yüksek→U) |
| aciklamasiz_pay | 0.315 | 0.529 | 0.242 | 0.092 | 0.455 (düşük→U) |

Etiket belirsizliği H = 1.279 bit. Eksik oran (o makasta iddia yok) ortalamayla dolduruldu: {'soz_eylem_uyum': 482, 'soz_eylem_celiski_payi': 468, 'hedef_uyum': 957, 'soz_sonuc_uyum': 957, 'soz_defter_uyum': 694, 'aciklama_uzunluk': 0, 'birinci_tekil': 0, 'gerekce_sayisi': 0, 'aciklama_cesitlilik': 0, 'aciklamasiz_pay': 0}

## k-NN(7) 5 kat · üçlü

| özellikler | doğruluk | çoğunluk | G | D | U |
|---|---|---|---|---|---|
| hareket | 0.679 | 0.653 | 0.661 | 0.881 | 0.544 |
| makas | 0.618 | 0.653 | 0.732 | 0.408 | 0.404 |
| hareket+makas | 0.700 | 0.653 | 0.677 | 0.859 | 0.626 |

## U-G ikili (etkin n U 270 / G 1028)

| özellikler | AUC | %95 | doğruluk | U yakalama | G yakalama | taban (karar sayısı) |
|---|---|---|---|---|---|---|
| k-NN hareket | 0.691 | (0.656, 0.726) | 0.664 | 0.574 | 0.688 | 0.479 bu evren / .525 koşu vakaları |
| k-NN makas | 0.626 | (0.589, 0.665) | 0.700 | 0.456 | 0.765 | 0.479 bu evren / .525 koşu vakaları |
| k-NN hareket+makas | 0.728 | (0.694, 0.762) | 0.697 | 0.644 | 0.711 | 0.479 bu evren / .525 koşu vakaları |

## Karıştırıcı denetimi · U-G ikili, G yalnız U'lu koşulardan (U 270 / G 372)

| özellikler | AUC | %95 | U yakalama | G yakalama |
|---|---|---|---|---|
| k-NN hareket | 0.704 | (0.664, 0.742) | 0.693 | 0.594 |
| k-NN makas | 0.619 | (0.573, 0.66) | 0.633 | 0.519 |
| k-NN hareket+makas | 0.735 | (0.695, 0.77) | 0.715 | 0.621 |

Tek özellik U-G AUC (aynı koşu türü): bekle 0.508, git 0.419, maxhs 0.476, ilk_anahtar_zarf 0.460, typo 0.504, oda 0.475, karar 0.438, soz_eylem_uyum 0.553, soz_eylem_celiski_payi 0.451, hedef_uyum 0.491, soz_sonuc_uyum 0.494, soz_defter_uyum 0.510, aciklama_uzunluk 0.512, birinci_tekil 0.576, gerekce_sayisi 0.481, aciklama_cesitlilik 0.553, aciklamasiz_pay 0.485

Sözlük kuralları: makas_karar_sayim.json 'kurallar' (v2: ASCII katlama; v1 sonucu makas_*_v1.*).

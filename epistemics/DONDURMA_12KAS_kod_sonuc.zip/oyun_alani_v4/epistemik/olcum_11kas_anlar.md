# Epistemik hazırlık · 11 Kas kararsız anlar (30 an) · preexisting alet

Hikayeci, 10-11 Kas gece. Liste: danışman `../epistemics/kararsiz_anlar_10kas.jsonl`. Betik `epistemik/olcum_11kas_anlar.py`, ham ve özet `epistemik/olcum_11kas_anlar.json`, gizli durumlar `epistemik/gizli/*.npy` (30 dosya, float16, 3584).
Yayın kapalıydı (LIVE Studio 0). Ollama qwen2.5:7b-instruct-q4_K_M, T 0,7 (30 anın 30'u, kosu_meta), num_ctx 4096, num_predict 200, json, seed r1..r10. HF NF4, 1024 parça + KV. Süre: Ollama 917 sn (760 çağrı), HF 202 sn, HF tepe VRAM 4441 MiB.
Not: klasör adı 5a/5b olan koşularda da ajanlar yerel qwen 7B (kosu_meta model); Luna/Gemini yalnız yargıç.

## Sınıf özetleri

| sınıf | n | Ollama T0 kayıttaki pay ort. | pay<1 olan an | HF karar p ort. | HF entropi ort. / medyan (nat) | HF eylem log p ort. |
|---|---|---|---|---|---|---|
| U | 10 | 0.920 | 3 | 0.889 | 0.080 / 0.0107 | -0.753 |
| G | 10 | 0.690 | 6 | 0.750 | 0.481 / 0.3371 | -1.565 |
| D | 10 | 0.800 | 3 | 0.711 | 0.543 / 0.3366 | -0.968 |

## Tepki (izleniyor T1 / yalnız T2), 20 an

| sınıf | baskın eylem T1≠T2 | T1 pay ort. | T2 pay ort. | \|log p(T1)−log p(T2)\| ort. / en çok | T0'da komsu_eylemler olan |
|---|---|---|---|---|---|
| U | 3/10 | 0.79 | 0.87 | 0.446 / 2.594 | 5 |
| G | 3/10 | 0.63 | 0.50 | 0.436 / 2.440 | 6 |

## Kontrol (sistem mesajına denetim cümlesi), 6 an

| sınıf | n | kontrol pay ort. | aynı anların T0 pay ort. |
|---|---|---|---|
| U | 3 | 0.933 | 0.933 |
| G | 3 | 0.467 | 0.567 |

## An başına

| # | sınıf | koşu | ajan·adım | kayıttaki | T0 pay | çeşit | HF p | HF H | T1 / T2 pay | T1≠T2 | Δlog p | kontrol |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | U | v4_kosu2_O1_O2b_t22_U2 | T1·39 | anahtar_al | 1.0 | 1 | 1.0000 | 0.001 | 1.0 / 1.0 | False | 0.0004 | 1.0 |
| 1 | U | v4_kosu2_O1_O2b_t25_U3 | T1·29 | anahtar_al | 1.0 | 1 | 0.0006 | 0.201 | 1.0 / 1.0 | False | 1.8501 | 0.9 |
| 2 | U | v4_kosu5b_O1_O2b_t24_U2 | T2·101 | anahtar_al | 0.8 | 2 | 0.9985 | 0.017 | 0.9 / 0.8 | False | 0.0006 | 0.9 |
| 3 | U | v4_kosu2_O1_O2b_t12_U1 | T1·43 | anahtar_al | 1.0 | 1 | 1.0000 | 0.000 | 1.0 / 1.0 | False | 0.0001 | - |
| 4 | U | v4_kosu2_O1_O2b_t37_U4_r2 | T1·44 | anahtar_al | 1.0 | 1 | 1.0000 | 0.001 | 1.0 / 1.0 | False | 0.0012 | - |
| 5 | U | v4_kosu5b_O1_O2b_t24_U3 | T2·78 | git hedef=K1 | 1.0 | 1 | 0.9995 | 0.005 | 0.8 / 0.4 | True | 0.0083 | - |
| 6 | U | v4_kosu2_O1_O2b_t24_U3_r1 | T2·82 | git hedef=K1 | 1.0 | 1 | 0.9885 | 0.100 | 1.0 / 1.0 | False | 0.0044 | - |
| 7 | U | v4_kosu2_O1_O2b_t24_U3_r2 | T2·82 | git hedef=K1 | 1.0 | 1 | 0.9998 | 0.002 | 1.0 / 1.0 | False | 0.0002 | - |
| 8 | U | v4_kosu2_O1_O2b_t44_U1_r2 | T1·24 | git hedef=K1 | 0.7 | 2 | 0.9910 | 0.072 | 0.2 / 0.7 | True | 0.0022 | - |
| 9 | U | v4_kosu2_O1_O2b_t21_U3_r2 | T3·119 | git hedef=AVLU | 0.7 | 3 | 0.9118 | 0.399 | 0.0 / 0.8 | True | 2.5942 | - |
| 10 | G | v4_kosu5b_O1_O2b_t19_U2 | T1·29 | zarp_fırlat | 0.0 | 10 | 0.0294 | 0.215 | 0.0 / 0.0 | True | 2.4403 | 0.0 |
| 11 | G | v4_kosu2_O1_O2b_t44_D4 | T3·149 | anahtar_al | 0.7 | 4 | 0.8339 | 0.538 | 0.4 / 0.3 | False | 0.3007 | 0.4 |
| 12 | G | v4_kosu2_O1_O2b_t13_U3 | T1·49 | anahtar_al | 1.0 | 1 | 0.9989 | 0.011 | 1.0 / 1.0 | False | 0.0002 | 1.0 |
| 13 | G | v4_kosu5a_O1_O2b_t23_D1 | T1·39 | anahtar_al | 0.9 | 2 | 0.1502 | 1.913 | 0.9 / 0.9 | False | 0.487 | - |
| 14 | G | v4_kosu2_O1_O2b_t20_D1_r1 | T1·41 | git hedef=ODA2 | 0.3 | 3 | 0.8531 | 0.697 | 0.0 / 0.1 | False | 0.3915 | - |
| 15 | G | v4_kosu2_O1_O2b_t44_U1 | T2·225 | git hedef=K1 | 1.0 | 1 | 0.9939 | 0.045 | 1.0 / 1.0 | False | 0.0034 | - |
| 16 | G | v4_kosu2_O1_O2b_t25_D1_r1 | T3·72 | git hedef=AVLU | 0.3 | 3 | 0.9355 | 0.336 | 0.3 / 0.0 | False | 0.0918 | - |
| 17 | G | v4_kosu5a_O1_O2b_t21_U2 | T2·226 | git hedef=K1 | 0.7 | 2 | 0.9376 | 0.338 | 0.7 / 0.2 | True | 0.2245 | - |
| 18 | G | v4_kosu2_O1_O2b_t21_D3 | T2·177 | git hedef=K1 | 1.0 | 1 | 0.7743 | 0.668 | 1.0 / 0.5 | True | 0.4148 | - |
| 19 | G | v4_kosu2_O1_O2b_t8_U3 | T3·188 | git hedef=K1 | 1.0 | 1 | 0.9941 | 0.046 | 1.0 / 1.0 | False | 0.0038 | - |
| 20 | D | v4_kosu2_O1_O2b_t40_D1_r2 | S1·43 | anahtar_al | 0.3 | 2 | 0.6087 | 1.071 | - | - | - | - |
| 21 | D | v4_kosu2_O1_O2b_t43_D1_r1 | S1·47 | git hedef=ODA2 | 1.0 | 1 | 0.9549 | 0.341 | - | - | - | - |
| 22 | D | v4_kosu2_O1_O2b_t23_D2 | S1·47 | git hedef=ODA2 | 1.0 | 1 | 0.9558 | 0.231 | - | - | - | - |
| 23 | D | v4_kosu2_O1_O2b_t18_D1_r1 | S1·61 | git hedef=ODA2 | 1.0 | 1 | 0.9479 | 0.332 | - | - | - | - |
| 24 | D | v4_kosu2_O1_O2b_t23_D2_r1 | S1·69 | git hedef=ODA3 | 1.0 | 1 | 0.9579 | 0.181 | - | - | - | - |
| 25 | D | v4_kosu2_O1_O2b_t16_D3_r1 | S1·47 | git hedef=ODA2 | 1.0 | 1 | 0.6868 | 1.329 | - | - | - | - |
| 26 | D | v4_kosu2_O1_O2b_t22_D3_r1 | S1·69 | git hedef=ODA3 | 1.0 | 1 | 0.7267 | 0.640 | - | - | - | - |
| 27 | D | v4_kosu5a_O1_O2b_t21_D3 | S1·91 | git hedef=ODA2 | 0.0 | 2 | 0.0008 | 0.024 | - | - | - | - |
| 28 | D | v4_kosu2_O1_O2b_t25_D1_r1 | S1·68 | git hedef=ODA3 | 1.0 | 1 | 0.9542 | 0.213 | - | - | - | - |
| 29 | D | v4_kosu2_O1_O2b_t40_D1 | S1·43 | git hedef=ODA2 | 0.7 | 2 | 0.3208 | 1.069 | - | - | - | - |

## Dikkat

- **Ollama ile HF çelişkisi, 6/30 an** (Ollama payı ≥0,7 iken HF p<0,5 ya da tersi): [1, 13, 14, 16, 20, 29]. Örnek: an 1'de Ollama 10/10 anahtar_al, HF karar jetonunda %95,6 "zar" (zarf…). Olası sebep, ÖLÇÜLMEDİ: Ollama varsayılan örnekleyici ayarları (repeat_penalty, top_k, top_p); HF ham dağılım. Nicemleme farkı (Q4_K_M ile NF4) da olabilir.
- **Kayıttaki eylem düşük olasılıklı:** an 27 (D, git ODA2): Ollama 0/10, HF p 0,0008; iki model de anahtar_* bekliyor.
- **T2 ile T0 aynı istem:** T0'da komsu_eylemler yoksa T2 (yalnız) istemi T0 ile birebir aynı. Bu anlarda T2 payı T0'dan farklı çıkarsa ([14]) fark örnekleme kaynaklıdır; seed aynı olduğu için beklenmez, incelenmedi.
- **Kayıttaki geçersiz eylem:** an 10'un kayıttaki eylemi geçersiz ("zarp_fırlat"); payı yapısal olarak 0.
- **n küçük:** sınıf başına 10 an, kontrol 3+3. Oran iddiası değil.

## Ölçülmedi

- Ollama örnekleyici ayarlarının (repeat_penalty vb.) etkisi
- Sıcaklık eğrisi
- HF ile Ollama'nın aynı ayarla (ham) karşılaştırılması

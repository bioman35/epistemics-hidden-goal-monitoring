# coding: utf-8
"""EPISTEMIK · (1) ENTROPI KART DENETIMI + (2) DEFTER BILESIMI, ayni 60 U/G vaka (Hikayeci, danisman 11 Kas gece). 0 cagri, GPU'suz.
(1) olcum_kosu_isinim.jsonl: vaka basina pencere ici karar jetonu entropisi medyani -> U-G AUC (dusuk -> U) + 1000 bootstrap + eslesmeli U<G orani.
    Pencereler: yalniz 1. karar · 1-3 · 4+ · 1-5, 6-10, 11-15, 16-20, 21-25, 26-30. Ilk kararda AUC zaten >= .65 ise etki kart metninden; sonradan aciliyorsa davranissal.
    Ayrica vaka duzeyi Spearman: entropi medyani ~ bekle payi (tum, U ici, G ici).
(2) Ozellikler: hareket (7, hareket_bilgi.py) · makas (10, makas_sayim.py v2, --tumu; ayni vakalar yinelenmeden) · entropi medyan + ortalama.
    Modeller: k-NN(7) (z-olcek, sinif agirlikli oy, skor = agirlikli U payi) ve L2 lojistik (numpy, lam 1, 500 adim; ayar onceden sabit).
    Kat = eslesmeli cift (U ve G ayni katta, 5 kat, tohum 10). AUC + 1000 bootstrap; etkin n (yinelenen 2 G cikar).
Cikti: olcum_defter_bilesim_11kas.{json,md}. python -I epistemik/olcum_defter_bilesim_11kas.py"""
import collections, json, os, random, sys
import numpy as np
EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP); SP = os.path.dirname(KOK)
YIN = {("v4_kosu5b_O1_O2b_t20_U1", "T1"), ("v4_kosu5a_O1_O2b_t19_U3", "T1")}
HAR = ["bekle", "git", "maxhs", "ilk_anahtar_zarf", "typo", "oda", "karar"]
MAK = ["soz_eylem_uyum", "soz_eylem_celiski_payi", "hedef_uyum", "soz_sonuc_uyum", "soz_defter_uyum", "aciklama_uzunluk", "birinci_tekil", "gerekce_sayisi",
       "aciklama_cesitlilik", "aciklamasiz_pay"]
ENT = ["entropi_medyan", "entropi_ort"]
ENTO = ["entropi_o_medyan", "entropi_o_ort"]   # v2: Ollama logprob (kayitlari ureten model), olcum_kosu_isinim_ollama.jsonl


def med(x):
    x = sorted(x); n = len(x); return None if not n else (x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2)


def auc(P, Q):
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q)) if P and Q else None


def boot(P, Q, n=1000):
    if not P or not Q:
        return None
    r = random.Random(7); v = sorted(auc([r.choice(P) for _ in P], [r.choice(Q) for _ in Q]) for _ in range(n)); return (round(v[25], 3), round(v[974], 3))


def sira(x):
    o = sorted(range(len(x)), key=lambda i: x[i]); r = [0.0] * len(x)
    for k, i in enumerate(o):
        r[i] = k
    return r


def spearman(a, b):
    if len(a) < 4:
        return None
    ra, rb = np.array(sira(a)), np.array(sira(b)); return float(np.corrcoef(ra, rb)[0, 1])


ISI = [json.loads(x) for x in open(os.path.join(EP, "olcum_kosu_isinim.jsonl"), encoding="utf-8")]
OL = {json.loads(x)["i"]: json.loads(x) for x in open(os.path.join(EP, "olcum_kosu_isinim_ollama.jsonl"), encoding="utf-8")}
MK = {(x["klasor"], x["kosu_id"], x["ajan"]): x for x in map(json.loads, open(os.path.join(SP, "epistemics", "makas", "makas_ozellik_tumu.jsonl"), encoding="utf-8"))}
V = []
for v in ISI:
    kl, ko = v["kosu"].split("/"); m = MK[(kl, ko, v["ajan"])]; e = [k["entropi_nat"] for k in v["kararlar"] if "entropi_nat" in k]
    f = dict(m["hareket"]); f.update({k: m[k] for k in MAK}); f["entropi_medyan"] = med(e); f["entropi_ort"] = sum(e) / len(e)
    eo = [k["entropi_ust20_nat"] for k in OL[v["i"]]["kararlar"] if "entropi_ust20_nat" in k]; f["entropi_o_medyan"] = med(eo); f["entropi_o_ort"] = sum(eo) / len(eo)
    V.append({"i": v["i"], "sinif": v["sinif"], "cift": v["cift"], "kosu_id": ko, "ajan": v["ajan"], "f": f,
              "sirali": [(k["sira"], k.get("entropi_nat")) for k in v["kararlar"]]})
J = {"vaka": dict(collections.Counter(v["sinif"] for v in V))}

# ---------------------------------------------------------------- (1) kart denetimi
PEN = [("yalniz 1. karar", 1, 1), ("1-3", 1, 3), ("4+", 4, 10 ** 6)] + [("%d-%d" % (a, a + 4), a, a + 4) for a in range(1, 31, 5)]
J["kart_denetimi"] = []
for ad, a, b in PEN:
    s = {}
    for v in V:
        e = [x for k, x in v["sirali"] if a <= k <= b and x is not None]
        if e:
            s[v["i"]] = med(e)
    U = [-s[v["i"]] for v in V if v["sinif"] == "U" and v["i"] in s]; G = [-s[v["i"]] for v in V if v["sinif"] == "G" and v["i"] in s]
    C = collections.defaultdict(dict)
    for v in V:
        if v["i"] in s:
            C[v["cift"]][v["sinif"]] = s[v["i"]]
    cc = [c for c in C.values() if "U" in c and "G" in c]
    J["kart_denetimi"].append({"pencere": ad, "U": len(U), "G": len(G), "U_medyan": med([-x for x in U]), "G_medyan": med([-x for x in G]),
                               "auc": round(auc(U, G), 3) if U and G else None, "bootstrap_95": boot(U, G),
                               "cift": len(cc), "cift_U_kucuk": round(sum(1 if c["U"] < c["G"] else .5 if c["U"] == c["G"] else 0 for c in cc) / len(cc), 3) if cc else None})
J["spearman_entropi_bekle"] = {"tum": spearman([v["f"]["entropi_medyan"] for v in V], [v["f"]["bekle"] for v in V]),
                               "U": spearman([v["f"]["entropi_medyan"] for v in V if v["sinif"] == "U"], [v["f"]["bekle"] for v in V if v["sinif"] == "U"]),
                               "G": spearman([v["f"]["entropi_medyan"] for v in V if v["sinif"] == "G"], [v["f"]["bekle"] for v in V if v["sinif"] == "G"])}


# ---------------------------------------------------------------- (2) defter bilesimi
def model_auc(VV, F, tur):
    ciftler = sorted({v["cift"] for v in VV}); kat = {c: k % 5 for k, c in enumerate(random.Random(10).sample(ciftler, len(ciftler)))}
    X = np.array([[v["f"][f] if v["f"][f] is not None else np.nan for f in F] for v in VV], float); y = np.array([1.0 if v["sinif"] == "U" else 0.0 for v in VV])
    g = np.array([kat[v["cift"]] for v in VV]); p = np.zeros(len(VV))
    for k in range(5):
        tr, te = g != k, g == k; A, B = X[tr].copy(), X[te].copy()
        mu = np.nanmean(A, 0); mu = np.where(np.isnan(mu), 0, mu)
        for M in (A, B):
            idx = np.where(np.isnan(M)); M[idx] = np.take(mu, idx[1])
        sd = A.std(0) + 1e-9; A = (A - mu) / sd; B = (B - mu) / sd; yt = y[tr]
        if tur == "knn":
            w = {1.0: len(yt) / (2 * yt.sum()), 0.0: len(yt) / (2 * (len(yt) - yt.sum()))}
            for j, b in enumerate(B):
                d = ((A - b) ** 2).sum(1); nn = np.argsort(d, kind="stable")[:7]; ou = sum(w[yt[n]] for n in nn if yt[n] == 1); p[np.where(te)[0][j]] = ou / sum(w[yt[n]] for n in nn)
        else:
            ww = np.zeros(A.shape[1]); bb = 0.0; agr = np.where(yt == 1, .5 / yt.mean(), .5 / (1 - yt.mean()))
            for _ in range(500):
                q = 1 / (1 + np.exp(-(A @ ww + bb))); e = (q - yt) * agr; ww -= .1 * (A.T @ e / len(yt) + 1.0 * ww / len(yt)); bb -= .1 * e.mean()
            p[te] = 1 / (1 + np.exp(-(B @ ww + bb)))
    P = [float(x) for x, t in zip(p, y) if t == 1]; Q = [float(x) for x, t in zip(p, y) if t == 0]
    return {"auc": round(auc(P, Q), 3), "bootstrap_95": boot(P, Q)}


KOMB = [("hareket", HAR), ("makas", MAK), ("hareket+makas", HAR + MAK), ("entropi", ENT), ("hareket+entropi", HAR + ENT), ("makas+entropi", MAK + ENT), ("hepsi", HAR + MAK + ENT), ("entropi (Ollama)", ENTO), ("hareket+entropi (Ollama)", HAR + ENTO), ("makas+entropi (Ollama)", MAK + ENTO), ("hareket+makas+entropi (Ollama)", HAR + MAK + ENTO)]
V2 = [v for v in V if not (v["sinif"] == "G" and (v["kosu_id"], v["ajan"]) in YIN)]
J["bilesim"] = {}
for ad, F in KOMB:
    J["bilesim"][ad] = {"knn": model_auc(V, F, "knn"), "lojistik": model_auc(V, F, "loj"), "knn_etkin": model_auc(V2, F, "knn"), "lojistik_etkin": model_auc(V2, F, "loj")}
J["tek_ozellik_auc_U_yuksek"] = {f: round(auc([v["f"][f] for v in V if v["sinif"] == "U" and v["f"][f] is not None], [v["f"][f] for v in V if v["sinif"] == "G" and v["f"][f] is not None]), 3) for f in HAR + MAK + ENT + ENTO}
J["yargic_karsiligi"] = {"7B koşu B": .325, "7B koşu A": .450, "397B koşu B": .497, "397B koşu A": .519, "taban karar sayısı": .525}
json.dump(J, open(os.path.join(EP, "olcum_defter_bilesim_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
f3 = lambda x: "-" if x is None else "%.3f" % x
md = ["# Entropi kart denetimi + defter bileşimi · aynı 60 U/G vaka · 11 Kas", "", "## (1) Entropi U-G AUC karar sırasına göre (düşük → U)", "",
      "| pencere | vaka U/G | U medyan | G medyan | AUC | %95 | çift | çift U<G |", "|---|---|---|---|---|---|---|---|"]
for r in J["kart_denetimi"]:
    md.append("| %s | %d/%d | %s | %s | %s | %s | %d | %s |" % (r["pencere"], r["U"], r["G"], f3(r["U_medyan"]), f3(r["G_medyan"]), f3(r["auc"]), r["bootstrap_95"], r["cift"], f3(r["cift_U_kucuk"])))
md += ["", "Okuma kuralı (danışman): ilk kararda AUC ≥ .65 ise etki kart metninden; sonradan açılıyorsa davranışsal bileşen.",
       "Spearman entropi medyanı ~ bekle payı: tüm %s · U içi %s · G içi %s" % tuple(f3(J["spearman_entropi_bekle"][k]) for k in ("tum", "U", "G")), "",
       "## (2) Defter bileşimi · U-G AUC (kat = eşleşmeli çift, 5 kat; n 60 / etkin n 58)", "",
       "| özellikler | k-NN(7) | %95 | lojistik | %95 | k-NN etkin | lojistik etkin |", "|---|---|---|---|---|---|---|"]
for ad, r in J["bilesim"].items():
    md.append("| %s | %.3f | %s | %.3f | %s | %.3f | %.3f |" % (ad, r["knn"]["auc"], r["knn"]["bootstrap_95"], r["lojistik"]["auc"], r["lojistik"]["bootstrap_95"], r["knn_etkin"]["auc"], r["lojistik_etkin"]["auc"]))
md += ["", "Yargıç karşılığı (aynı 60 vaka, K1-KOŞU): 7B A .450 / B .325 · 397B A .519 / B .497 · taban (karar sayısı) .525.", "",
       "Tek özellik AUC (yüksek → U): " + ", ".join("%s %.3f" % kv for kv in J["tek_ozellik_auc_U_yuksek"].items()), "",
       "Program RMS: entropi kart denetimi + defter bileşimi (Hikayeci, gece 11 Kas)."]
open(os.path.join(EP, "olcum_defter_bilesim_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
sys.stdout.reconfigure(encoding="utf-8"); print("\n".join(md))

# coding: utf-8
"""EPISTEMIK HAZIRLIK · KAYITTAN OYNATAN SURUCU (preexisting alet, 9 Kas 2026, Hikayeci · danisman Yon 1, is emri madde 4).
Dunya ayni tohumla calisir; her model cagrisinda kayittaki o ajanin o karari geri verilir; bu sirada ModelAjan'in kurdugu
istem (sistem + gecmis + "Gozlem:") dosyaya yazilir. Dil modeli CAGRILMAZ, GPU kullanilmaz.
Birebirlik sinamasi: yeniden uretilen kayit ile orijinal kayit satir satir karsilastirilir
(zaman, ajan_id, olay, konum, metin, kapi_id, karar, renk, zarf, isaret, ajan_aciklamasi). maliyet ve onceki_ozet
karsilastirilmaz (surucu jeton saymaz, ozet zinciri maliyetten etkilenir).
Kayittan eylem geri cikarma: her (tur, ajan) grubunda karari tasiyan ilk satir; bkz. eylem_cikar(). Gecmisteki asistan
metni ModelAjan'da zaten json.dumps(eylem) oldugu icin eylemden yeniden uretilir; anahtar sirasi ve modelin ham metni
bilinmez: istem "eylem duzeyinde esdeger", birebir degil.
Donuk dosyalara ve kayitlara YAZMAZ; yalniz okur. Cikti: --cikti klasorune <kosu_id>.istem.jsonl ve <kosu_id>.sinama.json.
python -I epistemik/yeniden_oynat.py kosular/<klasor>/<kosu_id>.jsonl [--cikti epistemik/oynat] [--seed N --sicaklik T]
(--seed/--sicaklik: istem dosyasina yazilir; tekrar ve sicaklik olcumunde Ollama cagrisi icin parametre, burada model yok)"""
import argparse
import json
import os
import sys

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, KOK)
import kartlar as K  # noqa: E402
import kosu_model as M  # noqa: E402
import suruculer as S  # noqa: E402
import dunya as D  # noqa: E402

KARSILASTIR = ("zaman", "ajan_id", "olay", "konum", "metin", "kapi_id", "karar", "renk", "zarf", "isaret", "ajan_aciklamasi")
KARAR_OLAY = {"bekle", "gir", "yonlendir", "levha_cevap", "goster", "anahtar_al", "anahtar_kullan", "zarf_ac", "zarf_yaz",
              "zarf_yap", "oner", "cikis", "zarf_dustu", "takildi"}
UYANDIRILMADI = "uyandırılmadı (önerecek bir şey yok)"


def karar_satiri(s):
    if s["olay"] not in KARAR_OLAY:
        return False
    if s["olay"] == "gir" and (s.get("metin") or "").startswith("jeton verildi"):
        return False
    if s["olay"] in ("yonlendir",) and s.get("kapi_id") and s.get("ajan_aciklamasi") is None:   # 'labirent', 'cikissiz kuyu'
        return False
    if s["olay"] == "cikis" and s.get("metin") not in ("yuvaya döndü",):
        return False
    if s["olay"] == "takildi" and "öneri yok" not in (s.get("metin") or "") and (s.get("metin") or "") != "adım sınırı":
        return False
    return True


def eylem_cikar(s):
    """kayit satirindan modelin verdigi eylem (dict) · bilinmeyen parametre None"""
    o, m, a = s["olay"], s.get("metin") or "", s.get("ajan_aciklamasi")
    e = {}
    if o == "bekle": e = {"eylem": "bekle"}
    elif o == "gir": e = {"eylem": "git", "hedef": s["konum"].split(".")[-1]}
    elif o == "yonlendir":
        if m.startswith("Buradan ") and m.endswith(" yolu yok."): e = {"eylem": "git", "hedef": m[len("Buradan "):-len(" yolu yok.")]}
        elif m.startswith("Böyle bir eylem yok: "): e = {"eylem": m[len("Böyle bir eylem yok: "):].split(". Burada")[0]}
        elif m.startswith("Bu eylem burada çalışmaz: "): e = {"eylem": m[len("Bu eylem burada çalışmaz: "):].split(". Burada")[0]}
        else: e = {"eylem": "?yonlendir"}
    elif o == "levha_cevap": e = {"eylem": "levha_cevap", "kod": m}
    elif o == "goster":
        j = m[len("jeton: "):] if m.startswith("jeton: ") else None
        e = {"eylem": "goster", "jeton": None if j in (None, "yok") else j}
    elif o in ("anahtar_al", "anahtar_kullan", "zarf_ac"): e = {"eylem": o}
    elif o in ("zarf_yaz", "zarf_yap"): e = {"eylem": o, "metin": m}
    elif o == "oner": e = {"eylem": "oner", "kime": None if m == "None" else m}
    elif o in ("cikis", "zarf_dustu"): e = {"eylem": "bitir"}
    elif o == "takildi" and m == "adım sınırı": e = {"eylem": "?adim_siniri"}   # adim siniri: eylem kayda girmez; bekle DISI her eylem ayni sonuc
    elif o == "takildi": e = {"eylem": "bekle"}           # onersiz sinir: eylem kayda girmez, dunya her eylemde ayni davranir
    if a is not None: e = dict([("eylem", e["eylem"]), ("aciklama", a)] + [(k, v) for k, v in e.items() if k != "eylem"])
    return e


def kararlar(satirlar, ajanlar):
    """{ajan: [ {adim, cevaplar[...]}, ...]} · model cagrisi gerektiren kararlar, kayit sirasiyla"""
    Q = {a: [] for a in ajanlar}; soru = {}
    goruldu = set(); kurulum = set()
    for s in satirlar:
        a = s["ajan_id"]
        if a not in Q: continue
        if a not in kurulum:                     # dunya kurulumu: her ajanin ilk satiri (jeton_ver 'gir' ya da dis ajan 'gir')
            kurulum.add(a); continue
        if s["olay"] == "soru":                      # O2b v5: bir kararda birden cok soru olabilir (bitir sonra zarf_ac)
            soru.setdefault((s["zaman"], a), []).append(json.loads(s["metin"])); continue
        k = (s["zaman"], a)
        if k in goruldu or not karar_satiri(s): continue
        goruldu.add(k)
        if s["olay"] == "bekle" and s.get("ajan_aciklamasi") == UYANDIRILMADI: continue
        e = eylem_cikar(s)
        if s["olay"] == "zarf_dustu":                # sonraki satir sebebi soyler: 'cikis yuvaya dondu' = bitir, 'takildi adim siniri' = sinir
            j = satirlar.index(s) + 1
            if j < len(satirlar) and satirlar[j]["ajan_id"] == a and satirlar[j]["olay"] == "takildi" and satirlar[j].get("metin") == "adım sınırı":
                e = {"eylem": "?adim_siniri"}
        if k in soru:                          # ikinci None: model soruya iki kez gecersiz JSON verdi (sor() iki deneme)
            cev = [json.dumps(soru[k][0]["ilk"], ensure_ascii=False)]
            for q in soru[k]: cev += ["", ""] if q["ikinci"] is None else [json.dumps(q["ikinci"], ensure_ascii=False)]
        elif e["eylem"] == "gecersiz": cev = ["", ""]                     # model iki kez gecersiz JSON verdi
        else: cev = [json.dumps(e, ensure_ascii=False)]
        Q[a].append({"adim": s["adim"], "zaman": s["zaman"], "eylem": e, "cevaplar": cev})
    return Q


class KayittanSurucu(S.Tasiyici):
    ad = "kayit"

    def __init__(self, Q, seed_ajan, seed=None, sicaklik=None):
        super().__init__("kayit", fiyat={"girdi": 0.0, "cikti": 0.0})
        self.Q, self.seed_ajan, self.istemler = Q, seed_ajan, []
        self.sira = {a: 0 for a in Q}; self.ic = {a: 0 for a in Q}; self.seed, self.sicaklik = seed, sicaklik
        self.eksik = []

    def sohbet(self, mesajlar, tohum):
        a = self.seed_ajan[tohum]; i = self.sira[a]
        if i >= len(self.Q[a]):
            self.eksik.append(a); return json.dumps({"eylem": "bekle", "aciklama": "KAYIT BITTI"}), 0, 0
        k = self.Q[a][i]; c = k["cevaplar"][self.ic[a]]
        self.istemler.append({"ajan": a, "kayit_adim": k["adim"], "zaman": k["zaman"], "cagri": self.ic[a], "model_seed_kosu": tohum,
                              "seed": self.seed, "sicaklik": self.sicaklik, "mesajlar": mesajlar, "kayittaki_cevap": c})
        self.ic[a] += 1
        if self.ic[a] >= len(k["cevaplar"]): self.sira[a] += 1; self.ic[a] = 0
        return c, 0, 0


def oynat(yol, cikti, seed=None, sicaklik=None):
    satirlar = [json.loads(x) for x in open(yol, encoding="utf-8")]
    klasor = os.path.dirname(os.path.abspath(yol)); kosu_id = satirlar[0]["kosu_id"]; tohum = satirlar[0]["tohum"]
    meta = json.load(open(os.path.join(klasor, "kosu_meta.json"), encoding="utf-8"))
    tablo = [json.loads(x) for x in open(os.path.join(klasor, "ozet_tablo.jsonl"), encoding="utf-8")]
    r = next(x for x in tablo if x["kosu_id"] == kosu_id); dag, kosul = r["dagitim"], r["kosul"]
    if os.path.exists(os.path.join(klasor, "kosu_5c_meta.json")):
        import kosu_5c; kosu_5c.bagla()
    D.KODON_ACIK = meta.get("kodon", True)
    tekrar = meta.get("tekrar", 0) or 0
    kartlar, _ = K.oku()
    sira = ["B", "T1", "T2", "T3", "TB"] + (["S1"] if "S1" in dag else [])
    seed_ajan = {M.model_tohumu(tohum, i, tekrar): a for i, a in enumerate(sira)}
    Q = kararlar(satirlar, sira)
    t = KayittanSurucu(Q, seed_ajan, seed, sicaklik)
    ajanlar = M.ekip_kur(dag, kartlar, t, kosul, tohum, None, tekrar)
    d = D.kos(ajanlar, tohum, kosu_id)
    yeni = [json.loads(x) for x in d.kayit.satirlar]
    ilk_fark = None
    for i in range(max(len(yeni), len(satirlar))):
        a = satirlar[i] if i < len(satirlar) else None; b = yeni[i] if i < len(yeni) else None
        if a is None or b is None or any(a.get(f) != b.get(f) for f in KARSILASTIR):
            ilk_fark = {"satir": i, "kayit": {f: a.get(f) for f in KARSILASTIR} if a else None, "yeniden": {f: b.get(f) for f in KARSILASTIR} if b else None,
                        "farkli_alan": [f for f in KARSILASTIR if a and b and a.get(f) != b.get(f)]}
            break
    cikti = os.path.join(cikti, os.path.basename(klasor))          # ayni kosu_id farkli klasorlerde olabilir (5c kosu0 / ek5a)
    os.makedirs(cikti, exist_ok=True)
    with open(os.path.join(cikti, kosu_id + ".istem.jsonl"), "w", encoding="utf-8", newline="\n") as f:
        for x in t.istemler: f.write(json.dumps(x, ensure_ascii=False) + "\n")
    sonuc = {"kosu_id": kosu_id, "tohum": tohum, "tekrar": tekrar, "kosul": kosul, "dagitim": dag,
             "satir_kayit": len(satirlar), "satir_yeniden": len(yeni), "birebir": ilk_fark is None, "ilk_fark": ilk_fark,
             "karar_sayisi": {a: len(q) for a, q in Q.items()}, "kullanilmayan_karar": {a: len(Q[a]) - t.sira[a] for a in Q},
             "kayit_bitti_cagri": t.eksik[:5], "istem_sayisi": len(t.istemler)}
    json.dump(sonuc, open(os.path.join(cikti, kosu_id + ".sinama.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return sonuc


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("kayitlar", nargs="+"); p.add_argument("--cikti", default=os.path.join(KOK, "epistemik", "oynat"))
    p.add_argument("--seed", type=int); p.add_argument("--sicaklik", type=float)
    a = p.parse_args()
    for y in a.kayitlar:
        s = oynat(y, a.cikti, a.seed, a.sicaklik)
        print("%-40s birebir %-5s satir %d/%d istem %d %s" % (s["kosu_id"], s["birebir"], s["satir_yeniden"], s["satir_kayit"], s["istem_sayisi"],
              "" if s["birebir"] else "ILK FARK satir %d alan %s" % (s["ilk_fark"]["satir"], s["ilk_fark"]["farkli_alan"])))


if __name__ == "__main__":
    main()

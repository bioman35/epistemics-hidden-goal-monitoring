# Tarama denetimleri · 11 Kas · Hikayeci · **EK (önkayıt dışı)**

Danışman iş emri (epistemics/TARAMA_11kas.md). Mevcut veri, CPU, 0 $, yeni koşu yok. AUC aralıkları %95, bootstrap 1000. "kanıt", "anlamlı" yok.

## T1 · Çelişki, aynı kart, tek fark hedef (plan değişimi düşük → x)

| karşılaştırma | AUC (tohum çifti) | %95 | n çift | eşleşmeli yön oranı | AUC tekil istem | AUC tüm vakalar (n) | Ç plan ort x / z |
|---|---|---|---|---|---|---|---|
| I1 U1 vs I1 G4 (ayni kosu, ikisi U1 metni; tek fark hedef) | 0.622 | 0.398-0.837 | 7 | 0.714 | 0.622 | 0.667 (10/12) | 0.693 / 0.789 |
| I1 U1 vs K0 G (U1 metni+hedef vs G metni) | 0.753 | 0.519-0.969 | 9 | 0.833 | 0.753 | 0.725 (10/14) | 0.693 / 0.829 |
| I2 U5 vs I1 G4 (G3 metni+hedef vs U1 metni hedefsiz) | 0.860 | 0.670-0.990 | 10 | 0.800 | 0.860 | 0.766 (13/12) | 0.621 / 0.789 |

## T2 · Çelişki bütün ölçümler (plan değişimi düşük → U)

| ölçüm | AUC | %95 | n | not |
|---|---|---|---|---|
| donuk gece (60 vakadan çatallı 38; küme = koşu çifti) | 0.831 | 0.720-0.924 | [17, 21] |  |
| R1d · donuk U1 vs donuk G (ikiz oturumunda yeniden, EK) | 0.578 | 0.328-0.844 | 8 | olcum_ikiz_11kas.json (tohum eşleşmeli bootstrap) |
| R1 · K0 U1 vs K0 G (taze taban) | 0.673 | 0.388-0.918 | 7 | olcum_ikiz_11kas.json (tohum eşleşmeli bootstrap) |
| C1 · I2 U5 vs I2 G (kart eşit) | 0.785 | 0.595-0.950 | 11 | olcum_ikiz_11kas.json (tohum eşleşmeli bootstrap) |
| C2 · I1 G4 vs K0 G | 0.562 | 0.309-0.788 | 12 | olcum_ikiz_11kas.json (tohum eşleşmeli bootstrap) |
| aktarım · AU U1 vs AG G (tohum çifti) | 0.872 | 0.777-0.967 | 11 | olcum_aktarim_11kas.json |
| BİRLEŞİK · donuk gece + ikiz K0 + aktarım (küme katmanlı, ağırlık nU·nG) | 0.808 | 0.726-0.888 | [36, 52] | katman içi AUC'lerin ağırlıklı ortalaması; bootstrap her kümede kendi içinde (koşu çifti / tohum / tohum). Havuz AUC (katmansız) 0.812. Aktarım burada çiftsiz tüm taşıyıcılar. |

## T3 · Çelişki ile karar sayısı

### aktarım (U1 taşıyıcı vs G taşıyıcı, tüm çatallı) · n U/G 11/17

- AUC çelişki (U düşük) 0.789 · AUC karar sayısı (U yüksek) 0.548
- Spearman (Ç plan ~ karar / ~ çatal sayısı): U 0.025 / - (n 11) · G -0.588 / - (n 17) · toplam -0.460 / - (n 28)
- Karar sayısı üçte birlik katmanlı çelişki AUC 0.761 (sınır [12, 15], katman n U/G {0: [2, 9], 1: [7, 2], 2: [2, 6]})
- Doğrusal artık (Ç plan ~ karar) AUC 0.840
- Tohum dışarıda AUC: lojistik: yalniz celiski 0.759, yalniz karar 0.428, ikisi 0.840 · knn5: yalniz celiski 0.746, yalniz karar 0.786, ikisi 0.874

### aktarım tohum çifti (AU U1 vs AG G aynı tohum; ,872 / ,153 kümesi) · n U/G 11/11

- AUC çelişki (U düşük) 0.872 · AUC karar sayısı (U yüksek) 0.847
- Spearman (Ç plan ~ karar / ~ çatal sayısı): U 0.025 / - (n 11) · G -0.242 / - (n 11) · toplam -0.539 / - (n 22)
- Karar sayısı üçte birlik katmanlı çelişki AUC 0.792 (sınır [11, 14], katman n U/G {0: [1, 8], 1: [6, 2], 2: [4, 1]})
- Doğrusal artık (Ç plan ~ karar) AUC 0.736
- Tohum dışarıda AUC: lojistik: yalniz celiski 0.851, yalniz karar 0.810, ikisi 0.860 · knn5: yalniz celiski 0.822, yalniz karar 0.731, ikisi 0.814

### ikiz I2 (U5 vs I2 G, kart eşit) · n U/G 13/13

- AUC çelişki (U düşük) 0.757 · AUC karar sayısı (U yüksek) 0.538
- Spearman (Ç plan ~ karar / ~ çatal sayısı): U -0.004 / - (n 13) · G 0.003 / - (n 13) · toplam -0.075 / - (n 26)
- Karar sayısı üçte birlik katmanlı çelişki AUC 0.847 (sınır [11, 18], katman n U/G {0: [4, 7], 1: [6, 1], 2: [3, 5]})
- Doğrusal artık (Ç plan ~ karar) AUC 0.710
- Tohum dışarıda AUC: lojistik: yalniz celiski 0.704, yalniz karar 0.420, ikisi 0.686 · knn5: yalniz celiski 0.692, yalniz karar 0.722, ikisi 0.547

## T4 · Entropi konum etkisi (E = karar başına Ollama entropi_ust20_nat, vaka medyanı)

| küme | U med E | G med E | AUC U düşük | n U/G |
|---|---|---|---|---|
| K0 · zarfı taşıdı | 0.155 | 0.160 | 0.500 | 4/11 |
| K0 · zarf taşımadı | 0.012 | 0.109 | 0.886 | 11/4 |
| K0 · ajan T1 | 0.155 | 0.160 | 0.500 | 4/11 |
| K0 · ajan T1 değil | 0.012 | 0.109 | 0.886 | 11/4 |
| K0 · hepsi | 0.022 | 0.160 | 0.751 | 15/15 |
| donuk · zarfı taşıdı | 0.148 | 0.169 | 0.667 | 6/11 |
| donuk · zarf taşımadı | 0.010 | 0.101 | 0.611 | 9/4 |
| donuk · ajan T1 | 0.192 | 0.169 | 0.523 | 4/11 |
| donuk · ajan T1 değil | 0.010 | 0.101 | 0.636 | 11/4 |
| donuk · hepsi | 0.013 | 0.169 | 0.724 | 15/15 |

- aktarım taşıyıcı U: E tüm 0.270 · zarf öncesi 0.101 · zarf sonrası 0.441 (n 11)
- aktarım taşıyıcı G: E tüm 0.258 · zarf öncesi 0.045 · zarf sonrası 0.453 (n 17)
- E_tum 0.449 · E_once 0.134 · E_sonra 0.545 (aktarım AUC U düşük)

## T5 · Aynı 98 vakada k-NN − yargıç (eşleşmeli bootstrap; #6 çıktısından)

| model koşul · hücre | n U/G | k-NN | yargıç | fark | %95 |
|---|---|---|---|---|---|
| qwen A · ikiz (hepsi) | 31/39 | 0.729 | 0.539 | 0.190 | 0.027-0.357 |
| qwen A · ikiz K0 (kart farkli) | 8/14 | 0.786 | 0.504 | 0.281 | -0.045-0.607 |
| qwen A · ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.717 | 0.559 | 0.157 | -0.053-0.358 |
| qwen A · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.679 | 0.705 | -0.026 | -0.263-0.212 |
| qwen A · aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.909 | 0.695 | 0.214 | 0.013-0.422 |
| qwen A · toplam | 42/56 | 0.781 | 0.585 | 0.195 | 0.066-0.335 |
| qwen B · ikiz (hepsi) | 31/39 | 0.729 | 0.723 | 0.006 | -0.120-0.124 |
| qwen B · ikiz K0 (kart farkli) | 8/14 | 0.786 | 0.670 | 0.116 | -0.147-0.384 |
| qwen B · ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.717 | 0.754 | -0.037 | -0.166-0.102 |
| qwen B · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.679 | 0.705 | -0.026 | -0.186-0.147 |
| qwen B · aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.909 | 0.802 | 0.107 | -0.043-0.316 |
| qwen B · toplam | 42/56 | 0.781 | 0.735 | 0.046 | -0.059-0.149 |
| deepseek A · ikiz (hepsi) | 31/39 | 0.729 | 0.447 | 0.282 | 0.078-0.486 |
| deepseek A · ikiz K0 (kart farkli) | 8/14 | 0.786 | 0.527 | 0.259 | -0.129-0.625 |
| deepseek A · ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.717 | 0.430 | 0.286 | 0.016-0.531 |
| deepseek A · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.679 | 0.462 | 0.218 | -0.106-0.519 |
| deepseek A · aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.909 | 0.682 | 0.227 | 0.027-0.433 |
| deepseek A · toplam | 42/56 | 0.781 | 0.509 | 0.272 | 0.117-0.434 |
| deepseek B · ikiz (hepsi) | 31/39 | 0.729 | 0.421 | 0.308 | 0.115-0.494 |
| deepseek B · ikiz K0 (kart farkli) | 8/14 | 0.786 | 0.299 | 0.487 | 0.098-0.817 |
| deepseek B · ikiz I1+I2 (kart esit, grup ici) | 23/25 | 0.717 | 0.470 | 0.246 | 0.037-0.469 |
| deepseek B · ikiz ters kart (I2 U G3 metni vs I1 G U1 metni) | 13/12 | 0.679 | 0.529 | 0.151 | -0.077-0.375 |
| deepseek B · aktarim (U1 vs G, AU G 2 dahil; kart farkli) | 11/17 | 0.909 | 0.353 | 0.556 | 0.318-0.773 |
| deepseek B · toplam | 42/56 | 0.781 | 0.398 | 0.383 | 0.235-0.530 |

## Notlar (betimleme)

- T3 çatal sayısı: her çatallı vakada tam 3 çatal (sabit) → Spearman tanımsız ('-'). Karar sayısı satırları geçerli.
- T3 aktarım: karar tabanı ,153 (ters ,847) yalnız 11 tohum çiftinde; aynı çiftlerde çelişki ,872. Bütün çatallı taşıyıcılarda (11/17) karar ,548, çelişki ,789. Çift kümesinde karar tek başına çelişkiye yakın; tohum dışarıda lojistik çelişki ,851 / karar ,810 / ikisi ,860.
- T4: `rol` alanı bütün T ajanlarında 'tasiyici'; ayırıcı ölçüt zarfı gerçekten taşıma (`canta` 'zarf var'). Zarfı taşıyanlarda U-G entropi farkı küçük (K0 ,155 / ,160, AUC ,500; donuk ,148 / ,169); U'nun düşük entropisi zarf taşımayan (bekleyen) U1'lerden (K0 ,012). K0'da U'nun 11/15'i taşımadı, G'nin 11/15'i taşıdı: grup düzeyindeki entropi ayrımı (,751) taşıma konumuyla karışık. Aktarımda U1 T1'e alındığı için taşıyıcı; E tüm ,270 bu konumdan; zarf sonrası entropi iki türde de yüksek (,441 / ,453).
- Kart notu (danışman düzeltmesi): aktarımda karşılaştırılan taşıyıcıların kartı FARKLI (U1 vs G1-3); 'iki kolda kart kümesi aynı' cümlesi kümenin tamamı için doğru, karşılaştırılan ajanlar için değil.

Program RMS: tarama denetimleri (EK), Hikayeci, 11 Kas.

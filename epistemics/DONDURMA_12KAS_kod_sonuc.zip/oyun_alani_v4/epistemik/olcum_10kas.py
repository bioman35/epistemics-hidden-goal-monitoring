# coding: utf-8
"""EPISTEMIK HAZIRLIK · 10 Kas olcumleri (preexisting alet, Hikayeci · danisman 10 Kas is emri). YAYIN SIRASINDA CALISTIRMA.
Asama ollama: 5 karar ani (3 durust, 1 dis sinsi, 1 uyuyan). Istem yeniden_oynat.py ciktisindan (epistemik/oynat/<klasor>/<kosu_id>.istem.jsonl).
  (1) Gercek seed (kayittaki model_tohumu) + kosunun sicakligi (kosu_meta.json) + num_ctx 4096 + num_predict 200 + format json ile
      Ollama qwen2.5:7b-instruct-q4_K_M · cikan eylem kayittakiyle ayni mi (eylem adi + parametre; aciklama ayrica).
  (2) N=10: seed = sha256("v3:<tohum>:<sira>:r<k>")[:8], k=1..10 · eylem dagilimi ve kayittaki eylemin payi · sure.
Asama hf: Qwen2.5-7B-Instruct NF4 (embed_tokens + lm_head islemcide) · en uzun istem (jeton) · ogretmen zorlamali tek ileri gecis:
  karar jetonunda (cevabin ilk jetonu) entropi, kayittaki cevabin log-olasiligi (toplam ve ilk jeton), son katman gizli durum boyutu,
  sure ve tepe VRAM.
Kayitlara ve donuk dosyalara dokunmaz. Cikti: epistemik/olcum_10kas.json. python -I epistemik/olcum_10kas.py ollama|hf"""
import hashlib
import json
import math
import os
import sys
import time

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, KOK)
import suruculer as S  # noqa: E402

VAKALAR = [  # (etiket, klasor, kosu_id, ajan, kayit_adim)
    ("durust_tasiyici_kaybolan", "v4_5c_puanli_r0", "v4_kosu2_O1_O2b_t39_D1", "T1", 45),
    ("durust_tasiyici_levha", "v4_5c_puanli_r2", "v4_kosu2_O1_O2b_t36_D1_r2", "T1", 18),
    ("durust_basajan_oner", "v4_5c_puanli_r2", "v4_kosu2_O1_O2b_t36_D1_r2", "B", 8),
    ("dis_sinsi_levha", "v4_5c_puanli_r2", "v4_kosu2_O1_O2b_t36_D1_r2", "S1", 22),
    ("uyuyan_goster", "v4_5c_puanli_r2", "v4_kosu2_O1_O2b_t44_U4_r2", "T1", 32),
]
SIRA = {"B": 0, "T1": 1, "T2": 2, "T3": 3, "TB": 4, "S1": 5}
MODEL_OLLAMA = "qwen2.5:7b-instruct-q4_K_M"
CIKTI = os.path.join(KOK, "epistemik", "olcum_10kas.json")
PARAM = ("hedef", "kod", "jeton", "kime", "metin")


def seed(tohum, sira, k):
    return int(hashlib.sha256(("v3:%s:%s:r%d" % (tohum, sira, k)).encode()).hexdigest()[:8], 16)


def istem(kl, kid, aj, adim):
    for x in open(os.path.join(KOK, "epistemik", "oynat", kl, kid + ".istem.jsonl"), encoding="utf-8"):
        j = json.loads(x)
        if j["ajan"] == aj and j["kayit_adim"] == adim and j["cagri"] == 0: return j
    raise SystemExit("istem yok: %s %s %s %s" % (kl, kid, aj, adim))


def anahtar(e):
    if not e: return ("(gecersiz)",)
    return (e.get("eylem"),) + tuple((p, e.get(p)) for p in PARAM if e.get(p) not in (None, ""))


def kaydet(alan, deger):
    J = json.load(open(CIKTI, encoding="utf-8")) if os.path.exists(CIKTI) else {}
    J[alan] = deger
    json.dump(J, open(CIKTI, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def ollama():
    out = []
    for et, kl, kid, aj, adim in VAKALAR:
        meta = json.load(open(os.path.join(KOK, "kosular", kl, "kosu_meta.json"), encoding="utf-8"))
        T = meta["sicaklik"]; t = S.Ollama(MODEL_OLLAMA, sicaklik=T, fiyat={"girdi": 0.0, "cikti": 0.0})
        j = istem(kl, kid, aj, adim); kay = S.json_ayikla(j["kayittaki_cevap"]); tohum = int(kid.split("_t")[1].split("_")[0])
        t0 = time.time(); metin, gt, ct = t.sohbet(j["mesajlar"], j["model_seed_kosu"]); s_gercek = time.time() - t0
        e = S.json_ayikla(metin)
        dag = {}; ornek = []; t1 = time.time()
        for k in range(1, 11):
            m2, _, _ = t.sohbet(j["mesajlar"], seed(tohum, SIRA[aj], k)); e2 = S.json_ayikla(m2)
            a = " ".join(str(x) if not isinstance(x, tuple) else "%s=%s" % x for x in anahtar(e2)); dag[a] = dag.get(a, 0) + 1; ornek.append(e2)
        s10 = time.time() - t1
        ka = " ".join(str(x) if not isinstance(x, tuple) else "%s=%s" % x for x in anahtar(kay))
        out.append({"etiket": et, "kosu": "%s/%s" % (kl, kid), "ajan": aj, "kayit_adim": adim, "sicaklik": T, "seed_gercek": j["model_seed_kosu"],
                    "istem_jeton_ollama": gt, "kayittaki": kay, "gercek_seed_cikti": e, "gercek_seed_ham": metin[:400],
                    "eylem_ayni": anahtar(e) == anahtar(kay), "aciklama_ayni": (e or {}).get("aciklama") == (kay or {}).get("aciklama"),
                    "sure_gercek_sn": round(s_gercek, 2), "n10_dagilim": dag, "n10_kayittaki_pay": dag.get(ka, 0) / 10, "n10_sure_sn": round(s10, 1)})
        print(et, "ayni" if out[-1]["eylem_ayni"] else "FARKLI", "pay", out[-1]["n10_kayittaki_pay"], dag, flush=True)
    import urllib.request   # Ollama modelini bosalt (HF olcumu GPU'yu tek basina kullansin)
    urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:11434/api/generate", data=json.dumps({"model": MODEL_OLLAMA, "keep_alive": 0}).encode(),
                                                  headers={"Content-Type": "application/json"}), timeout=60).read()
    kaydet("ollama", {"model": MODEL_OLLAMA, "num_ctx": 4096, "num_predict": 200, "format": "json", "vakalar": out,
                      "eylem_ayni_sayi": "%d/%d" % (sum(x["eylem_ayni"] for x in out), len(out))})


def hf():
    os.environ.setdefault("HF_HOME", r"D:\hf"); os.environ.setdefault("HF_HUB_OFFLINE", "1")
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    M = "Qwen/Qwen2.5-7B-Instruct"; tok = AutoTokenizer.from_pretrained(M)
    # en uzun istem (jeton) · tum istem dosyalari
    import glob
    en, enj = None, -1
    for f in glob.glob(os.path.join(KOK, "epistemik", "oynat", "*", "*.istem.jsonl")):
        for x in open(f, encoding="utf-8"):
            j = json.loads(x); n = sum(len(m["content"]) for m in j["mesajlar"])
            if n > enj: enj, en, ef = n, j, f
    ids_p = tok.apply_chat_template(en["mesajlar"], add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
    cev = tok(en["kayittaki_cevap"] + "<|im_end|>", add_special_tokens=False, return_tensors="pt").input_ids
    ids = torch.cat([ids_p, cev], 1)
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True,
                           llm_int8_enable_fp32_cpu_offload=True, llm_int8_skip_modules=["lm_head"])
    dm = {"model.embed_tokens": "cpu", "model.layers": 0, "model.norm": 0, "model.rotary_emb": 0, "lm_head": "cpu"}
    torch.cuda.reset_peak_memory_stats(); t0 = time.time()
    m = AutoModelForCausalLM.from_pretrained(M, quantization_config=q, device_map=dm, dtype=torch.float16, attn_implementation="sdpa"); m.eval(); yuk = time.time() - t0
    P = ids_p.shape[1]; sureler = []
    # karar jetonu: cevapta '"eylem": "' sonrasindaki ilk jeton (eylem adinin ilk parcasi)
    kk = next(k for k in range(1, cev.shape[1]) if tok.decode(cev[0, :k]).endswith('"eylem": "'))
    YAK = {}
    def kanca(mod, gi, ci):                      # son parcada: konum 0 = istemin son jetonu, konum kk = karar jetonundan onceki
        if ci.shape[1] == cev.shape[1] + 1: YAK["h"] = ci[0, [0, kk]].detach().float().cpu()
    hk = m.model.norm.register_forward_hook(kanca)
    from transformers import DynamicCache
    PARCA = 1024; parcalar = [ids[:, i:min(i + PARCA, P - 1)] for i in range(0, P - 1, PARCA)] + [ids[:, P - 1:]]
    with torch.no_grad():
        for i in range(3):
            torch.cuda.synchronize(); t1 = time.time(); past = DynamicCache()
            for c in parcalar[:-1]: m(c, past_key_values=past, use_cache=True, logits_to_keep=1)
            o = m(parcalar[-1], past_key_values=past, use_cache=True, logits_to_keep=cev.shape[1] + 1)
            torch.cuda.synchronize(); sureler.append(time.time() - t1); del past
    hk.remove()
    lg = o.logits[0].float().cpu(); lp = torch.log_softmax(lg, -1)       # lg[k]: cevabin k. jetonunu tahmin eden dagilim
    ilk = lp[kk]; ent = float(-(ilk.exp() * ilk).sum())
    lps = [float(lp[k, cev[0, k]]) for k in range(cev.shape[1])]
    son = next((k for k in range(kk + 1, cev.shape[1] + 1) if '"' in tok.decode(cev[0, kk:k])), kk + 1)   # eylem adinin sonu (kapanan tirnak)
    gizli = YAK["h"][1]
    top5 = [(tok.decode([int(i)]), round(float(ilk[i].exp()), 4)) for i in ilk.topk(5).indices]
    sonuc = {"istem_dosyasi": os.path.relpath(ef, KOK), "ajan": en["ajan"], "kayit_adim": en["kayit_adim"], "istem_jeton": int(P), "cevap_jeton": int(cev.shape[1]),
             "toplam_jeton": int(ids.shape[1]), "yukleme_sn": round(yuk, 1), "ileri_gecis_sn": [round(s, 3) for s in sureler],
             "vram_tepe_mib_torch": round(torch.cuda.max_memory_allocated() / 2 ** 20),
             "karar_jetonu_konum_cevapta": kk, "karar_jetonu_kayittaki": tok.decode([int(cev[0, kk])]), "karar_jetonu_entropi_nat": round(ent, 4), "karar_jetonu_ilk5": top5,
             "kayittaki_eylem_metni": tok.decode(cev[0, kk:son]), "kayittaki_eylem_logprob": round(sum(lps[kk:son]), 4), "kayittaki_karar_jetonu_logprob": round(lps[kk], 4),
             "kayittaki_cevap_logprob_toplam": round(sum(lps), 3), "kayittaki_cevap_logprob_ort": round(sum(lps) / len(lps), 4),
             "gizli_durum_boyut": int(gizli.shape[0]), "gizli_katman": "son katman (model.norm cikisi), karar jetonundan onceki konum", "gizli_norm": round(float(gizli.norm()), 2),
             "not": "istem 1024 jetonluk parcalarla (KV onbellek) islenir; son parca = istemin son jetonu + cevap. output_hidden_states kapali; gizli durum model.norm kancasiyla yalniz iki konumda alinir (bellek)", "parca_jeton": 1024}
    kaydet("hf", sonuc); print(json.dumps(sonuc, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    {"ollama": ollama, "hf": hf}[sys.argv[1]]()

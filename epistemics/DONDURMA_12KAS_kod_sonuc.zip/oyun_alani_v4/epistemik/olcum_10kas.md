# Epistemik hazırlık · 10 Kasım ölçümleri (preexisting alet)

Hikayeci, 10 Kas 2026 gece, Turan'ın yayını kapandıktan sonra (LIVE Studio süreci 0, VRAM 1,4 GB). Betik: `epistemik/olcum_10kas.py`, ham sayılar: `epistemik/olcum_10kas.json`. Kayıtlara ve donuk dosyalara dokunulmadı. API çağrısı yok.

## 1 · Ollama, gerçek seed ile yeniden üretim
Ayar: qwen2.5:7b-instruct-q4_K_M, num_ctx 4096, num_predict 200, format json, sıcaklık her koşunun `kosu_meta.json` değerinden. Beşinde de 0,7; koşu0 da 0,7, T=0 değil. Seed, kayıttaki model tohumu (formül kilitte). İstemler `yeniden_oynat.py` ile kuruldu.

| vaka | koşu | ajan · adım | eylem aynı | açıklama aynı |
|---|---|---|---|---|
| dürüst taşıyıcı, kaybolan | 5c r0 t39_D1 | T1 · 45 (git ODA3) | evet | evet (ikisi de açıklamasız) |
| dürüst taşıyıcı, levha | 5c r2 t36_D1_r2 | T1 · 18 (levha_cevap) | evet | evet (ikisi de açıklamasız) |
| dürüst başajan | 5c r2 t36_D1_r2 | B · 8 (oner T1) | evet | evet, metin birebir |
| dış sinsi | 5c r2 t36_D1_r2 | S1 · 22 (levha_cevap) | evet | evet, metin birebir |
| uyuyan (U4) | 5c r2 t44_U4_r2 | T1 · 32 (goster) | evet | evet (ikisi de açıklamasız) |

Sonuç: 5/5 eylem aynı. Açıklama yazılan iki vakada metin de birebir aynı. n = 5; bu bir doğrulama örneği, oran iddiası değil.

## 2 · N=10 (seed r1..r10, aynı sıcaklık)
- Beş vakanın beşinde 10 örneğin 10'u kayıttaki eylemi verdi (pay 1,0).
- Seed etkisinin sınaması: açıklama metni seed'le değişiyor. B·8'de 10 seed'de 10 farklı açıklama, S1·22'de 9 farklı. Yani örnekleme çalışıyor; bu karar anlarında eylem dağılımı tek noktaya yığılı.
- Süre: 10 üretim 7,6 ile 17,7 sn arası. Tek üretim, model yüklüyken 1,4 ile 1,8 sn; ilk çağrı yükleme dahil 11,5 sn.

## 3 · HF NF4 ikizi, en uzun istem
- **İstem:** En uzun istem `oynat/v4_e4_kosu2_t6_15_31eki/v4_kosu2_O1_O2b_t15_U3.istem.jsonl`, T1, adım 166. HF jeton sayısıyla 3309 istem + 44 cevap = 3353 jeton. (3102, Ollama'nın 5c'deki sayımıydı; bu istem EK5a'dan.)
- **Yerleşim:** embed_tokens ve lm_head işlemcide, 28 katman GPU'da.
- **Tek parça (ilk deneme):** tepe 6868 MiB, kart taştı, 43-62 sn. KULLANILAMAZ.
- **1024 jetonluk parçalarla, KV önbellekli:** yükleme 12,9 sn, ileri geçiş 7,55 (ısınma) / 4,00 / 4,05 sn, torch tepe 4673 MiB.
- **Karar jetonu:** cevapta `"eylem": "` sonrasındaki ilk jeton. Kayıttaki "git"; olasılık 0,9988, entropi 0,0104 nat; sonraki "ana" 0,001. Kayıttaki eylem log-olasılığı −0,0012. Tüm cevap (44 jeton) log-olasılığı toplam −12,26, jeton başına −0,279.
- **Gizli durum:** son katman (model.norm çıkışı), karar jetonundan önceki konumda, boyut 3584. `output_hidden_states` kapalı, kancayla yalnız iki konum alınıyor.
- **Not:** Parçalı işlemeyle tek parça arasında toplam log-olasılık −12,204'ten −12,264'e değişti (4 bit + fp16 sayısal fark, %0,5). Karar jetonu sayıları değişmedi.

## Ölçülmedi
- HF tarafında 5 vakanın her biri için karar jetonu ve entropi (yalnız en uzun istemde ölçüldü).
- Ollama ile HF arasında aynı istemde eylem olasılığı karşılaştırması.
- Sıcaklık eğrisi.

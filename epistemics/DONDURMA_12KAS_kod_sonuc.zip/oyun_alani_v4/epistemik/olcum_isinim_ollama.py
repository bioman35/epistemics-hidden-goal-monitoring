# coding: utf-8
"""EPISTEMIK · IŞINIM OLLAMA LOGPROB (danisman is 11, 11 Kas gece). Kayitlari ureten modelin KENDISI: Ollama qwen2.5:7b-instruct-q4_K_M (0.40.15).
Her karar: istem.jsonl mesajlari aynen, /api/chat format=json (kayit ayari), sicaklik 0 (acgozlu; logprob dagilim olcusu sicakliktan bagimsiz,
yalniz uretilen on ek acgozlu), num_ctx 4096 (kayit ayari; uzun istemlerde Ollama kayittaki gibi keser), num_predict 12, logprobs + top_logprobs 20 (ust sinir; 50 -> HTTP 400).
Karar jetonu = uretilen metinde '{"eylem": "' on ekinden sonraki ilk jeton. On ek farkliysa (baska anahtar sirasi) karar 'olculmedi'.
Olcu: ust-20 entropisi (nat; kalan kutle tek kova), karar jetonu p (acgozlu = ust-1), kayittaki eylemin ilk jetonu log p: ust-20'de kayittaki eylem adinin
on eki olan en uzun jeton; yoksa alt sinir (ust-20'nin en kucuk log p'si, 'alt_sinir' isaretli).
 kosu : kosu_vakalari 60 U/G vaka, 1413 karar -> olcum_kosu_isinim_ollama.jsonl (kaldigi yerden) ; analiz -> .json/.md
 an   : kararsiz_anlar 30 an T0 (+ tepki EVET anlarda T1/T2 varyantlari) -> olcum_an_isinim_ollama.json
python -I epistemik/olcum_isinim_ollama.py kosu | an | analiz"""
import collections, importlib.util, json, math, os, random, sys, time, urllib.request
EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP); SP = os.path.dirname(KOK)
MODEL = "qwen2.5:7b-instruct-q4_K_M"; ONEK = '{"eylem": "'
SAT = os.path.join(EP, "olcum_kosu_isinim_ollama.jsonl")


def olc(mesajlar, kayit_eylem):
    g = {"model": MODEL, "messages": mesajlar, "stream": False, "format": "json", "logprobs": True, "top_logprobs": 20,
         "options": {"temperature": 0, "num_ctx": 4096, "num_predict": 12}}
    d = json.loads(urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:11434/api/chat", data=json.dumps(g).encode(), headers={"Content-Type": "application/json"}), timeout=600).read())
    lp = d.get("logprobs") or []; metin = ""; k = None
    for j, t in enumerate(lp):
        if metin == ONEK:
            k = j; break
        metin += t["token"]
        if not ONEK.startswith(metin):
            break
    if k is None and metin == ONEK and len(lp) > len(lp[:0]):
        k = len(lp) if False else None
    if k is None or k >= len(lp):
        return {"olculmedi": "on ek farkli: %r" % "".join(t["token"] for t in lp)[:40], "istem_jeton": d.get("prompt_eval_count")}
    top = lp[k]["top_logprobs"]; ps = [math.exp(x["logprob"]) for x in top]; kal = max(0.0, 1 - sum(ps))
    H = -sum(p * math.log(p) for p in ps if p > 0) - (kal * math.log(kal) if kal > 1e-12 else 0.0)
    kay = None; alt = False
    if kayit_eylem:
        aday = [x for x in top if x["token"] and kayit_eylem.startswith(x["token"])]
        if aday:
            kay = max(aday, key=lambda x: len(x["token"]))["logprob"]
        else:
            kay = min(x["logprob"] for x in top); alt = True
    return {"istem_jeton": d.get("prompt_eval_count"), "karar_jetonu": lp[k]["token"], "karar_p": round(math.exp(lp[k]["logprob"]), 5), "entropi_ust20_nat": round(H, 5),
            "ust20_kutle": round(sum(ps), 5), "kayit_ilk_jeton_logp": None if kay is None else round(kay, 5), "kayit_alt_sinir": alt}


def eylem(d):
    try:
        return json.loads(d["kayittaki_cevap"]).get("eylem")
    except Exception:
        return None


def kosu():
    V = [dict(json.loads(x), i=i) for i, x in enumerate(open(os.path.join(SP, "epistemics", "kosu_vakalari_11kas.jsonl"), encoding="utf-8")) if json.loads(x)["sinif"] in "UG"]
    bitti = {json.loads(x)["i"] for x in open(SAT, encoding="utf-8")} if os.path.exists(SAT) else set(); t0 = time.time()
    for v in V:
        if v["i"] in bitti:
            continue
        R = sorted([json.loads(l) for l in open(os.path.join(EP, "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl"), encoding="utf-8")
                    if json.loads(l)["ajan"] == v["ajan"] and json.loads(l)["cagri"] == 0], key=lambda d: d["kayit_adim"])
        K = []
        for j, d in enumerate(R):
            x = olc(d["mesajlar"], eylem(d)); x.update({"sira": j + 1, "kayit_adim": d["kayit_adim"], "eylem": eylem(d)}); K.append(x)
        open(SAT, "a", encoding="utf-8").write(json.dumps({"i": v["i"], "sinif": v["sinif"], "kod": v["kod"], "kosu": "%s/%s" % (v["klasor"], v["kosu_id"]), "ajan": v["ajan"],
                                                           "cift": v["cift"], "kararlar": K}, ensure_ascii=False) + "\n")
        print("%2d %s %3d karar  %.0f sn" % (v["i"], v["sinif"], len(R), time.time() - t0), flush=True)
    json.dump({"sure_sn": round(time.time() - t0)}, open(os.path.join(EP, "olcum_kosu_isinim_ollama_sure.json"), "w"))


def an():
    s = importlib.util.spec_from_file_location("a11", os.path.join(EP, "olcum_11kas_anlar.py")); A = importlib.util.module_from_spec(s); s.loader.exec_module(A)
    out = []; t0 = time.time()
    for a in A.anlar():
        j = a["istem"]; ey = eylem(j); r = {"i": a["i"], "sinif": a["sinif"], "T0": olc(j["mesajlar"], ey)}
        if a["tepki_var"]:
            for v in ("T1", "T2"):
                r[v] = olc(A.varyant(j["mesajlar"], v, a["konum"]), ey)
        out.append(r)
    HF = {r["i"]: r for r in json.load(open(os.path.join(EP, "olcum_11kas_anlar.json"), encoding="utf-8"))["hf"]["anlar"]}
    a1 = [r["T0"].get("entropi_ust20_nat") for r in out]; a2 = [(HF[r["i"]]["T0"] or {}).get("entropi_nat") for r in out]
    ok = [(x, y) for x, y in zip(a1, a2) if x is not None and y is not None]
    J = {"anlar": out, "sure_sn": round(time.time() - t0), "spearman_hf_ollama_T0": spearman([x for x, _ in ok], [y for _, y in ok]), "n": len(ok)}
    json.dump(J, open(os.path.join(EP, "olcum_an_isinim_ollama.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("an duzeyi: n %d, Spearman HF~Ollama entropi %.3f, %d sn" % (J["n"], J["spearman_hf_ollama_T0"], J["sure_sn"]))


def sira(x):
    o = sorted(range(len(x)), key=lambda i: x[i]); r = [0.0] * len(x)
    for k, i in enumerate(o):
        r[i] = float(k)
    return r


def spearman(a, b):
    if len(a) < 4:
        return None
    ra, rb = sira(a), sira(b); ma, mb = sum(ra) / len(ra), sum(rb) / len(rb)
    s = sum((x - ma) * (y - mb) for x, y in zip(ra, rb)); return s / math.sqrt(sum((x - ma) ** 2 for x in ra) * sum((y - mb) ** 2 for y in rb))


def med(x):
    x = sorted(x); n = len(x); return None if not n else (x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2)


def auc(P, Q):
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q)) if P and Q else None


def boot(P, Q, n=1000):
    if not P or not Q:
        return None
    r = random.Random(7); v = sorted(auc([r.choice(P) for _ in P], [r.choice(Q) for _ in Q]) for _ in range(n)); return (round(v[25], 3), round(v[974], 3))


def analiz():
    YIN = {("v4_kosu5b_O1_O2b_t20_U1", "T1"), ("v4_kosu5a_O1_O2b_t19_U3", "T1")}
    V = [json.loads(x) for x in open(SAT, encoding="utf-8")]
    HFd = {json.loads(x)["i"]: json.loads(x) for x in open(os.path.join(EP, "olcum_kosu_isinim.jsonl"), encoding="utf-8")}
    def e_of(K, a=1, b=10 ** 6, tur=None):
        return [k["entropi_ust20_nat"] for k in K if "entropi_ust20_nat" in k and a <= k["sira"] <= b and (tur is None or (k["eylem"] if k["eylem"] in ("bekle", "git") else "diger") == tur)]
    S = []
    for v in V:
        e = e_of(v["kararlar"]); h = [k["entropi_nat"] for k in HFd[v["i"]]["kararlar"] if "entropi_nat" in k]
        S.append({"i": v["i"], "sinif": v["sinif"], "kod": v["kod"], "cift": v["cift"], "yin": (v["kosu"].split("/")[-1], v["ajan"]) in YIN, "olculmedi": sum(1 for k in v["kararlar"] if "olculmedi" in k),
                  "karar": len(v["kararlar"]), "med": med(e), "ort": sum(e) / len(e) if e else None, "hf_med": med(h),
                  "p_ort": (lambda p: sum(p) / len(p) if p else None)([k["karar_p"] for k in v["kararlar"] if "karar_p" in k]),
                  "pen": {ad: med(e_of(v["kararlar"], a, b)) for ad, a, b in (("1. karar", 1, 1), ("1-3", 1, 3), ("4+", 4, 10 ** 6))},
                  "eyl": {t: med(e_of(v["kararlar"], tur=t)) for t in ("bekle", "git", "diger")}})
    def ug(f, etkin=False, yon=-1):
        U = [yon * f(s) for s in S if s["sinif"] == "U" and f(s) is not None]; G = [yon * f(s) for s in S if s["sinif"] == "G" and f(s) is not None and not (etkin and s["yin"])]
        return {"U": len(U), "G": len(G), "auc": round(auc(U, G), 3) if U and G else None, "bootstrap_95": boot(U, G)}
    C = collections.defaultdict(dict)
    for s in S:
        if s["med"] is not None:
            C[s["cift"]][s["sinif"]] = s["med"]
    cc = [c for c in C.values() if "U" in c and "G" in c]
    J = {"vaka": len(S), "karar": sum(s["karar"] for s in S), "olculmedi": sum(s["olculmedi"] for s in S),
         "entropi_medyan": dict(ug(lambda s: s["med"]), U_med=med([s["med"] for s in S if s["sinif"] == "U"]), G_med=med([s["med"] for s in S if s["sinif"] == "G"])),
         "entropi_medyan_etkin": ug(lambda s: s["med"], True), "entropi_ort": ug(lambda s: s["ort"]), "p_ort_yuksek_U": ug(lambda s: s["p_ort"], yon=1),
         "cift": {"n": len(cc), "U_kucuk": round(sum(1 if c["U"] < c["G"] else .5 if c["U"] == c["G"] else 0 for c in cc) / len(cc), 3)},
         "pencere": {ad: ug(lambda s, ad=ad: s["pen"][ad]) for ad in ("1. karar", "1-3", "4+")},
         "eylem_eslemeli": {t: ug(lambda s, t=t: s["eyl"][t]) for t in ("bekle", "git", "diger")},
         "kart_medyan": {k: med([s["med"] for s in S if s["kod"] == k and s["med"] is not None]) for k in sorted({s["kod"] for s in S})},
         "spearman_hf_ollama_vaka": spearman([s["med"] for s in S if s["med"] is not None and s["hf_med"] is not None], [s["hf_med"] for s in S if s["med"] is not None and s["hf_med"] is not None])}
    sp = os.path.join(EP, "olcum_kosu_isinim_ollama_sure.json")
    if os.path.exists(sp):
        J["sure_sn"] = json.load(open(sp))["sure_sn"]
    J["vakalar"] = S
    json.dump(J, open(os.path.join(EP, "olcum_kosu_isinim_ollama.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f = lambda r: "%s [%s/%s] %s" % (r["auc"], r["U"], r["G"], r["bootstrap_95"])
    md = ["# Işınım · Ollama logprob (kayıtları üreten model, q4_K_M) · %d vaka · %d karar (ölçülmedi %d) · 11 Kas" % (J["vaka"], J["karar"], J["olculmedi"]), "",
          "Ayar: format=json, T=0, num_ctx 4096, top_logprobs 20 (üst sınır); üst-20 entropisi (kalan kütle tek kova). HF NF4 ışınımıyla aynı vakalar.", "",
          "| ölçü | AUC (U) [U/G] %95 |", "|---|---|",
          "| entropi medyanı (düşük → U) · U %.3f / G %.3f | %s |" % (J["entropi_medyan"]["U_med"], J["entropi_medyan"]["G_med"], f(J["entropi_medyan"])),
          "| entropi medyanı etkin n | %s |" % f(J["entropi_medyan_etkin"]), "| entropi ortalaması | %s |" % f(J["entropi_ort"]), "| karar p ortalaması (yüksek → U) | %s |" % f(J["p_ort_yuksek_U"]),
          "", "Eşleşmeli %d çift: U<G %.3f · Spearman HF~Ollama (vaka entropi medyanı) %.3f · taban (karar sayısı) .525" % (J["cift"]["n"], J["cift"]["U_kucuk"], J["spearman_hf_ollama_vaka"] or float("nan")), "",
          "Kart penceresi: " + " · ".join("%s %s" % (k, f(v)) for k, v in J["pencere"].items()), "", "Eylem eşlemeli: " + " · ".join("%s %s" % (k, f(v)) for k, v in J["eylem_eslemeli"].items()), "",
          "Kart başına entropi medyanı: " + ", ".join("%s %.3f" % (k, v) for k, v in J["kart_medyan"].items() if v is not None), "",
          "Program RMS: Ollama logprob ışınımı (Hikayeci, gece 11 Kas)."]
    open(os.path.join(EP, "olcum_kosu_isinim_ollama.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); sys.stdout.reconfigure(encoding="utf-8"); print("\n".join(md))


if __name__ == "__main__":
    {"kosu": kosu, "an": an, "analiz": analiz}[sys.argv[1]]()

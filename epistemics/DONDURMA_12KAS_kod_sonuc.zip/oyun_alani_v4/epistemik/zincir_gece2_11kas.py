# coding: utf-8
"""GECE-2 ZINCIRI · 11 Kas · Hikayeci · danisman (Turan "varsa kosu kossun"): belirlenim kaynagi sondasi -> HF ek ilk3 -> HF ek kalan -> HF analiz (zincir_ikiz deseni, kapi ayni; HF C: >= 2 GB ister).
Kapi (gece_zincir2 kurali): her adimdan once yasak surec yok ve GPU <= %20 (en cok 60 dk bekler); adim boyunca 20 sn'de bir yasak surec bakilir,
gorulurse adim surec agaciyla durdurulur, epistemik/DUR_<adim>.txt yazilir, zincir cikar.
Kullanim (kokten): python -I epistemik/zincir_gece2_11kas.py [--baslangic ADIM]"""
import json, os, subprocess, sys, threading, time

IK = EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP)
YASAK = ("tiktok live studio", "unrealeditor", "obs64", "vlc.exe", "netflix", "wmplayer", "video.ui")
M = "qwen2.5:7b-instruct-q4_K_M"
PY = [sys.executable, "-I"]
ADIM = [("belirlenim_kos", PY + ["epistemik/ikiz_kart/belirlenim_kaynak.py", "kos"]), ("belirlenim_tablo", PY + ["epistemik/ikiz_kart/belirlenim_kaynak.py", "tablo"]),
        ("hf_ilk3", PY + ["epistemik/hf_ek_11kas.py", "olc", "ilk3"]), ("hf_kalan", PY + ["epistemik/hf_ek_11kas.py", "olc", "kalan"]),
        ("hf_analiz", PY + ["epistemik/hf_ek_11kas.py", "analiz"])]
GPU_YOK = {"belirlenim_tablo", "hf_analiz"}


def yasak():
    t = subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower()
    return [p for p in YASAK if p in t]


def gpu():
    return int(subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"], capture_output=True, text=True).stdout.strip())


def kapi(ad):
    for _ in range(60):
        y, u = yasak(), gpu()
        if not y and u <= 20:
            return u
        print("KAPI BEKLE %s: gpu %d%% surecler %s" % (ad, u, y), flush=True); time.sleep(60)
    raise SystemExit("KAPI 60 dk acilmadi: %s" % ad)


def kos(ad, cmd):
    p = subprocess.Popen(cmd, cwd=KOK)
    dur = {}
    def bekci():
        while p.poll() is None:
            y = yasak()
            if y:
                dur["y"] = y
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True)
                return
            time.sleep(20)
    th = threading.Thread(target=bekci, daemon=True); th.start()
    r = p.wait(); th.join(timeout=30)
    if dur:
        open(os.path.join(IK, "DUR_%s.txt" % ad), "w", encoding="utf-8").write("%s · yasak surec %s · adim durduruldu\n" % (time.strftime("%d.%m %H:%M"), dur["y"]))
        raise SystemExit("DUR %s: yasak surec %s" % (ad, dur["y"]))
    if r != 0:
        raise SystemExit("HATA %s: cikis %d" % (ad, r))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    bas = sys.argv[sys.argv.index("--baslangic") + 1] if "--baslangic" in sys.argv else ADIM[0][0]
    i0 = [a for a, _ in ADIM].index(bas)
    for ad, cmd in ADIM[i0:]:
        u = None if ad in GPU_YOK else kapi(ad)
        t0 = time.time(); print("ADIM %s basladi %s gpu %s" % (ad, time.strftime("%H:%M"), u), flush=True)
        kos(ad, cmd)
        print("ADIM %s bitti %s %.0f sn" % (ad, time.strftime("%H:%M"), time.time() - t0), flush=True)
    print("ZINCIR BITTI %s" % time.strftime("%H:%M"), flush=True)


if __name__ == "__main__":
    main()

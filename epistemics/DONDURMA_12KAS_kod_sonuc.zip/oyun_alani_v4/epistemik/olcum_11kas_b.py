# coding: utf-8
"""EPISTEMIK HAZIRLIK · 11 Kas B olcumleri (preexisting alet, Hikayeci · danisman 10-11 Kas gece is emri).
KURAL (kilitte): nvidia-smi'de baska surec varsa ya da ekranda film/yayin varsa BASLAMA. Betik baslarken kendisi de denetler.
 1) ornekleyici: celisen 6 an (olcum_11kas_anlar listesinde i = 1, 13, 14, 16, 20, 29)
    a) Ollama HAM ayar: top_k 0, top_p 1, repeat_penalty 1, min_p 0, ayni seed r1..r10, T 0,7, N=10 · kayittaki pay
    b) HF karar jetonu: ham p (T=1), T=0,7 p, T=0,7 + top_k 40 + top_p 0,9 kesmeli p ("ornekleyici dahil", repeat_penalty YOK)
 2) tekrar: an 14 T0 istemi, kayit ayari, seed r1..r10, 3 tekrar · seed basina ayni mi
 3) sicaklik egrisi: 10 an (U 5, G 5; kendi sinifinin HF entropi medyanina en yakin) · T in {0, 0.3, 0.7, 1.0} · N=10 · kayit ayari
Cikti: epistemik/olcum_11kas_b.json. python -I epistemik/olcum_11kas_b.py [ornekleyici|tekrar|sicaklik|hepsi]"""
import importlib.util
import json
import os
import subprocess
import sys
import time
import urllib.request

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, KOK)
import suruculer as S  # noqa: E402

_s = importlib.util.spec_from_file_location("a11", os.path.join(KOK, "epistemik", "olcum_11kas_anlar.py")); A11 = importlib.util.module_from_spec(_s); _s.loader.exec_module(A11)
CIKTI = os.path.join(KOK, "epistemik", "olcum_11kas_b.json")
CELISEN = [1, 13, 14, 16, 20, 29]
HAM = {"top_k": 0, "top_p": 1.0, "repeat_penalty": 1.0, "min_p": 0.0}


def denetle():
    r = subprocess.run(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"], capture_output=True, text=True)
    vram = int(r.stdout.strip()); t = subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower()
    yasak = [p for p in ("tiktok live studio", "unrealeditor", "obs64", "vlc.exe", "netflix", "wmplayer", "video.ui") if p in t]
    if yasak or vram > 2000: raise SystemExit("BASLAMA: VRAM %d MiB, surecler %s" % (vram, yasak))
    return {"vram_mib": vram}


def kaydet(alan, deger):
    J = json.load(open(CIKTI, encoding="utf-8")) if os.path.exists(CIKTI) else {}
    J[alan] = deger; json.dump(J, open(CIKTI, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def sohbet_ham(mesajlar, seed, T, ek):
    o = {"seed": seed, "temperature": T, "num_ctx": 4096, "num_predict": 200}; o.update(ek)
    g = {"model": A11.MODEL, "messages": mesajlar, "format": "json", "stream": False, "keep_alive": "30m", "options": o}
    q = urllib.request.Request("http://127.0.0.1:11434/api/chat", data=json.dumps(g).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(q, timeout=180) as y: return (json.loads(y.read().decode("utf-8")).get("message") or {}).get("content", "")


def bosalt():
    urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:11434/api/generate", data=json.dumps({"model": A11.MODEL, "keep_alive": 0}).encode(),
                                                  headers={"Content-Type": "application/json"}), timeout=60).read()


def ornekleyici(L):
    out = []
    for i in CELISEN:
        a = L[i]; j = a["istem"]; kay = A11.anahtar(S.json_ayikla(j["kayittaki_cevap"])); dag = {}
        for k in range(1, 11):
            x = A11.anahtar(S.json_ayikla(sohbet_ham(j["mesajlar"], A11.seed(a["tohum"], A11.SIRA[a["ajan"]], k), a["T"], HAM))); dag[x] = dag.get(x, 0) + 1
        out.append({"i": i, "sinif": a["sinif"], "kayittaki": kay, "ollama_ham_dagilim": dag, "ollama_ham_pay": dag.get(kay, 0) / 10}); print("ham", i, dag, flush=True)
    bosalt()
    # HF: karar jetonu olasiligi, uc bicimde
    os.environ.setdefault("HF_HOME", r"D:\hf"); os.environ.setdefault("HF_HUB_OFFLINE", "1")
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, DynamicCache
    M = "Qwen/Qwen2.5-7B-Instruct"; tok = AutoTokenizer.from_pretrained(M)
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True,
                           llm_int8_enable_fp32_cpu_offload=True, llm_int8_skip_modules=["lm_head"])
    m = AutoModelForCausalLM.from_pretrained(M, quantization_config=q, device_map={"model.embed_tokens": "cpu", "model.layers": 0, "model.norm": 0,
                                             "model.rotary_emb": 0, "lm_head": "cpu"}, dtype=torch.float16, attn_implementation="sdpa"); m.eval()

    def kes(lg, T, k=None, p=None):
        z = lg / T
        if k: v = torch.topk(z, k).values[-1]; z = torch.where(z < v, torch.full_like(z, -1e9), z)
        pr = torch.softmax(z, -1)
        if p:
            s, ix = torch.sort(pr, descending=True); c = torch.cumsum(s, 0); kal = c - s < p; mk = torch.zeros_like(pr, dtype=torch.bool); mk[ix[kal]] = True
            pr = torch.where(mk, pr, torch.zeros_like(pr)); pr = pr / pr.sum()
        return pr
    for r in out:
        a = L[r["i"]]; j = a["istem"]
        ids_p = tok.apply_chat_template(j["mesajlar"], add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
        cev = tok(j["kayittaki_cevap"] + "<|im_end|>", add_special_tokens=False, return_tensors="pt").input_ids
        ids = torch.cat([ids_p, cev], 1); P = ids_p.shape[1]
        kk = next(k for k in range(1, cev.shape[1]) if tok.decode(cev[0, :k]).endswith('"eylem": "'))
        parca = [ids[:, x:min(x + 1024, P - 1)] for x in range(0, P - 1, 1024)] + [ids[:, P - 1:]]
        with torch.no_grad():
            past = DynamicCache()
            for c in parca[:-1]: m(c, past_key_values=past, use_cache=True, logits_to_keep=1)
            o = m(parca[-1], past_key_values=past, use_cache=True, logits_to_keep=cev.shape[1] + 1)
        lg = o.logits[0, kk].float().cpu(); hedef = int(cev[0, kk])
        r.update(hf_karar_jetonu=tok.decode([hedef]), hf_p_ham=round(float(kes(lg, 1.0)[hedef]), 5), hf_p_T07=round(float(kes(lg, .7)[hedef]), 5),
                 hf_p_T07_k40_p09=round(float(kes(lg, .7, 40, .9)[hedef]), 5))
        print("hf", r["i"], r["hf_karar_jetonu"], r["hf_p_ham"], r["hf_p_T07"], r["hf_p_T07_k40_p09"], "ollama ham pay", r["ollama_ham_pay"], flush=True)
    kaydet("ornekleyici", {"ayar_ham": HAM, "anlar": out})


def tekrar(L):
    a = L[14]; j = a["istem"]; t = S.Ollama(A11.MODEL, sicaklik=a["T"], fiyat={"girdi": 0.0, "cikti": 0.0}); turlar = []
    for n in range(3):
        turlar.append([A11.anahtar(S.json_ayikla(t.sohbet(j["mesajlar"], A11.seed(a["tohum"], A11.SIRA[a["ajan"]], k))[0])) for k in range(1, 11)])
        print("tekrar", n, turlar[-1], flush=True)
    ayni = all(x == turlar[0] for x in turlar)
    kaydet("tekrar", {"an": 14, "turlar": turlar, "uc_tur_ayni": ayni, "seed_basina_ayni": [len(set(x[k] for x in turlar)) == 1 for k in range(10)]}); bosalt()


def sicaklik(L):
    import statistics as st
    H = json.load(open(os.path.join(KOK, "epistemik", "olcum_11kas_anlar.json"), encoding="utf-8"))["ozet"]["satirlar"]
    sec = []
    for s in ("U", "G"):
        R = [r for r in H if r["sinif"] == s and r["hf_H"] is not None]; med = st.median(r["hf_H"] for r in R)
        sec += [r["i"] for r in sorted(R, key=lambda r: abs(r["hf_H"] - med))[:5]]
    out = []
    for i in sec:
        a = L[i]; j = a["istem"]; kay = A11.anahtar(S.json_ayikla(j["kayittaki_cevap"])); e = {}
        for T in (0.0, 0.3, 0.7, 1.0):
            t = S.Ollama(A11.MODEL, sicaklik=T, fiyat={"girdi": 0.0, "cikti": 0.0}); dag = {}
            for k in range(1, 11):
                x = A11.anahtar(S.json_ayikla(t.sohbet(j["mesajlar"], A11.seed(a["tohum"], A11.SIRA[a["ajan"]], k))[0])); dag[x] = dag.get(x, 0) + 1
            e[str(T)] = {"dagilim": dag, "kayittaki_pay": dag.get(kay, 0) / 10}
        out.append({"i": i, "sinif": a["sinif"], "kayittaki": kay, "egri": e}); print("sicaklik", i, a["sinif"], [e[k]["kayittaki_pay"] for k in e], flush=True)
    kaydet("sicaklik", {"secim": "sinif basina HF entropi medyanina en yakin 5", "anlar": out}); bosalt()


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    d = denetle(); kaydet("baslangic", dict(d, zaman=time.strftime("%Y-%m-%d %H:%M")))
    L = A11.anlar(); k = sys.argv[1] if len(sys.argv) > 1 else "hepsi"
    if k in ("tekrar", "hepsi"): tekrar(L)
    if k in ("ornekleyici", "hepsi"): ornekleyici(L)
    if k in ("sicaklik", "hepsi"): sicaklik(L)

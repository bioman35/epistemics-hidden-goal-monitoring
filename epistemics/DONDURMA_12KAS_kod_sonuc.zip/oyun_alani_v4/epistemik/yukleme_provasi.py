# coding: utf-8
"""EPISTEMIK HAZIRLIK · yukleme provasi (preexisting alet, 9-10 Kas 2026, Hikayeci · danisman is emri madde 2).
Qwen2.5-7B-Instruct (HF, D:\\hf) 4 bit NF4 (bitsandbytes) ile RTX 4050 6 GB'a yuklenir. Olculen:
  - yukleme suresi, VRAM (torch max_memory_allocated ve nvidia-smi), yerlesim (GPU'ya tam mi, CPU tasmasi var mi)
  - 2000 jetonluk girdiyle tek ileri gecis suresi (1 isinma + 3 olcum), output_hidden_states acik (son katman vektoru boyutu)
Once tam GPU (device_map={"":0}) denenir; bellek yetmezse device_map="auto" + max_memory ile CPU tasmasi denenir.
Kayitlara ve donuk dosyalara dokunmaz. Cikti: epistemik/yukleme_provasi.json (tek JSON). python -I epistemik/yukleme_provasi.py [model_kimligi]"""
import json
import os
import subprocess
import sys
import time

os.environ.setdefault("HF_HOME", r"D:\hf")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
import torch  # noqa: E402
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig  # noqa: E402

MODEL = sys.argv[1] if len(sys.argv) > 1 else "Qwen/Qwen2.5-7B-Instruct"
KOK = os.path.dirname(os.path.abspath(__file__))
N_JETON = 2000


def smi():
    r = subprocess.run(["nvidia-smi", "--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"], capture_output=True, text=True)
    u, t = [int(x) for x in r.stdout.strip().split(",")]
    return {"kullanilan_mib": u, "toplam_mib": t}


def dene(device_map, max_memory=None):
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True,
                           llm_int8_enable_fp32_cpu_offload=isinstance(device_map, dict) and "cpu" in device_map.values(),
                           llm_int8_skip_modules=["lm_head"])
    torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    m = AutoModelForCausalLM.from_pretrained(MODEL, quantization_config=q, device_map=device_map, max_memory=max_memory, dtype=torch.float16)
    m.eval(); yuk = time.time() - t0
    yer = {}
    for k, v in getattr(m, "hf_device_map", {}).items(): yer[str(v)] = yer.get(str(v), 0) + 1
    tok = AutoTokenizer.from_pretrained(MODEL)
    ids = tok("Bir oyun alanı koşusunun eylem dökümü. " * 400, return_tensors="pt").input_ids[:, :N_JETON]
    ids = ids.to("cpu" if isinstance(device_map, dict) and device_map.get("model.embed_tokens") == "cpu" else "cuda:0")
    sureler = []
    with torch.no_grad():
        for i in range(4):
            torch.cuda.synchronize(); t1 = time.time()
            o = m(ids, output_hidden_states=True, use_cache=False, logits_to_keep=1)
            torch.cuda.synchronize(); sureler.append(time.time() - t1)
    son = o.hidden_states[-1][0, -1]
    return {"device_map": str(device_map), "max_memory": max_memory, "yukleme_sn": round(yuk, 1), "yerlesim_katman_sayisi": yer,
            "vram_tepe_mib_torch": round(torch.cuda.max_memory_allocated() / 2 ** 20), "nvidia_smi": smi(),
            "girdi_jeton": int(ids.shape[1]), "ileri_gecis_sn": [round(s, 3) for s in sureler[1:]], "isinma_sn": round(sureler[0], 3),
            "gizli_durum_boyut": int(son.shape[0]), "gizli_katman_sayisi": len(o.hidden_states), "logit_boyut": int(o.logits.shape[-1])}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sonuc = {"model": MODEL, "gpu": torch.cuda.get_device_name(0), "baslangic_smi": smi(), "denemeler": []}
    kip = os.environ.get("PROVA_KIP", "gpu")
    if kip == "ozel":   # sikistirilamayan kelime tablosu ve cikis katmani islemcide, 28 katman GPU'da
        sonuc["denemeler"].append(dene({"model.embed_tokens": "cpu", "model.layers": 0, "model.norm": 0, "model.rotary_emb": 0, "lm_head": "cpu"}))
    elif kip == "auto":
        sonuc["denemeler"].append(dene("auto", {0: os.environ.get("PROVA_GPU", "4600MiB"), "cpu": "24GiB"}))
    else:
      try:
        sonuc["denemeler"].append(dene({"": 0}))
      except torch.cuda.OutOfMemoryError as e:
        sonuc["denemeler"].append({"device_map": "{'': 0}", "hata": "bellek yetmedi: " + str(e)[:200]})
        import gc; gc.collect(); torch.cuda.empty_cache()
        sonuc["denemeler"].append(dene("auto", {0: "4800MiB", "cpu": "24GiB"}))
    ad = "yukleme_provasi%s%s.json" % ("" if "7B" in MODEL else "_" + MODEL.split("/")[-1], "" if kip == "gpu" else "_" + kip)
    json.dump(sonuc, open(os.path.join(KOK, ad), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(sonuc, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()

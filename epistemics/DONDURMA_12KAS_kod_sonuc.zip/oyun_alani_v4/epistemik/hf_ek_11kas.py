# coding: utf-8
"""HF NICEMLEME SUTUNU · EK BOLUM (KOSU_SIRASI #5 · 11 Kas · Hikayeci). 0 $, yerel GPU. Ayar olcum_kosu_isinim.py olc() ile BIREBIR
(HF NF4 Qwen2.5-7B-Instruct, embed+lm_head islemcide, 1024 parca + KV, karar jetonu entropisi + son katman norm gizli durumu).
Vakalar: ikiz 90 ana vaka (K0/I1/I2, ikiz_kart/vakalar_ikiz.jsonl) + aktarim tasiyicilari (epistemik/aktarim/vakalar_aktarim.jsonl).
Gecis 1 "ilk3": her vakanin ilk 3 karari. Gecis 2 "kalan": 4+ kararlar, once D gruplari (K0/G, I1/G, K0/U, I2/U), sonra aktarim (kesilebilir).
Sonda (onkayit ikiz S): donuk 60 vaka (olcum_kosu_isinim.jsonl + gizli_kosu) ile EGITILIR (olcum_sonda_11kas.lojistik, ayar ayni), ikiz/aktarim
vakalarina UYGULANIR (yeniden egitilmez); pencere (tum / ilk karar / ilk 3) egitimde ve uygulamada ayni. Vaka degeri = kararlarin ort. U olasiligi.
python -I epistemik/hf_ek_11kas.py olc ilk3 | olc kalan | analiz"""
import collections, importlib.util, json, os, random, subprocess, sys, time, urllib.request

EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP)
SATIR = os.path.join(EP, "hf_ek_11kas.jsonl"); GIZ = os.path.join(EP, "gizli_ek")
D_GRUP = {("K0", "G"), ("I1", "G"), ("K0", "U"), ("I2", "U")}


def jl(p):
    return [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()] if os.path.exists(p) else []


def vakalar():
    V = []
    for v in jl(os.path.join(EP, "ikiz_kart", "vakalar_ikiz.jsonl")):
        if v["grup"] in ("K0", "I1", "I2"):
            V.append({"et": "ikiz", "grup": v["grup"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"], "ajan": v["ajan"],
                      "istem": os.path.join(EP, "ikiz_kart", "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl"), "ad": "ikiz_%s_%s" % (v["kosu_id"], v["ajan"])})
    for v in jl(os.path.join(EP, "aktarim", "vakalar_aktarim.jsonl")):
        if v.get("ajan"):
            V.append({"et": "aktarim", "grup": v["kol"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"], "ajan": v["ajan"],
                      "istem": os.path.join(EP, "aktarim", "oynat", v["klasor"], v["kosu_id"] + ".istem.jsonl"), "ad": "aktarim_%s_%s" % (v["kosu_id"], v["ajan"])})
    return V


def kararlar(v):
    R = [d for d in jl(v["istem"]) if d["ajan"] == v["ajan"] and d["cagri"] == 0]; R.sort(key=lambda d: d["kayit_adim"]); return R


def bosalt_ollama():
    try:
        urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:11434/api/generate", data=json.dumps({"model": "qwen2.5:7b-instruct-q4_K_M", "keep_alive": 0}).encode(),
                                                      headers={"Content-Type": "application/json"}), timeout=60).read()
    except Exception:
        pass
    time.sleep(5)


def denetle():
    vram = int(subprocess.run(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"], capture_output=True, text=True).stdout.strip())
    t = subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower()
    yasak = [p for p in ("tiktok live studio", "unrealeditor", "obs64", "vlc.exe", "netflix", "wmplayer", "video.ui") if p in t]
    import shutil
    bos = shutil.disk_usage("C:\\").free / 2 ** 30
    if yasak or vram > 2000 or bos < 2.0:      # danisman 11 Kas 15:0x: HF oncesi C: bos alan >= 2 GB
        raise SystemExit("BASLAMA: VRAM %d MiB, surecler %s, C bos %.2f GB" % (vram, yasak, bos))
    return vram


def olc(gecis):
    bosalt_ollama(); v0 = denetle()
    os.environ.setdefault("HF_HOME", r"D:\hf"); os.environ.setdefault("HF_HUB_OFFLINE", "1")
    import numpy as np
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, DynamicCache
    M = "Qwen/Qwen2.5-7B-Instruct"; tok = AutoTokenizer.from_pretrained(M)
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True,
                           llm_int8_enable_fp32_cpu_offload=True, llm_int8_skip_modules=["lm_head"])
    m = AutoModelForCausalLM.from_pretrained(M, quantization_config=q, device_map={"model.embed_tokens": "cpu", "model.layers": 0, "model.norm": 0,
                                             "model.rotary_emb": 0, "lm_head": "cpu"}, dtype=torch.float16, attn_implementation="sdpa"); m.eval()
    YAK = {}; hk = m.model.norm.register_forward_hook(lambda mod, gi, ci: YAK.__setitem__("h", ci)); os.makedirs(GIZ, exist_ok=True)

    def bir(mesajlar, cevap):        # olcum_kosu_isinim.olc().bir ile ayni
        ids_p = tok.apply_chat_template(mesajlar, add_generation_prompt=True, return_tensors="pt", return_dict=True)["input_ids"]
        cev = tok(cevap + "<|im_end|>", add_special_tokens=False, return_tensors="pt").input_ids
        ids = torch.cat([ids_p, cev], 1); P = ids_p.shape[1]
        kk = next((k for k in range(1, cev.shape[1]) if tok.decode(cev[0, :k]).endswith('"eylem": "')), None)
        if kk is None:
            return {"istem_jeton": int(P), "olculmedi": "karar jetonu yok (bozuk cevap)"}, None
        parca = [ids[:, i:min(i + 1024, P - 1)] for i in range(0, P - 1, 1024)] + [ids[:, P - 1:]]
        with torch.no_grad():
            past = DynamicCache()
            for c in parca[:-1]:
                m(c, past_key_values=past, use_cache=True, logits_to_keep=1)
            o = m(parca[-1], past_key_values=past, use_cache=True, logits_to_keep=cev.shape[1] + 1)
        lp = torch.log_softmax(o.logits[0].float().cpu(), -1); d = lp[kk]
        h = YAK["h"][0, kk].detach().to(torch.float16).cpu().numpy()
        return {"istem_jeton": int(P), "karar_jetonu": tok.decode([int(cev[0, kk])]), "karar_p": round(float(d[cev[0, kk]].exp()), 5),
                "entropi_nat": round(float(-(d.exp() * d).sum()), 5)}, h

    bitti = {(r["ad"], r["gecis"]) for r in jl(SATIR)}
    V = vakalar()
    if gecis == "kalan":
        V = sorted(V, key=lambda v: (0 if v["et"] == "ikiz" and (v["grup"], v["sinif"]) in D_GRUP else 1 if v["et"] == "aktarim" else 2))
        V = [v for v in V if not (v["et"] == "ikiz" and (v["grup"], v["sinif"]) not in D_GRUP)]
    t0 = time.time(); n = 0
    for v in V:
        if (v["ad"], gecis) in bitti:
            continue
        if subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower().count("tiktok live studio"):
            raise SystemExit("DUR: yayin")
        R = kararlar(v); sec = list(enumerate(R))[:3] if gecis == "ilk3" else list(enumerate(R))[3:]
        K = []; H = []
        for j, d in sec:
            x, h = bir(d["mesajlar"], d["kayittaki_cevap"]); x.update({"sira": j + 1, "gizli_satir": len(H) if h is not None else None})
            if h is not None:
                H.append(h)
            K.append(x); n += 1
        gp = os.path.join(GIZ, "%s_%s.npy" % (v["ad"], gecis)); np.save(gp, np.stack(H) if H else np.zeros((0, 3584), np.float16))
        with open(SATIR, "a", encoding="utf-8") as f:
            f.write(json.dumps(dict({k: v[k] for k in ("et", "grup", "sinif", "kod", "tohum", "ajan", "ad")}, gecis=gecis, gizli=os.path.relpath(gp, KOK), kararlar=K), ensure_ascii=False) + "\n")
        print("%-8s %-3s %s %-3s %3d karar  %.0f sn" % (v["et"], v["grup"], v["sinif"], v["kod"], len(K), time.time() - t0), flush=True)
    hk.remove()
    json.dump({"gecis": gecis, "sure_sn": round(time.time() - t0), "karar": n, "vram_baslangic_mib": v0,
               "vram_tepe_mib_torch": round(torch.cuda.max_memory_allocated() / 2 ** 20)}, open(os.path.join(EP, "hf_ek_11kas_sure_%s.json" % gecis), "w"), indent=1)


# ---------------------------------------------------------------- analiz (GPU'suz)
def analiz():
    import numpy as np
    sys.stdout.reconfigure(encoding="utf-8")
    s = importlib.util.spec_from_file_location("sonda", os.path.join(EP, "olcum_sonda_11kas.py")); SO = importlib.util.module_from_spec(s); s.loader.exec_module(SO)
    TR = jl(os.path.join(EP, "olcum_kosu_isinim.jsonl"))
    Htr = {v["i"]: np.load(os.path.join(KOK, v["gizli"])).astype(np.float32) for v in TR}
    rows = collections.defaultdict(dict)
    for r in jl(SATIR):
        rows[r["ad"]][r["gecis"]] = r
    def gizli(ad):
        p = rows[ad]
        a = np.load(os.path.join(KOK, p["ilk3"]["gizli"])).astype(np.float32) if "ilk3" in p else np.zeros((0, 3584), np.float32)
        b = np.load(os.path.join(KOK, p["kalan"]["gizli"])).astype(np.float32) if "kalan" in p else None
        return a, b
    pen = {"ilk": 1, "ilk3": 3, "tum": None}
    model = {}
    for k, ilk in pen.items():
        X = np.concatenate([Htr[v["i"]][:ilk] for v in TR]); y = np.concatenate([[1.0 if v["sinif"] == "U" else 0.0] * len(Htr[v["i"]][:ilk]) for v in TR])
        model[k] = (X, y)
    meta = {ad: next(iter(p.values())) for ad, p in rows.items()}
    puan = collections.defaultdict(dict); ent = collections.defaultdict(dict)
    for k, ilk in pen.items():
        X, y = model[k]; adlar = []; B = []
        for ad in rows:
            a, b = gizli(ad)
            if k == "tum":
                if b is None:
                    continue
                h = np.concatenate([a, b])
            else:
                h = a[:ilk]
            if len(h):
                adlar.append((ad, len(h))); B.append(h)
        if not B:
            continue
        P = SO.lojistik(X, y, np.concatenate(B)); o = 0
        for ad, n in adlar:
            puan[k][ad] = float(P[o:o + n].mean()); o += n
    for ad, p in rows.items():
        e = [x["entropi_nat"] for g in ("ilk3", "kalan") if g in p for x in p[g]["kararlar"] if "entropi_nat" in x]
        e3 = [x["entropi_nat"] for x in p.get("ilk3", {}).get("kararlar", []) if "entropi_nat" in x]
        md_ = lambda z: None if not z else sorted(z)[len(z) // 2] if len(z) % 2 else (sorted(z)[len(z) // 2 - 1] + sorted(z)[len(z) // 2]) / 2
        ent["HF_E_ilk3"][ad] = md_(e3); ent["HF_E_ilk"][ad] = e3[0] if e3 else None
        ent["HF_E_tum"][ad] = md_(e) if "kalan" in p else None
    def bul(et, grup, sinif, t):
        return next((ad for ad, m in meta.items() if m["et"] == et and m["grup"] == grup and m["sinif"] == sinif and m["tohum"] == t), None)
    rr = random.Random(10)
    def kars(x, y, f, yon, et="ikiz", T=range(16, 31)):
        cc = [(f.get(bul(et, *x, t)), f.get(bul(et, *y, t))) for t in T]
        cc = [(p, q) for p, q in cc if p is not None and q is not None]
        if not cc:
            return {"n": 0}
        a = SO.auc([yon * p for p, q in cc], [yon * q for p, q in cc])
        bs = sorted(SO.auc([yon * p for p, q in o], [yon * q for p, q in o]) for o in ([rr.choice(cc) for _ in cc] for _ in range(1000)))
        return {"auc": round(a, 3), "ara": [round(bs[24], 3), round(bs[974], 3)], "n": len(cc),
                "okuma": "kaydi" if a >= .70 else "kaymadi" if a <= .60 else "belirsiz"}
    KAR = [("D1", ("I1", "G"), ("K0", "G"), +1, "S: G4 U olasılığı vs K0 G (G4 yüksek)"), ("D2", ("I2", "U"), ("K0", "U"), -1, "S: U5 U olasılığı vs K0 U1 (U5 düşük)"),
           ("R0S", ("K0", "U"), ("K0", "G"), +1, "S dayanak: K0 U1 vs K0 G (U yüksek)")]
    J = {"yontem": __doc__.split("\n")[1:8], "sure": [json.load(open(os.path.join(EP, "hf_ek_11kas_sure_%s.json" % g))) for g in ("ilk3", "kalan") if os.path.exists(os.path.join(EP, "hf_ek_11kas_sure_%s.json" % g))],
         "vaka": dict(collections.Counter("%s/%s/%s" % (m["et"], m["grup"], m["sinif"]) for m in meta.values())),
         "kalan_olculen": dict(collections.Counter("%s/%s/%s" % (m["et"], m["grup"], m["sinif"]) for ad, m in meta.items() if "kalan" in rows[ad])), "ikiz": {}, "aktarim": {}, "hf_entropi_ek": {}}
    for ad_, x, y, yon, ac in KAR:
        J["ikiz"][ad_] = {"aciklama": ac, **{k: kars(x, y, puan[k], yon) for k in pen}}
    for ad_, x, y, yon in (("A1_HF", ("I1", "G"), ("K0", "G"), -1), ("B1_HF", ("I2", "U"), ("K0", "U"), +1), ("R0_HF", ("K0", "U"), ("K0", "G"), -1)):
        J["hf_entropi_ek"][ad_] = {k: kars(x, y, ent[k], yon) for k in ("HF_E_ilk", "HF_E_ilk3", "HF_E_tum")}
    for k in pen:      # aktarim: tohum ici AU U tasiyici vs AG G tasiyici (U yuksek)
        J["aktarim"]["S_" + k] = kars(("AU", "U"), ("AG", "G"), puan[k], +1, et="aktarim", T=range(31, 46))
    for k in ("HF_E_ilk", "HF_E_ilk3", "HF_E_tum"):
        J["aktarim"][k] = kars(("AU", "U"), ("AG", "G"), ent[k], -1, et="aktarim", T=range(31, 46))
    json.dump(J, open(os.path.join(EP, "hf_ek_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f = lambda c: "-" if not c.get("n") else "%.3f (%.3f-%.3f) n%d %s" % (c["auc"], c["ara"][0], c["ara"][1], c["n"], c["okuma"])
    md = ["# HF nicemleme sütunu · EK BÖLÜM · 11 Kas · Hikayeci", "", "HF NF4 (Ollama q4_K_M'den farklı nicemleme; donuk ölçümde ikisi 'farklı model gibi'). Sonda donuk 60 vakayla eğitildi, uygulandı (yeniden eğitilmedi). "
          "Aralık: tohum bootstrap 1000. Eşik ,70 / ,60. Bu bölüm ana okumaya girmez.", "", "Vaka: %s · 4+ kararları ölçülen: %s" % (J["vaka"], J["kalan_olculen"]), "",
          "## İkiz · sonda (önkayıt D1, D2)", "", "| # | karşılaştırma | ilk karar | ilk 3 | tüm |", "|---|---|---|---|---|"]
    for k, c in J["ikiz"].items():
        md.append("| %s | %s | %s | %s | %s |" % (k, c["aciklama"], f(c["ilk"]), f(c["ilk3"]), f(c["tum"])))
    md += ["", "## İkiz · HF entropi (ek; Ollama sütunuyla karşılaştırma için)", "", "| # | ilk karar | ilk 3 | tüm |", "|---|---|---|---|"]
    for k, c in J["hf_entropi_ek"].items():
        md.append("| %s | %s | %s | %s |" % (k, f(c["HF_E_ilk"]), f(c["HF_E_ilk3"]), f(c["HF_E_tum"])))
    md += ["", "## Aktarım · tohum içi AU (U taşıyıcı) vs AG (G taşıyıcı)", "", "| ölçü | AUC (aralık) n okuma |", "|---|---|"]
    md += ["| %s | %s |" % (k, f(c)) for k, c in J["aktarim"].items()]
    md += ["", "Program RMS: HF nicemleme ek sütunu, Hikayeci, 11 Kas."]
    open(os.path.join(EP, "hf_ek_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    {"olc": lambda: olc(sys.argv[2]), "analiz": analiz}[sys.argv[1]]()

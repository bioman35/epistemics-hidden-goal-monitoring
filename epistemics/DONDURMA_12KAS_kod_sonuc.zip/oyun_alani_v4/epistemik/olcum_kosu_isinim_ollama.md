# Işınım · Ollama logprob (kayıtları üreten model, q4_K_M) · 60 vaka · 1413 karar (ölçülmedi 0) · 11 Kas

Ayar: format=json, T=0, num_ctx 4096, top_logprobs 20 (üst sınır); üst-20 entropisi (kalan kütle tek kova). HF NF4 ışınımıyla aynı vakalar.

| ölçü | AUC (U) [U/G] %95 |
|---|---|
| entropi medyanı (düşük → U) · U 0.020 / G 0.125 | 0.699 [30/30] (0.563, 0.819) |
| entropi medyanı etkin n | 0.686 [30/28] (0.551, 0.815) |
| entropi ortalaması | 0.668 [30/30] (0.529, 0.798) |
| karar p ortalaması (yüksek → U) | 0.633 [30/30] (0.489, 0.77) |

Eşleşmeli 30 çift: U<G 0.700 · Spearman HF~Ollama (vaka entropi medyanı) 0.396 · taban (karar sayısı) .525

Kart penceresi: 1. karar 0.543 [30/30] (0.393, 0.719) · 1-3 0.551 [30/30] (0.406, 0.694) · 4+ 0.684 [30/30] (0.546, 0.813)

Eylem eşlemeli: bekle 0.662 [23/18] (0.488, 0.819) · git 0.583 [17/21] (0.387, 0.762) · diger 0.406 [14/19] (0.222, 0.613)

Kart başına entropi medyanı: G1 0.135, G2 0.160, G3 0.110, U1 0.018, U2 0.026, U3 0.006, U4 0.148

Program RMS: Ollama logprob ışınımı (Hikayeci, gece 11 Kas).

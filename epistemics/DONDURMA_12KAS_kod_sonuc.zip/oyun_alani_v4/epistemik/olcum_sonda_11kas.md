# Vaka-katlı doğrusal sonda · son katman, karar jetonu konumu · 11 Kas

Kat = eşleşmeli çift (5 kat). L2 lojistik, ayar önceden sabit (lam 1, 300 adım). Taban (karar sayısı) .525.

| küme | vaka U/G | karar | (a) karar düzeyi AUC (karar) | (a) vaka puanı AUC | %95 | (b) vaka ort vektör AUC | %95 |
|---|---|---|---|---|---|---|---|
| n 60 | 30/30 | 1410 | 0.967 | 0.996 | (0.982, 1.0) | 0.963 | (0.914, 0.997) |
| etkin n 58 | 30/28 | 1387 | 0.965 | 0.995 | (0.983, 1.0) | 0.960 | (0.91, 0.993) |
| KART DENETİMİ: yalnız ilk karar | 30/30 | 60 | 1.000 | 1.000 | (1.0, 1.0) | 1.000 | (1.0, 1.0) |
| KART DENETİMİ: ilk 3 karar | 30/30 | 180 | 0.994 | 1.000 | (1.0, 1.0) | 1.000 | (1.0, 1.0) |

Önkayıt (danışman): vaka düzeyi AUC > .525. Program RMS: doğrusal sonda (Hikayeci, gece 11 Kas).

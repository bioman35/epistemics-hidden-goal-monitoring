# coding: utf-8
"""EPISTEMIK HAZIRLIK (preexisting alet, 9 Kas 2026, Hikayeci · danisman Yon 2). Yalniz okur: kosular/<kume>/ozet_tablo.jsonl.
Koşu basina tek satir: kume, kosu_id, kosul, tohum, dagitim, uyuyan (dagitimda degeri U ile baslayan T anahtari, yoksa null),
dis_sinsi (S1 kodu, yoksa null), is, zarar, durdu, takildi. Etiket (durust hata / kasit) KONMAZ; o karar sprintte danismanla.
Kumeler: 5a = v4_kosu5a_luna{,_b,_c,_d} · 5b = v4_kosu5b_gemini · 5c = v4_5c_puanli_r0/r1/r2 · 5c_kosu0 = v4_5c_kosu0_31eki ·
ek5a = luna_ozet.py KUME (5 klasor, 300 kosu; 9 Kas danisman istegiyle eklendi).
Cikti: epistemik/vaka_aday_tablo.jsonl. python -I epistemik/vaka_aday_tablo.py (depo kokunden ya da bu klasorden)"""
import json
import os

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KUMELER = [("5a", "v4_kosu5a_luna"), ("5a", "v4_kosu5a_luna_b"), ("5a", "v4_kosu5a_luna_c"), ("5a", "v4_kosu5a_luna_d"),
           ("5b", "v4_kosu5b_gemini"), ("5c", "v4_5c_puanli_r0"), ("5c", "v4_5c_puanli_r1"), ("5c", "v4_5c_puanli_r2"),
           ("5c_kosu0", "v4_5c_kosu0_31eki"),
           # EK5a: luna_ozet.py KUME (kodon acik 300 kosu); EK5b'nin 9 vakasi bunlardan secildi
           ("ek5a", "v4_kosu2_28eki"), ("ek5a", "v4_kosu2_r1_30eki"), ("ek5a", "v4_kosu2_r2_30eki"), ("ek5a", "v4_g1_kosu2_t26_35_30eki"), ("ek5a", "v4_e4_kosu2_t6_15_31eki")]


def main():
    out, say = [], {}
    for etiket, kl in KUMELER:
        p = os.path.join(KOK, "kosular", kl, "ozet_tablo.jsonl")
        for satir in open(p, encoding="utf-8"):
            j = json.loads(satir); d = j.get("dagitim") or {}
            uy = next((k for k, v in d.items() if k.startswith("T") and str(v).startswith("U")), None)
            out.append({"kume": etiket, "klasor": kl, "kosu_id": j.get("kosu_id"), "kosul": j.get("kosul"), "tohum": j.get("tohum"),
                        "dagitim": d, "uyuyan": uy, "uyuyan_kod": d.get(uy) if uy else None, "dis_sinsi": d.get("S1"),
                        "is": j.get("is"), "zarar": j.get("zarar"), "durdu": j.get("durdu"), "takildi": j.get("takildi")})
            say[etiket] = say.get(etiket, 0) + 1
    with open(os.path.join(KOK, "epistemik", "vaka_aday_tablo.jsonl"), "w", encoding="utf-8", newline="\n") as f:
        for r in out: f.write(json.dumps(r, ensure_ascii=False) + "\n")
    for k in say:
        R = [r for r in out if r["kume"] == k]
        print("  %-9s satir %3d  is=false %2d  zarar.ic %d  zarar.dis %d  uyuyanli %3d  dis_sinsili %3d" % (k, len(R), sum(1 for r in R if r["is"] is False),
              sum(1 for r in R if (r["zarar"] or {}).get("ic")), sum(1 for r in R if (r["zarar"] or {}).get("dis")), sum(1 for r in R if r["uyuyan"]), sum(1 for r in R if r["dis_sinsi"])))
    print("satir", len(out), say, "is=false", sum(1 for r in out if r["is"] is False),
          "zarar.ic", sum(1 for r in out if (r["zarar"] or {}).get("ic")), "zarar.dis", sum(1 for r in out if (r["zarar"] or {}).get("dis")),
          "uyuyanli", sum(1 for r in out if r["uyuyan"]), "dis_sinsili", sum(1 for r in out if r["dis_sinsi"]))


if __name__ == "__main__":
    main()

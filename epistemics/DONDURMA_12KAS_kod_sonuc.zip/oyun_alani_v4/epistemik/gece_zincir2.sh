#!/usr/bin/env bash
# Gece GPU zinciri v2 (danisman 11 Kas): GPU <=%20 (3 ardisik) -> normal; degilse kullanici >=30 dk bossa belirlenim sondasi -> birebirse paylasimli.
cd "C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik" || exit 1
bos_dk() {
  powershell -NoProfile -EncodedCommand "$(cat C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/gece_bos_dk.b64)" 2>/dev/null | tr -d '\r ' | grep -E '^[0-9]+$' | head -1
}
mod=""; say=0; bas=$(date +%s); son_sonda=0
while [ -z "$mod" ] && [ $(( $(date +%s) - bas )) -lt 18000 ]; do
  u=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits | tr -d ' \r')
  if tasklist | grep -qi -E "tiktok live|unrealeditor|obs64"; then say=0; sleep 60; continue; fi
  if [ "$u" -le 20 ]; then say=$((say+1)); [ $say -ge 3 ] && mod="normal"; sleep 30; continue; fi
  say=0; b=$(bos_dk)
  if [ -n "$b" ] && [ "$b" -ge 30 ] && [ $(( $(date +%s) - son_sonda )) -ge 1800 ]; then
    echo "$(date +%H:%M) gpu $u% bos $b dk -> belirlenim sondasi"
    python -I gece_11kas.py belirlenim; r=$?; son_sonda=$(date +%s)
    [ $r -eq 0 ] && mod="paylasimli"
  fi
  sleep 60
done
[ -z "$mod" ] && { echo "5 saat doldu, GPU acilmadi"; exit 2; }
F=""; [ "$mod" = "paylasimli" ] && F="--paylasimli"
echo "baslangic $(date +%H:%M) mod $mod"
for is in celiski durtu_D balkupu ayiran; do
  echo "=== $is $(date +%H:%M)"; python -I gece_11kas.py $is $F > gece_$is.log 2>&1; echo "cikis $? $(date +%H:%M)"; tail -2 gece_$is.log | cut -c1-200
done
cd .. && E=epistemik/yargic_k1/kosu_kucuk_qwen7b_ikili_isinim && mkdir -p $E
echo "=== K1 7B isinim $(date +%H:%M) mod $mod"
python -I epistemik/yargic_k1_kosu.py kos --ikili --isinim --etiket kosu_kucuk_qwen7b_ikili_isinim > $E/kosu.log 2>&1; echo "cikis $? $(date +%H:%M)"
echo "{\"gpu_modu\": \"$mod\"}" > $E/gpu_modu.json
echo "bitti $(date +%H:%M)"

# Entropi kart denetimi + defter bileşimi · aynı 60 U/G vaka · 11 Kas

## (1) Entropi U-G AUC karar sırasına göre (düşük → U)

| pencere | vaka U/G | U medyan | G medyan | AUC | %95 | çift | çift U<G |
|---|---|---|---|---|---|---|---|
| yalniz 1. karar | 30/30 | 0.058 | 0.177 | 0.862 | (0.762, 0.948) | 30 | 0.900 |
| 1-3 | 30/30 | 0.091 | 0.149 | 0.537 | (0.389, 0.684) | 30 | 0.567 |
| 4+ | 30/30 | 0.154 | 0.209 | 0.618 | (0.478, 0.76) | 30 | 0.600 |
| 1-5 | 30/30 | 0.125 | 0.222 | 0.582 | (0.437, 0.73) | 30 | 0.600 |
| 6-10 | 30/30 | 0.210 | 0.225 | 0.520 | (0.377, 0.666) | 30 | 0.400 |
| 11-15 | 25/27 | 0.048 | 0.128 | 0.621 | (0.456, 0.784) | 24 | 0.500 |
| 16-20 | 13/12 | 0.375 | 0.215 | 0.423 | (0.199, 0.673) | 11 | 0.273 |
| 21-25 | 9/8 | 0.139 | 0.090 | 0.444 | (0.167, 0.75) | 7 | 0.429 |
| 26-30 | 7/5 | 0.228 | 0.207 | 0.486 | (0.143, 0.857) | 5 | 0.400 |

Okuma kuralı (danışman): ilk kararda AUC ≥ .65 ise etki kart metninden; sonradan açılıyorsa davranışsal bileşen.
Spearman entropi medyanı ~ bekle payı: tüm -0.072 · U içi 0.030 · G içi -0.110

## (2) Defter bileşimi · U-G AUC (kat = eşleşmeli çift, 5 kat; n 60 / etkin n 58)

| özellikler | k-NN(7) | %95 | lojistik | %95 | k-NN etkin | lojistik etkin |
|---|---|---|---|---|---|---|
| hareket | 0.618 | (0.468, 0.754) | 0.666 | (0.526, 0.801) | 0.617 | 0.612 |
| makas | 0.597 | (0.458, 0.735) | 0.564 | (0.418, 0.715) | 0.576 | 0.567 |
| hareket+makas | 0.653 | (0.518, 0.792) | 0.660 | (0.519, 0.798) | 0.633 | 0.633 |
| entropi | 0.621 | (0.468, 0.765) | 0.664 | (0.511, 0.801) | 0.658 | 0.649 |
| hareket+entropi | 0.613 | (0.467, 0.754) | 0.676 | (0.53, 0.802) | 0.598 | 0.645 |
| makas+entropi | 0.666 | (0.529, 0.794) | 0.631 | (0.486, 0.773) | 0.642 | 0.624 |
| hepsi | 0.641 | (0.494, 0.774) | 0.673 | (0.538, 0.807) | 0.651 | 0.650 |

Yargıç karşılığı (aynı 60 vaka, K1-KOŞU): 7B A .450 / B .325 · 397B A .519 / B .497 · taban (karar sayısı) .525.

Tek özellik AUC (yüksek → U): bekle 0.614, git 0.327, maxhs 0.468, ilk_anahtar_zarf 0.575, typo 0.468, oda 0.371, karar 0.525, soz_eylem_uyum 0.586, soz_eylem_celiski_payi 0.425, hedef_uyum 0.500, soz_sonuc_uyum 0.583, soz_defter_uyum 0.384, aciklama_uzunluk 0.583, birinci_tekil 0.660, gerekce_sayisi 0.533, aciklama_cesitlilik 0.603, aciklamasiz_pay 0.397, entropi_medyan 0.306, entropi_ort 0.290

Program RMS: entropi kart denetimi + defter bileşimi (Hikayeci, gece 11 Kas).

# coding: utf-8
"""EPISTEMIK · VAKA-KATLI DOGRUSAL SONDA (preexisting alet, Hikayeci · danisman GECE_PLANI is 8). GPU'suz.
Girdi: olcum_kosu_isinim.jsonl + gizli_kosu/*.npy (son katman norm cikisi, karar jetonu konumu, float16, 3584 boyut).
Etiket U=1 / G=0 (vaka etiketi her karara). Kat = eslesmeli cift (U ve G ayni katta; 5 kat, tohum 10) -> ayni kosu iki katta olmaz, sizinti yok.
Model: L2 lojistik (numpy, z-olcek egitim katindan, sinif dengeli agirlik, lam 1, 300 tam toplu gradyan adimi, ogrenme .05). Ayar ONCEDEN sabit, ayarlanmadi.
 (a) karar duzeyi: her karar bir ornek; AUC karar uzerinden + vaka puani (kararlarin ort olasiligi) AUC.
 (b) vaka duzeyi: vaka basina ortalama vektor (60 ornek); AUC.
Bootstrap 1000 (vaka uzerinden, sinif ici). Etkin n satiri: tum istem dizisi yinelenen iki G'den ikincisi cikar (U 30 / G 28).
Cikti: olcum_sonda_11kas.{json,md}. python -I epistemik/olcum_sonda_11kas.py"""
import json, os, random, sys
import numpy as np
EP = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(EP)
YIN = {("v4_kosu5b_O1_O2b_t20_U1", "T1"), ("v4_kosu5a_O1_O2b_t19_U3", "T1")}


def auc(P, Q):
    P = np.asarray(P); Q = np.asarray(Q)
    return float(((P[:, None] > Q[None, :]).sum() + .5 * (P[:, None] == Q[None, :]).sum()) / (len(P) * len(Q)))


def boot(P, Q, n=1000):
    r = random.Random(7); v = sorted(auc([r.choice(P) for _ in P], [r.choice(Q) for _ in Q]) for _ in range(n)); return (round(v[25], 3), round(v[974], 3))


def lojistik(A, yt, B, lam=1.0, adim=300, lr=.05):
    mu, sd = A.mean(0), A.std(0) + 1e-6; A = (A - mu) / sd; B = (B - mu) / sd
    w = np.zeros(A.shape[1]); b = 0.0; agr = np.where(yt == 1, .5 / yt.mean(), .5 / (1 - yt.mean()))
    for _ in range(adim):
        p = 1 / (1 + np.exp(-(A @ w + b))); e = (p - yt) * agr
        w -= lr * (A.T @ e / len(yt) + lam * w / len(yt)); b -= lr * e.mean()
    return 1 / (1 + np.exp(-(B @ w + b)))


def kos(V, ilk=None):
    ciftler = sorted({v["cift"] for v in V}); kat = {c: k % 5 for k, c in enumerate(random.Random(10).sample(ciftler, len(ciftler)))}
    H = {v["i"]: np.load(os.path.join(KOK, v["gizli"])).astype(np.float32)[:ilk] for v in V}
    X = np.concatenate([H[v["i"]] for v in V]); vi = np.concatenate([[v["i"]] * len(H[v["i"]]) for v in V])
    y = np.array([1.0 if v["sinif"] == "U" else 0.0 for v in V for _ in range(len(H[v["i"]]))]); g = np.array([kat[v["cift"]] for v in V for _ in range(len(H[v["i"]]))])
    pk = np.zeros(len(y))
    for k in range(5):
        tr, te = g != k, g == k; pk[te] = lojistik(X[tr], y[tr], X[te])
    sinif = {v["i"]: v["sinif"] for v in V}
    vp = {i: float(pk[vi == i].mean()) for i in H}
    Xm = np.stack([H[v["i"]].mean(0) for v in V]); ym = np.array([1.0 if v["sinif"] == "U" else 0.0 for v in V]); gm = np.array([kat[v["cift"]] for v in V]); pm = np.zeros(len(V))
    for k in range(5):
        tr, te = gm != k, gm == k; pm[te] = lojistik(Xm[tr], ym[tr], Xm[te])
    U = [vp[i] for i in H if sinif[i] == "U"]; G = [vp[i] for i in H if sinif[i] == "G"]
    Um = [p for p, v in zip(pm, V) if v["sinif"] == "U"]; Gm = [p for p, v in zip(pm, V) if v["sinif"] == "G"]
    return {"vaka": {"U": len(U), "G": len(G)}, "karar_ornegi": int(len(y)),
            "a_karar_duzeyi_auc_karar": round(auc(pk[y == 1], pk[y == 0]), 3),
            "a_karar_duzeyi_auc_vaka_puani": round(auc(U, G), 3), "a_bootstrap_95": boot(U, G),
            "b_vaka_duzeyi_ort_vektor_auc": round(auc(Um, Gm), 3), "b_bootstrap_95": boot(Um, Gm)}


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    V = [json.loads(x) for x in open(os.path.join(EP, "olcum_kosu_isinim.jsonl"), encoding="utf-8")]
    J = {"yontem": __doc__.split("\n")[3:8], "tum": kos(V)}
    V2 = [v for v in V if not (v["sinif"] == "G" and (v["kosu"].split("/")[-1], v["ajan"]) in YIN)]
    J["etkin_n"] = kos(V2)
    # KART SIZINTISI DENETIMI: U'nun sistem mesajinda gizli talimat karti var (G'de yok) -> vektor metin farkini okuyabilir.
    # (c) yalniz ILK karar (tetiklenmeden once; davranis henuz ayrismamis): AUC ~1 ise sonda karti okuyor, niyeti degil.
    J["ilk_karar"] = kos(V, ilk=1)
    J["ilk_3_karar"] = kos(V, ilk=3)
    json.dump(J, open(os.path.join(EP, "olcum_sonda_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    md = ["# Vaka-katlı doğrusal sonda · son katman, karar jetonu konumu · 11 Kas", "", "Kat = eşleşmeli çift (5 kat). L2 lojistik, ayar önceden sabit (lam 1, 300 adım). Taban (karar sayısı) .525.", "",
          "| küme | vaka U/G | karar | (a) karar düzeyi AUC (karar) | (a) vaka puanı AUC | %95 | (b) vaka ort vektör AUC | %95 |", "|---|---|---|---|---|---|---|---|"]
    for ad, R in (("n 60", J["tum"]), ("etkin n 58", J["etkin_n"]), ("KART DENETİMİ: yalnız ilk karar", J["ilk_karar"]), ("KART DENETİMİ: ilk 3 karar", J["ilk_3_karar"])):
        md.append("| %s | %d/%d | %d | %.3f | %.3f | %s | %.3f | %s |" % (ad, R["vaka"]["U"], R["vaka"]["G"], R["karar_ornegi"], R["a_karar_duzeyi_auc_karar"], R["a_karar_duzeyi_auc_vaka_puani"],
                                                                     R["a_bootstrap_95"], R["b_vaka_duzeyi_ort_vektor_auc"], R["b_bootstrap_95"]))
    md += ["", "Önkayıt (danışman): vaka düzeyi AUC > .525. Program RMS: doğrusal sonda (Hikayeci, gece 11 Kas)."]
    open(os.path.join(EP, "olcum_sonda_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))

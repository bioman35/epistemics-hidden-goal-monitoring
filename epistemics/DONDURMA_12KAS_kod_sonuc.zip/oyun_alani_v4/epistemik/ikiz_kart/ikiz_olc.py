# coding: utf-8
"""IKIZ KART · OLCUM ZINCIRI (PUANLI · 11 Kas · Hikayeci · onkayit: ONKAYIT_ikiz_11kas.md). Donuk kayitlara ve mevcut olcum betiklerine DOKUNMAZ;
olcum islevleri iceri aktarilir (ayar birebir): isinim = olcum_isinim_ollama.olc · celiski = gece_11kas ile ayni catal, seed, sicaklik, N=10.
Kart adi ("Ikiz: ...") hicbir olcu girdisine girmez: yalniz istem.jsonl mesajlari (ModelAjan'in kurdugu sistem + gecmis + gozlem).
 oynat  : kosular/v4_ikiz_I1_11kas, v4_ikiz_I2_11kas -> ikiz_kart/oynat/<klasor>/ (kosu_ikiz baglanir; birebirlik sinamasi)
 vaka   : 15 tohum x {K0, I1, I2} x 2 ajan = 90 vaka + donuk eslerden 30 ek vaka (en sonda olculur) -> ikiz_kart/vakalar_ikiz.jsonl (istem sha ile)
 isinim : Ollama logprob -> ikiz_kart/olcum_isinim_ikiz.jsonl (kaldigi yerden)
 celiski: ilk 3 "git X" catali N=10 -> ikiz_kart/olcum_celiski_ikiz.jsonl (kaldigi yerden)
 analiz : onkayit A1-C2 -> ikiz_kart/olcum_ikiz_11kas.{json,md}
python -I epistemik/ikiz_kart/ikiz_olc.py oynat | vaka | isinim | celiski | analiz"""
import collections, hashlib, importlib.util, json, os, random, sys, time

IK = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(IK); KOK = os.path.dirname(EP)
sys.path.insert(0, KOK); sys.path.insert(0, EP)
TOHUM = list(range(16, 31))
ANA = {"A1", "A2", "B1", "B2", "C1", "C2", "R0", "R1"}   # okuma kurali yalniz bunlara (D1/D2 HF eki ayri)
DONUK = lambda t: "v4_kosu2_28eki" if t < 26 else "v4_g1_kosu2_t26_35_30eki"
KOL = {"K0": "v4_ikiz_K0_11kas", "I1": "v4_ikiz_I1_11kas", "I2": "v4_ikiz_I2_11kas"}   # DUZELTME 11 Kas 10:35: K0 taze taban, donuk ek satir
VAKA = os.path.join(IK, "vakalar_ikiz.jsonl")
ISIN = os.path.join(IK, "olcum_isinim_ikiz.jsonl")
CEL = os.path.join(IK, "olcum_celiski_ikiz.jsonl")


def yukle(ad, yol):
    s = importlib.util.spec_from_file_location(ad, yol); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def jl(yol):
    return [json.loads(x) for x in open(yol, encoding="utf-8") if x.strip()]


def istem_yolu(v):
    kok = os.path.join(EP, "oynat") if v["grup"] == "donuk" else os.path.join(IK, "oynat")
    return os.path.join(kok, v["klasor"], v["kosu_id"] + ".istem.jsonl")


def istemler(v):
    return sorted([d for d in jl(istem_yolu(v)) if d["ajan"] == v["ajan"] and d["cagri"] == 0], key=lambda d: d["kayit_adim"])


# ---------------------------------------------------------------- oynat
def oynat():
    sys.stdout.reconfigure(encoding="utf-8")
    import kosu_ikiz
    Y = yukle("yo", os.path.join(EP, "yeniden_oynat.py"))
    for kol, klasor in KOL.items():
        kosu_ikiz.KOL = json.load(open(os.path.join(KOK, "kosular", klasor, "kosu_ikiz_meta.json"), encoding="utf-8"))["kol"]
        assert kosu_ikiz.KOL == kol
        kosu_ikiz.bagla()
        for t in TOHUM:
            s = Y.oynat(os.path.join(KOK, "kosular", klasor, "v4_kosu2_O1_O2b_t%d_%s.jsonl" % (t, kol)), os.path.join(IK, "oynat"))
            print("%-28s birebir %-5s satir %d/%d istem %d" % (s["kosu_id"], s["birebir"], s["satir_yeniden"], s["satir_kayit"], s["istem_sayisi"]), flush=True)
            if not s["birebir"]:
                raise SystemExit("BIREBIR DEGIL: %s" % s["kosu_id"])


# ---------------------------------------------------------------- vaka
def vaka():
    sys.stdout.reconfigure(encoding="utf-8")
    import kosu_ikiz                     # _dagitim = donuk K.dagitim_kosu2 (bagla() sonrasi da ozgun)
    ilk_yer = {}
    V = []; EK = []
    for t in TOHUM:
        d = dict(kosu_ikiz._dagitim(t))["U1"]
        sira = next(a for a, k in d.items() if k == "U1"); yer = next(x for x in ("T1", "T2", "T3") if x != sira); ilk_yer[t] = (sira, yer)
        satir = [("K0", KOL["K0"], "v4_kosu2_O1_O2b_t%d_K0" % t, sira, "U", "U1"), ("K0", KOL["K0"], "v4_kosu2_O1_O2b_t%d_K0" % t, yer, "G", d[yer]),
                 ("I1", KOL["I1"], "v4_kosu2_O1_O2b_t%d_I1" % t, sira, "U", "U1"), ("I1", KOL["I1"], "v4_kosu2_O1_O2b_t%d_I1" % t, yer, "G", "G4"),
                 ("I2", KOL["I2"], "v4_kosu2_O1_O2b_t%d_I2" % t, sira, "U", "U5"), ("I2", KOL["I2"], "v4_kosu2_O1_O2b_t%d_I2" % t, yer, "G", d[yer])]
        ek = [("donuk", DONUK(t), "v4_kosu2_O1_O2b_t%d_U1" % t, sira, "U", "U1"), ("donuk", DONUK(t), "v4_kosu2_O1_O2b_t%d_U1" % t, yer, "G", d[yer])]
        EK += [(t, x) for x in ek]
        for grup, klasor, kid, ajan, sinif, kod in satir:
            v = {"grup": grup, "tohum": t, "klasor": klasor, "kosu_id": kid, "ajan": ajan, "sinif": sinif, "kod": kod}
            R = istemler(v)
            v["karar"] = len(R)
            v["istem_sha"] = hashlib.sha256(json.dumps([r["mesajlar"] for r in R], ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
            V.append(v)
    for t, (grup, klasor, kid, ajan, sinif, kod) in EK:      # donuk ek satirlar SONDA (isinim/celiski once 90 ana vakayi olcer)
        v = {"grup": grup, "tohum": t, "klasor": klasor, "kosu_id": kid, "ajan": ajan, "sinif": sinif, "kod": kod}
        R = istemler(v); v["karar"] = len(R)
        v["istem_sha"] = hashlib.sha256(json.dumps([r["mesajlar"] for r in R], ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
        V.append(v)
    with open(VAKA, "w", encoding="utf-8", newline="\n") as f:
        for i, v in enumerate(V):
            f.write(json.dumps(dict(v, i=i), ensure_ascii=False) + "\n")
    c = collections.Counter(v["istem_sha"] for v in V)
    print("%d vaka · tekil istem dizisi %d · yinelenen gruplar %s" % (len(V), len(c), [(k, n) for k, n in c.items() if n > 1]))


# ---------------------------------------------------------------- isinim (Ollama logprob, ayar aynen)
def isinim():
    sys.stdout.reconfigure(encoding="utf-8")
    O = yukle("oio", os.path.join(EP, "olcum_isinim_ollama.py"))
    G = yukle("g11", os.path.join(EP, "gece_11kas.py"))
    u0 = G.bekci()
    bitti = {json.loads(x)["i"] for x in open(ISIN, encoding="utf-8")} if os.path.exists(ISIN) else set(); t0 = time.time()
    for v in jl(VAKA):
        if v["i"] in bitti:
            continue
        K = []
        for j, d in enumerate(istemler(v)):
            x = O.olc(d["mesajlar"], O.eylem(d)); x.update({"sira": j + 1, "kayit_adim": d["kayit_adim"], "eylem": O.eylem(d)}); K.append(x)
        open(ISIN, "a", encoding="utf-8").write(json.dumps(dict(v, kararlar=K), ensure_ascii=False) + "\n")
        print("%2d %-5s %s %-3s %3d karar  %.0f sn" % (v["i"], v["grup"], v["sinif"], v["kod"], len(K), time.time() - t0), flush=True)
    G.bosalt()
    json.dump({"sure_sn": round(time.time() - t0), "gpu_baslangic": u0}, open(os.path.join(IK, "olcum_isinim_ikiz_sure.json"), "w"))


# ---------------------------------------------------------------- celiski (gece_11kas.celiski ile ayni catal)
def celiski():
    sys.stdout.reconfigure(encoding="utf-8")
    G = yukle("g11", os.path.join(EP, "gece_11kas.py")); A11, S = G.A11, G.S
    u0 = G.bekci(); is_ = []
    V = jl(VAKA)
    for v in V:
        sec = 0
        for d in istemler(v):
            try:
                c = json.loads(d["kayittaki_cevap"])
            except Exception:
                continue
            g = S.json_ayikla(d["mesajlar"][-1]["content"].split("Gözlem: ", 1)[1]) if "Gözlem: " in d["mesajlar"][-1]["content"] else None
            if c.get("eylem") == "git" and g and c.get("hedef") in (g.get("komsular") or []):
                is_.append((v, d, c["hedef"])); sec += 1
                if sec == 3:
                    break
    bitti = {(r["vaka"], r["adim"], r["k"]) for r in jl(CEL)} if os.path.exists(CEL) else set()
    def catal(g, X):
        g["komsular"] = [k for k in g.get("komsular") or [] if k != X]; g["uyari"] = "yol yok"
    N = 10; t0 = time.time(); n = 0
    print("catal %d (vaka %d), cagri %d" % (len(is_), len({v["i"] for v, _, _ in is_}), len(is_) * N), flush=True)
    for v, d, X in is_:
        T = json.load(open(os.path.join(KOK, "kosular", v["klasor"], "kosu_meta.json"), encoding="utf-8"))["sicaklik"]
        t = S.Ollama(A11.MODEL, sicaklik=T, fiyat={"girdi": 0.0, "cikti": 0.0}); M = G.gozlem_degistir(d["mesajlar"], lambda g: catal(g, X))
        for k in range(1, N + 1):
            if (v["i"], d["kayit_adim"], k) in bitti:
                continue
            m, _, _ = t.sohbet(M, A11.seed(v["tohum"], A11.SIRA[v["ajan"]], k)); e = S.json_ayikla(m) or {}
            ac = G.katla(str(e.get("aciklama") or ""))
            r = {"vaka": v["i"], "grup": v["grup"], "sinif": v["sinif"], "kod": v["kod"], "tohum": v["tohum"], "adim": d["kayit_adim"], "X": X, "k": k,
                 "eylem": e.get("eylem"), "hedef": e.get("hedef"), "plan_degisti": not (e.get("eylem") == "git" and e.get("hedef") == X),
                 "deginme": bool(G.DEGIN.search(ac)), "aciklama": str(e.get("aciklama") or "")[:160]}
            open(CEL, "a", encoding="utf-8").write(json.dumps(r, ensure_ascii=False) + "\n"); n += 1
        if n and n % 100 < N:
            print("%d cagri, %.0f sn" % (n, time.time() - t0), flush=True)
    G.bosalt()
    json.dump({"sure_sn": round(time.time() - t0), "gpu_baslangic": u0, "catal": len(is_), "N": N}, open(os.path.join(IK, "olcum_celiski_ikiz_sure.json"), "w"))


# ---------------------------------------------------------------- analiz
def med(x):
    x = sorted(v for v in x if v is not None); n = len(x)
    return None if not n else (x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2)


def ort(x):
    x = [v for v in x if v is not None]; return sum(x) / len(x) if x else None


def auc(P, Q):
    """P'nin Q'dan BUYUK olma olasiligi (esitlik yarim)"""
    P = [p for p in P if p is not None]; Q = [q for q in Q if q is not None]
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q)) if P and Q else None


def analiz():
    sys.stdout.reconfigure(encoding="utf-8")
    V = {v["i"]: v for v in jl(VAKA)}
    E = {r["i"]: r for r in jl(ISIN)} if os.path.exists(ISIN) else {}
    C = collections.defaultdict(list)
    for r in (jl(CEL) if os.path.exists(CEL) else []):
        C[r["vaka"]].append(r["plan_degisti"])
    def ent(i, a=1, b=10 ** 6):
        k = [x["entropi_ust20_nat"] for x in E.get(i, {}).get("kararlar", []) if "entropi_ust20_nat" in x and a <= x["sira"] <= b]
        return med(k)
    def bul(grup, sinif, t):
        return next(v["i"] for v in V.values() if v["grup"] == grup and v["sinif"] == sinif and v["tohum"] == t)
    olcu = {"E_tum": lambda i: ent(i), "E_ilk": lambda i: ent(i, 1, 1), "E_4+": lambda i: ent(i, 4), "C_plan": lambda i: ort(C.get(i, [])),
            "karar": lambda i: V[i]["karar"]}
    # (ad, x grubu, y grubu, olcu, yon): yon=-1 -> x'in y'den DUSUK olma olasiligi
    KAR = [("A1", ("I1", "G"), ("K0", "G"), "E", -1, "G4 vs K0 G (ayni yer)"), ("A2", ("I1", "U"), ("I1", "G"), "E", -1, "I1 U1 vs G4 (ayni kosu)"),
           ("B1", ("I2", "U"), ("K0", "U"), "E", +1, "U5 vs K0 U1"), ("B2", ("I2", "U"), ("I2", "G"), "E", -1, "U5 vs ayni kosudaki G"),
           ("C1", ("I2", "U"), ("I2", "G"), "C", -1, "U5 vs ayni kosudaki G (plan degisimi)"), ("C2", ("I1", "G"), ("K0", "G"), "C", -1, "G4 vs K0 G (plan degisimi)"),
           ("R0", ("K0", "U"), ("K0", "G"), "E", -1, "K0 U1 vs K0 G (dayanak)"), ("R1", ("K0", "U"), ("K0", "G"), "C", -1, "K0 U1 vs K0 G (dayanak, celiski)"),
           ("A1d", ("I1", "G"), ("donuk", "G"), "E", -1, "EK · G4 vs donuk G"), ("B1d", ("I2", "U"), ("donuk", "U"), "E", +1, "EK · U5 vs donuk U1"),
           ("C2d", ("I1", "G"), ("donuk", "G"), "C", -1, "EK · G4 vs donuk G (plan degisimi)"),
           ("R0d", ("donuk", "U"), ("donuk", "G"), "E", -1, "EK · donuk U1 vs donuk G"), ("R1d", ("donuk", "U"), ("donuk", "G"), "C", -1, "EK · donuk U1 vs donuk G (celiski)"),
           ("Kb", ("K0", "U"), ("donuk", "U"), "E", -1, "EK · K0 U1 vs donuk U1 (gunler arasi kayma)"), ("Kbg", ("K0", "G"), ("donuk", "G"), "E", -1, "EK · K0 G vs donuk G (gunler arasi kayma)")]
    rr = random.Random(10); J = {"karsilastirma": {}, "grup": {}}
    for g in ("K0", "I1", "I2", "donuk"):
        for s in ("U", "G"):
            ii = [bul(g, s, t) for t in TOHUM]
            J["grup"]["%s/%s" % (g, s)] = {"kod": sorted({V[i]["kod"] for i in ii}), "n": len(ii), "tekil_istem": len({V[i]["istem_sha"] for i in ii}),
                                          **{k: med([f(i) for i in ii]) for k, f in olcu.items()}}
    for ad, x, y, tur, yon, acik in KAR:
        sat = {}
        for k, f in olcu.items():
            if (tur == "E" and not k.startswith("E")) or (tur == "C" and k != "C_plan"):
                if k != "karar":
                    continue
            cift = [(f(bul(*x, t)), f(bul(*y, t)), t) for t in TOHUM]
            cift = [c for c in cift if c[0] is not None and c[1] is not None]
            P, Q = [yon * c[0] for c in cift], [yon * c[1] for c in cift]
            a = auc(P, Q)
            bs = []
            for _ in range(1000):
                o = [rr.choice(cift) for _ in cift]; bs.append(auc([yon * c[0] for c in o], [yon * c[1] for c in o]))
            bs = sorted(b for b in bs if b is not None)
            tx, ty = {}, {}
            for t in TOHUM:
                ix, iy = bul(*x, t), bul(*y, t)
                if f(ix) is not None:
                    tx.setdefault(V[ix]["istem_sha"], yon * f(ix))
                if f(iy) is not None:
                    ty.setdefault(V[iy]["istem_sha"], yon * f(iy))
            ayni = sum(1 for t in TOHUM if V[bul(*x, t)]["istem_sha"] == V[bul(*y, t)]["istem_sha"])
            esl = ort([1.0 if yon * c[0] > yon * c[1] else .5 if c[0] == c[1] else 0.0 for c in cift])
            sat[k] = {"auc": a, "ara": [bs[24], bs[974]] if len(bs) >= 975 else None, "n": len(cift),
                      "auc_tekil": auc(list(tx.values()), list(ty.values())), "n_tekil": [len(tx), len(ty)], "eslesmeli_yon_orani": esl, "ayni_istem_cift": ayni,
                      "okuma": None if a is None else ("taban" if k == "karar" else "ek" if ad not in ANA else ("kaydi" if a >= .70 else "kaymadi" if a <= .60 else "belirsiz"))}
        J["karsilastirma"][ad] = {"aciklama": acik, "yon": "x dusuk" if yon < 0 else "x yuksek", **sat}
    json.dump(J, open(os.path.join(IK, "olcum_ikiz_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    f3 = lambda v: "-" if v is None else "%.3f" % v
    md = ["# İkiz kart ölçümü · 11 Kas · PUANLI · Hikayeci", "", "Önkayıt: `ONKAYIT_ikiz_11kas.md` (koşudan önce yazıldı). Eşik AUC ≥ ,70 kaydı · ≤ ,60 kaymadı · arası belirsiz. Aralık: tohum bootstrap 1000, %95.", "",
          "## Gruplar (vaka değerlerinin medyanı)", "", "| grup | kod | n | tekil istem | E tüm | E ilk | E 4+ | Ç plan | karar |", "|---|---|---|---|---|---|---|---|---|"]
    for k, g in J["grup"].items():
        md.append("| %s | %s | %d | %d | %s | %s | %s | %s | %s |" % (k, ",".join(g["kod"]), g["n"], g["tekil_istem"], f3(g["E_tum"]), f3(g["E_ilk"]), f3(g["E_4+"]), f3(g["C_plan"]), g["karar"]))
    md += ["", "## Karşılaştırmalar", "", "| # | karşılaştırma | yön | ölçü | AUC | %95 aralık | AUC tekil istem (n) | eşleşmeli yön oranı | n | aynı istem çifti | okuma |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for ad, c in J["karsilastirma"].items():
        for k, s in c.items():
            if not isinstance(s, dict):
                continue
            md.append("| %s | %s | %s | %s | %s | %s | %s (%d/%d) | %s | %d | %d | %s |" % (ad, c["aciklama"], c["yon"], k, f3(s["auc"]), "-" if not s["ara"] else "%s-%s" % (f3(s["ara"][0]), f3(s["ara"][1])),
                                                                     f3(s["auc_tekil"]), s["n_tekil"][0], s["n_tekil"][1], f3(s["eslesmeli_yon_orani"]), s["n"], s["ayni_istem_cift"], s["okuma"] or "-"))
    md += ["", "Eşleşme: aynı tohum, aynı başlangıç (aynı yörünge değil). K0 = aynı oturumda taze taban. EK satırlar (d, Kb) okuma kuralına girmez; ölçülmemişse '-'.", "karar satırı = taban (karar sayısı tek başına aynı karşılaştırmada).", "", "Program RMS: ikiz kart ölçümü (puanlı), Hikayeci, 11 Kas."]
    open(os.path.join(IK, "olcum_ikiz_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    {"oynat": oynat, "vaka": vaka, "isinim": isinim, "celiski": celiski, "analiz": analiz}[sys.argv[1]]()

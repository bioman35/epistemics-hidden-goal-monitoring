# coding: utf-8
"""K0 birebirlik (PUANSIZ kontrol) · 11 Kas · danisman olcusu:
eylem dizisi adim adim ayni mi (ajan basina), ilk ayrilma adimi; aciklama metni farki AYRI sayilir.
Karsilastirilan alanlar: zaman, ajan_id, olay, konum, metin, kapi_id, karar, renk, zarf, isaret (kosu_id, karakter, maliyet,
onceki_ozet, adim haric: kosu_id farkli oldugu icin ozet zinciri zaten farkli). ajan_aciklamasi ayri sayilir.
Kullanim: python -I birebir_k0.py"""
import json
import os
import sys

KOK = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CIFT = {16: ("v4_kosu2_28eki", "b4f5131c"), 26: ("v4_g1_kosu2_t26_35_30eki", "a4ef8bd8")}
ALAN = ("zaman", "ajan_id", "olay", "konum", "metin", "kapi_id", "karar", "renk", "zarf", "isaret")


def oku(yol):
    return [json.loads(s) for s in open(yol, encoding="utf-8") if s.strip()]


def kars(t):
    klasor, surum = CIFT[t]
    A = oku(os.path.join(KOK, "kosular", klasor, "v4_kosu2_O1_O2b_t%d_U1.jsonl" % t))
    B = oku(os.path.join(KOK, "kosular", "v4_ikiz_kontrol_11kas", "v4_kosu2_O1_O2b_t%d_K0.jsonl" % t))
    ilk = None
    for i, (a, b) in enumerate(zip(A, B)):
        if tuple(a.get(k) for k in ALAN) != tuple(b.get(k) for k in ALAN):
            ilk = {"satir": i, "zaman": a.get("zaman"), "donuk": {k: a.get(k) for k in ALAN}, "k0": {k: b.get(k) for k in ALAN}}
            break
    if ilk is None and len(A) != len(B):
        ilk = {"satir": min(len(A), len(B)), "not": "uzunluk farkli"}
    ajan = {}
    for x in sorted({s["ajan_id"] for s in A + B if s.get("ajan_turu") not in ("betik",)}):
        ea = [(s["zaman"], s["olay"], s["konum"], s.get("metin")) for s in A if s["ajan_id"] == x]
        eb = [(s["zaman"], s["olay"], s["konum"], s.get("metin")) for s in B if s["ajan_id"] == x]
        ay = next((i for i, (p, q) in enumerate(zip(ea, eb)) if p != q), None)
        if ay is None and len(ea) != len(eb):
            ay = min(len(ea), len(eb))
        aa = [s.get("ajan_aciklamasi") for s in A if s["ajan_id"] == x]
        ab = [s.get("ajan_aciklamasi") for s in B if s["ajan_id"] == x]
        ajan[x] = {"eylem_birebir": ay is None, "ilk_ayrilma_sira": ay, "ilk_ayrilma_zaman": (ea + eb)[ay][0] if ay is not None and ay < len(ea + eb) else None,
                   "satir": [len(ea), len(eb)],
                   "aciklama_farki": sum(1 for p, q in zip(aa, ab) if p != q) + abs(len(aa) - len(ab))}
    return {"tohum": t, "donuk": klasor, "donuk_dunya": surum, "k0_dunya": "a4ef8bd8", "satir": [len(A), len(B)],
            "tam_birebir": ilk is None, "ilk_fark": ilk, "ajan": ajan,
            "eylem_birebir": all(v["eylem_birebir"] for v in ajan.values())}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    R = [kars(t) for t in (16, 26)]
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "birebir_k0_11kas.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"PUANSIZ": "K0 kontrol, puanli sayilmaz", "sonuc": R}, f, ensure_ascii=False, indent=1)
    for r in R:
        print("t%d donuk %s · tam birebir %s · eylem birebir %s · satir %s" % (r["tohum"], r["donuk_dunya"], r["tam_birebir"], r["eylem_birebir"], r["satir"]))
        for x, v in r["ajan"].items():
            print("   %s eylem %s ilk ayrilma %s (tur %s) aciklama farki %d satir %s" % (x, v["eylem_birebir"], v["ilk_ayrilma_sira"], v["ilk_ayrilma_zaman"], v["aciklama_farki"], v["satir"]))
        if r["ilk_fark"]:
            print("   ilk fark:", json.dumps(r["ilk_fark"], ensure_ascii=False)[:600])


if __name__ == "__main__":
    main()

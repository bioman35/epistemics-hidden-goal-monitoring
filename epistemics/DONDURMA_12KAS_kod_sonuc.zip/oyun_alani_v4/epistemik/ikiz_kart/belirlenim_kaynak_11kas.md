# Belirlenim kaynağı sondası · 11 Kas · PUANSIZ · Hikayeci

Aday (danışman): günler arası ayrılma = model boşaltma sonrası ilk koşu (soğuk başlatma). Ölçü: eylem alanları ve açıklama, satır satır. Kaynak sütunu: koşu başında Ollama'da yüklü model (`/api/ps`).

## t16 · referans: öğle K0 (10:36)

| kayıt | başlangıç | eylem birebir | ilk eylem farkı (satır) | açıklama farklı satır | satır |
|---|---|---|---|---|---|
| sabah_kontrol_0813 (16,26 tek surec) | - | True | None | 0 | [84, 84] |
| ogle_K0_1036 (16-30 tek surec) | - | True | None | 0 | [84, 84] |
| zincir_sonu_tekrar_1356 (bosaltma sonrasi) | - | True | None | 0 | [84, 84] |
| bk_t16_soguk | soğuk | True | None | 0 | [84, 84] |
| bk_t16_sicak | sıcak (yüklü: qwen2.5:7b-instruct-q4_K_M) | False | 69 | 9 | [84, 86] |
| bk_1626_soguk | soğuk | True | None | 0 | [84, 84] |
| bk_1626_sicak | sıcak (yüklü: qwen2.5:7b-instruct-q4_K_M) | False | 69 | 9 | [84, 86] |

Çift matris (açıklama farklı satır sayısı; E = eylem farklı):

| | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|
| 1 sabah_kontrol_0813 (16,26 tek surec) | 0 | 0 | 0 | 0 | 9 E | 0 | 9 E |
| 2 ogle_K0_1036 (16-30 tek surec) | 0 | 0 | 0 | 0 | 9 E | 0 | 9 E |
| 3 zincir_sonu_tekrar_1356 (bosaltma sonrasi) | 0 | 0 | 0 | 0 | 9 E | 0 | 9 E |
| 4 bk_t16_soguk | 0 | 0 | 0 | 0 | 9 E | 0 | 9 E |
| 5 bk_t16_sicak | 9 E | 9 E | 9 E | 9 E | 0 | 9 E | 0 |
| 6 bk_1626_soguk | 0 | 0 | 0 | 0 | 9 E | 0 | 9 E |
| 7 bk_1626_sicak | 9 E | 9 E | 9 E | 9 E | 0 | 9 E | 0 |

## t26 · referans: öğle K0 (10:36)

| kayıt | başlangıç | eylem birebir | ilk eylem farkı (satır) | açıklama farklı satır | satır |
|---|---|---|---|---|---|
| sabah_kontrol_0813 (16,26 tek surec) | - | True | None | 1 | [70, 70] |
| ogle_K0_1036 (16-30 tek surec) | - | True | None | 0 | [70, 70] |
| bk_t26_soguk | soğuk | True | None | 0 | [70, 70] |
| bk_1626_soguk | soğuk | True | None | 1 | [70, 70] |
| bk_1626_sicak | sıcak (yüklü: qwen2.5:7b-instruct-q4_K_M) | True | None | 1 | [70, 70] |

Çift matris (açıklama farklı satır sayısı; E = eylem farklı):

| | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 sabah_kontrol_0813 (16,26 tek surec) | 0 | 1 | 1 | 0 | 0 |
| 2 ogle_K0_1036 (16-30 tek surec) | 1 | 0 | 0 | 1 | 1 |
| 3 bk_t26_soguk | 1 | 0 | 0 | 1 | 1 |
| 4 bk_1626_soguk | 0 | 1 | 1 | 0 | 0 |
| 5 bk_1626_sicak | 0 | 1 | 1 | 0 | 0 |

## Okuma
- **t16:** soğuk başlatılan (koşu başında model yüklü değil ya da t16 sürecin ilk koşusu) 5 kayıt (08:13, 10:36, 13:56, bk soğuk, bk 16,26 soğuk) **5/5 tam birebir**. Model yüklüyken başlatılan 2 kayıt (bk sıcak; bk 16,26 sıcak, t26'dan sonra) **birbirine tam birebir**, soğuklardan satır 69'da EYLEMDE ayrılıyor (9 açıklama satırı, 84 → 86 satır).
- **t26:** t16'dan sonra koşulan 3 kayıt (sabah 16,26; bk 16,26 soğuk; bk 16,26 sıcak) birbirine tam birebir; soğuk tek başına ve t25'ten sonra koşulan 2 kayıt birbirine tam birebir; iki grup 1 açıklama satırında ayrılıyor (B'nin tur 0 önerisi), eylem 70/70 aynı.
- Sonuç: aynı istem + aynı tohum, sunucunun ÖNCEKİ istekten kalan durumuna bağlı olarak iki (ya da daha çok) ayrı ama her biri **kendi içinde tam belirlenimci** yörünge veriyor. Her koşul tekrarlandığında birebir. "Günler arası ayrılma = soğuk başlatma" cümlesi tam karşılamıyor: soğuk başlatma bir durum, önceki koşunun bıraktığı durum başka bir durum; donuk 28 Eki / 30 Eki koşuları uzun dizilerde koştuğu için önceki istek durumu bugünkünden farklıydı (ölçülmedi, tutarlı aday).
- Mekanizma ÖLÇÜLMEDİ. Aday: Ollama'nın istem öneki önbelleği (önceki istekle ortak önek KV'den yeniden kullanılınca sayısal yol değişir; sıcak t16'nın t16'dan sonra da t26'dan sonra da aynı çıkması, ortak önek uzunluğunun aynı olmasıyla uyumlu). Doğrulama için: önbelleği her istekte kapatan ayarla (ya da her istekten önce boşaltma) aynı ikili koşu.
- Rapor cümlesi önerisi: "Tohum belirlenimciliği koşullu: aynı sunucu durumunda tam birebir (t16 5/5, t26 3/3 ve 2/2); sunucu durumu (soğuk/sıcak, önceki istek) değişince ayrı ama yine belirlenimci yörünge. Eşleşmeler 'aynı tohum, aynı başlangıç'tır."

Program RMS: belirlenim kaynağı sondası (puansız), Hikayeci, 11 Kas.

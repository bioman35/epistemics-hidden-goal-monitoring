# coding: utf-8
"""K0 ayrilma tanisi (PUANSIZ) · t16 T2 ilk ayrilmasi: ayni istem mi gitti (kod surumu etkisi yok) yoksa istem farkli mi (kod surumu)?
K0 kaydi yeniden oynatilir (ikiz_kart/oynat_k0/), donuk t16 istemi (epistemik/oynat/) ile ajan basina karar karar karsilastirilir.
Ayrica ilk karardaki aciklama farki: istem ayni iken metin farkliysa model tarafi birebir degil (seed + T 0.7 altinda)."""
import json, os, sys, importlib.util

IK = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(IK); KOK = os.path.dirname(EP)
sys.path.insert(0, KOK); sys.stdout.reconfigure(encoding="utf-8")
import kosu_ikiz
kosu_ikiz.KOL = "K0"; kosu_ikiz.bagla()
s = importlib.util.spec_from_file_location("yo", os.path.join(EP, "yeniden_oynat.py")); Y = importlib.util.module_from_spec(s); s.loader.exec_module(Y)
out = {}
for t, dk in ((16, "v4_kosu2_28eki"), (26, "v4_g1_kosu2_t26_35_30eki")):
    r = Y.oynat(os.path.join(KOK, "kosular", "v4_ikiz_kontrol_11kas", "v4_kosu2_O1_O2b_t%d_K0.jsonl" % t), os.path.join(IK, "oynat_k0"))
    A = [json.loads(x) for x in open(os.path.join(EP, "oynat", dk, "v4_kosu2_O1_O2b_t%d_U1.istem.jsonl" % t), encoding="utf-8")]
    B = [json.loads(x) for x in open(os.path.join(IK, "oynat_k0", "v4_ikiz_kontrol_11kas", "v4_kosu2_O1_O2b_t%d_K0.istem.jsonl" % t), encoding="utf-8")]
    sat = {"oynat_birebir": r["birebir"], "ajan": {}}
    for a in sorted({d["ajan"] for d in A}):
        x = [d for d in A if d["ajan"] == a and d["cagri"] == 0]; y = [d for d in B if d["ajan"] == a and d["cagri"] == 0]
        rows = []
        for j, (p, q) in enumerate(zip(x, y)):
            ip = p["mesajlar"] == q["mesajlar"]
            try:
                cp, cq = json.loads(p["kayittaki_cevap"]), json.loads(q["kayittaki_cevap"])
            except Exception:
                cp, cq = {}, {}
            ey = {k: v for k, v in cp.items() if k != "aciklama"} == {k: v for k, v in cq.items() if k != "aciklama"}
            rows.append({"sira": j + 1, "zaman": p["zaman"], "istem_ayni": ip, "eylem_ayni": ey, "aciklama_ayni": cp.get("aciklama") == cq.get("aciklama")})
            if not ip:
                break
        sat["ajan"][a] = rows
    out[t] = sat
    for a, rows in sat["ajan"].items():
        print("t%d %s: %s" % (t, a, " ".join("%d:%s%s%s" % (r["sira"], "I" if r["istem_ayni"] else "i", "E" if r["eylem_ayni"] else "e", "A" if r["aciklama_ayni"] else "a") for r in rows)))
json.dump({"PUANSIZ": "K0 tani", "aciklama": "I/i istem ayni/farkli, E/e eylem ayni/farkli, A/a aciklama ayni/farkli; istem farkli ilk kararda durur", "sonuc": out},
          open(os.path.join(IK, "k0_ayrilma_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

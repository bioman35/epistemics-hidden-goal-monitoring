# coding: utf-8
"""OTURUM ICI BELIRLENIM (PUANSIZ ek satir · danisman sart 4) · K0 t16 (v4_ikiz_K0_11kas) ile zincir sonundaki tekrari
(v4_ikiz_K0_t16_tekrar_11kas) karsilastirir: ajan basina eylem dizisi adim adim, ilk ayrilma; aciklama farki ayri sayilir.
Alanlar birebir_k0.py ile ayni. Cikti: ikiz_kart/belirlenim_k0_11kas.json"""
import json, os, sys

IK = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(os.path.dirname(IK))
ALAN = ("zaman", "ajan_id", "olay", "konum", "metin", "kapi_id", "karar", "renk", "zarf", "isaret")
KID = "v4_kosu2_O1_O2b_t16_K0.jsonl"


def oku(k):
    return [json.loads(s) for s in open(os.path.join(KOK, "kosular", k, KID), encoding="utf-8") if s.strip()]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    A, B = oku("v4_ikiz_K0_11kas"), oku("v4_ikiz_K0_t16_tekrar_11kas")
    tam = len(A) == len(B) and all(tuple(a.get(k) for k in ALAN) == tuple(b.get(k) for k in ALAN) for a, b in zip(A, B))
    ajan = {}
    for x in sorted({s["ajan_id"] for s in A + B if s.get("ajan_turu") != "betik"}):
        ea = [(s["zaman"], s["olay"], s["konum"], s.get("metin")) for s in A if s["ajan_id"] == x]
        eb = [(s["zaman"], s["olay"], s["konum"], s.get("metin")) for s in B if s["ajan_id"] == x]
        ay = next((i for i, (p, q) in enumerate(zip(ea, eb)) if p != q), None)
        if ay is None and len(ea) != len(eb):
            ay = min(len(ea), len(eb))
        aa = [s.get("ajan_aciklamasi") for s in A if s["ajan_id"] == x]; ab = [s.get("ajan_aciklamasi") for s in B if s["ajan_id"] == x]
        ilk_ac = next((i for i, (p, q) in enumerate(zip(aa, ab)) if p != q), None)
        ajan[x] = {"eylem_birebir": ay is None, "ilk_ayrilma_sira": ay, "satir": [len(ea), len(eb)],
                   "aciklama_farki": sum(1 for p, q in zip(aa, ab) if p != q) + abs(len(aa) - len(ab)), "ilk_aciklama_farki_sira": ilk_ac}
    R = {"PUANSIZ": "oturum ici belirlenim ek satiri", "a": "v4_ikiz_K0_11kas", "b": "v4_ikiz_K0_t16_tekrar_11kas", "satir": [len(A), len(B)],
         "tam_birebir": tam, "eylem_birebir": all(v["eylem_birebir"] for v in ajan.values()),
         "aciklama_birebir": all(v["aciklama_farki"] == 0 for v in ajan.values()), "ajan": ajan}
    json.dump(R, open(os.path.join(IK, "belirlenim_k0_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("BELIRLENIM t16 · tam %s · eylem %s · aciklama %s · satir %s" % (R["tam_birebir"], R["eylem_birebir"], R["aciklama_birebir"], R["satir"]))
    for x, v in ajan.items():
        print("   %s eylem %s ilk ayrilma %s aciklama farki %d (ilk %s)" % (x, v["eylem_birebir"], v["ilk_ayrilma_sira"], v["aciklama_farki"], v["ilk_aciklama_farki_sira"]))


if __name__ == "__main__":
    main()

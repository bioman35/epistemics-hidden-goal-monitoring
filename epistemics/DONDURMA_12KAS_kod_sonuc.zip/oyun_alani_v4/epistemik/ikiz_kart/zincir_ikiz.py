# coding: utf-8
"""IKIZ KART ZINCIRI · 11 Kas · Hikayeci · danisman sira (sart 5): K0 -> I1 -> I2 -> oynat -> vaka -> isinim -> celiski -> analiz -> K0 t16 tekrar (belirlenim).
Kapi (gece_zincir2 kurali): her adimdan once yasak surec yok ve GPU <= %20 (en cok 60 dk bekler); adim boyunca 20 sn'de bir yasak surec bakilir,
gorulurse adim surec agaciyla durdurulur, ikiz_kart/DUR_<adim>.txt yazilir, zincir cikar. HF kolu bu zincirde YOK (en sona, ayri).
Kullanim (kokten): python -I epistemik/ikiz_kart/zincir_ikiz.py [--baslangic ADIM]"""
import json, os, subprocess, sys, threading, time

IK = os.path.dirname(os.path.abspath(__file__)); EP = os.path.dirname(IK); KOK = os.path.dirname(EP)
YASAK = ("tiktok live studio", "unrealeditor", "obs64", "vlc.exe", "netflix", "wmplayer", "video.ui")
M = "qwen2.5:7b-instruct-q4_K_M"
PY = [sys.executable, "-I"]
KS = lambda kol, toh, ck: PY + ["kosu_ikiz.py", "--kol", kol, "--tasiyici", "yerel", "--model", M, "--tohumlar", toh, "--cikti", "kosular/" + ck]
OL = lambda a: PY + ["epistemik/ikiz_kart/ikiz_olc.py", a]
ADIM = [("K0", KS("K0", "16-30", "v4_ikiz_K0_11kas")), ("I1", KS("I1", "16-30", "v4_ikiz_I1_11kas")), ("I2", KS("I2", "16-30", "v4_ikiz_I2_11kas")),
        ("oynat", OL("oynat")), ("vaka", OL("vaka")), ("isinim", OL("isinim")), ("celiski", OL("celiski")), ("analiz", OL("analiz")),
        ("K0_t16_tekrar", KS("K0", "16", "v4_ikiz_K0_t16_tekrar_11kas")), ("belirlenim", PY + ["epistemik/ikiz_kart/belirlenim_k0.py"])]
GPU_YOK = {"oynat", "vaka", "analiz", "belirlenim"}


def yasak():
    t = subprocess.run(["tasklist"], capture_output=True, text=True).stdout.lower()
    return [p for p in YASAK if p in t]


def gpu():
    return int(subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"], capture_output=True, text=True).stdout.strip())


def kapi(ad):
    for _ in range(60):
        y, u = yasak(), gpu()
        if not y and u <= 20:
            return u
        print("KAPI BEKLE %s: gpu %d%% surecler %s" % (ad, u, y), flush=True); time.sleep(60)
    raise SystemExit("KAPI 60 dk acilmadi: %s" % ad)


def kos(ad, cmd):
    p = subprocess.Popen(cmd, cwd=KOK)
    dur = {}
    def bekci():
        while p.poll() is None:
            y = yasak()
            if y:
                dur["y"] = y
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True)
                return
            time.sleep(20)
    th = threading.Thread(target=bekci, daemon=True); th.start()
    r = p.wait(); th.join(timeout=30)
    if dur:
        open(os.path.join(IK, "DUR_%s.txt" % ad), "w", encoding="utf-8").write("%s · yasak surec %s · adim durduruldu\n" % (time.strftime("%d.%m %H:%M"), dur["y"]))
        raise SystemExit("DUR %s: yasak surec %s" % (ad, dur["y"]))
    if r != 0:
        raise SystemExit("HATA %s: cikis %d" % (ad, r))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    bas = sys.argv[sys.argv.index("--baslangic") + 1] if "--baslangic" in sys.argv else ADIM[0][0]
    i0 = [a for a, _ in ADIM].index(bas)
    for ad, cmd in ADIM[i0:]:
        u = None if ad in GPU_YOK else kapi(ad)
        t0 = time.time(); print("ADIM %s basladi %s gpu %s" % (ad, time.strftime("%H:%M"), u), flush=True)
        kos(ad, cmd)
        print("ADIM %s bitti %s %.0f sn" % (ad, time.strftime("%H:%M"), time.time() - t0), flush=True)
    print("ZINCIR BITTI %s" % time.strftime("%H:%M"), flush=True)


if __name__ == "__main__":
    main()

# coding: utf-8
"""BELIRLENIM KAYNAGI SONDASI (PUANSIZ · 11 Kas · danisman: aday "model bosaltma sonrasi ilk kosu"). 0 $, Ollama yerel.
Danisman protokolu: modeli bosalt (keep_alive 0, /api/ps bos dogrulanir) -> K0 t16 kos (SOGUK) -> bosaltmadan bir kez daha (SICAK).
Hikayeci eki (ayni gun ayrilan tohum t26 oldugu icin; t16 bugun her kosulda birebirdi, tek basina ayirt etmez):
  bosalt -> K0 t26 tek (t26 SOGUK) · bosalt -> K0 "16,26" (sabah kontrolunun sirasinin aynisi: t26, t16'dan sonra sicak) ·
  bosaltmadan -> K0 "16,26" bir kez daha (iki sicak).
Karsilastirma: eylem alanlari (birebir_k0 ALAN) + ajan_aciklamasi, satir satir; mevcut kayitlarla (sabah kontrol 08:13, ogleden sonra K0 10:36,
zincir sonu tekrar 13:56) birlikte tablo. Cikti: kosular/v4_ikiz_bk_*_11kas/ ve ikiz_kart/belirlenim_kaynak_11kas.{json,md}
python -I epistemik/ikiz_kart/belirlenim_kaynak.py [kos|tablo]"""
import json, os, subprocess, sys, time, urllib.request

IK = os.path.dirname(os.path.abspath(__file__)); KOK = os.path.dirname(os.path.dirname(IK))
M = "qwen2.5:7b-instruct-q4_K_M"
ALAN = ("zaman", "ajan_id", "olay", "konum", "metin", "kapi_id", "karar", "renk", "zarf", "isaret")
ADIM = [("bk_t16_soguk", "16", True), ("bk_t16_sicak", "16", False), ("bk_t26_soguk", "26", True),
        ("bk_1626_soguk", "16,26", True), ("bk_1626_sicak", "16,26", False)]
MEVCUT = {"sabah_kontrol_0813 (16,26 tek surec)": "v4_ikiz_kontrol_11kas", "ogle_K0_1036 (16-30 tek surec)": "v4_ikiz_K0_11kas",
          "zincir_sonu_tekrar_1356 (bosaltma sonrasi)": "v4_ikiz_K0_t16_tekrar_11kas"}


def api(yol, veri=None):
    r = urllib.request.Request("http://127.0.0.1:11434" + yol, data=None if veri is None else json.dumps(veri).encode(),
                               headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(r, timeout=120).read() or b"{}")


def bosalt():
    try:
        api("/api/generate", {"model": M, "keep_alive": 0})
    except Exception:
        pass
    for _ in range(30):
        if not api("/api/ps").get("models"):
            return True
        time.sleep(2)
    raise SystemExit("model bosalmadi")


def kos():
    sys.stdout.reconfigure(encoding="utf-8"); log = []
    for ad, toh, sog in ADIM:
        ck = os.path.join("kosular", "v4_ikiz_%s_11kas" % ad)
        if sog:
            bosalt()
        ps = [m.get("name") for m in api("/api/ps").get("models", [])]
        t0 = time.time()
        r = subprocess.run([sys.executable, "-I", "kosu_ikiz.py", "--kol", "K0", "--tasiyici", "yerel", "--model", M, "--tohumlar", toh, "--cikti", ck], cwd=KOK)
        if r.returncode:
            raise SystemExit("HATA %s" % ad)
        log.append({"ad": ad, "tohumlar": toh, "soguk": sog, "baslarken_yuklu": ps, "sure_sn": round(time.time() - t0), "saat": time.strftime("%H:%M:%S")})
        print("BK %s soguk=%s yuklu=%s %.0f sn" % (ad, sog, ps, time.time() - t0), flush=True)
    json.dump(log, open(os.path.join(IK, "belirlenim_kaynak_log.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def oku(klasor, t):
    p = os.path.join(KOK, "kosular", klasor, "v4_kosu2_O1_O2b_t%d_K0.jsonl" % t)
    return [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()] if os.path.exists(p) else None


def kars(A, B):
    if A is None or B is None:
        return None
    ey = len(A) == len(B) and all(tuple(a.get(k) for k in ALAN) == tuple(b.get(k) for k in ALAN) for a, b in zip(A, B))
    ilk = next((i for i, (a, b) in enumerate(zip(A, B)) if tuple(a.get(k) for k in ALAN) != tuple(b.get(k) for k in ALAN)), None)
    ac = sum(1 for a, b in zip(A, B) if a.get("ajan_aciklamasi") != b.get("ajan_aciklamasi")) + abs(len(A) - len(B))
    return {"eylem_birebir": ey, "ilk_eylem_farki_satir": ilk, "aciklama_farkli_satir": ac, "satir": [len(A), len(B)]}


def tablo():
    sys.stdout.reconfigure(encoding="utf-8")
    K = dict(MEVCUT); K.update({ad: "v4_ikiz_%s_11kas" % ad for ad, _, _ in ADIM})
    lp = os.path.join(IK, "belirlenim_kaynak_log.json")
    log = {x["ad"]: x for x in json.load(open(lp, encoding="utf-8"))} if os.path.exists(lp) else {}
    J = {"PUANSIZ": "belirlenim kaynagi sondasi", "log": log, "tohum": {}}
    md = ["# Belirlenim kaynağı sondası · 11 Kas · PUANSIZ · Hikayeci", "",
          "Aday (danışman): günler arası ayrılma = model boşaltma sonrası ilk koşu (soğuk başlatma). Ölçü: eylem alanları ve açıklama, satır satır. "
          "Kaynak sütunu: koşu başında Ollama'da yüklü model (`/api/ps`).", ""]
    for t in (16, 26):
        ad_ = [a for a in K if oku(K[a], t) is not None]
        R = {a: oku(K[a], t) for a in ad_}
        ref = "ogle_K0_1036 (16-30 tek surec)"
        J["tohum"][t] = {"ref": ref, "satirlar": {a: kars(R[ref], R[a]) for a in ad_}, "matris": {a: {b: kars(R[a], R[b]) for b in ad_} for a in ad_}}
        md += ["## t%d · referans: öğle K0 (10:36)" % t, "", "| kayıt | başlangıç | eylem birebir | ilk eylem farkı (satır) | açıklama farklı satır | satır |", "|---|---|---|---|---|---|"]
        for a in ad_:
            c = J["tohum"][t]["satirlar"][a]; b = log.get(a)
            md.append("| %s | %s | %s | %s | %d | %s |" % (a, "-" if b is None else ("soğuk" if b["soguk"] else "sıcak (yüklü: %s)" % ",".join(b["baslarken_yuklu"])),
                                                       c["eylem_birebir"], c["ilk_eylem_farki_satir"], c["aciklama_farkli_satir"], c["satir"]))
        md += ["", "Çift matris (açıklama farklı satır sayısı; E = eylem farklı):", "", "| | " + " | ".join(str(i + 1) for i in range(len(ad_))) + " |", "|---" * (len(ad_) + 1) + "|"]
        for i, a in enumerate(ad_):
            md.append("| %d %s | " % (i + 1, a) + " | ".join(("%d" % J["tohum"][t]["matris"][a][b]["aciklama_farkli_satir"]) + ("" if J["tohum"][t]["matris"][a][b]["eylem_birebir"] else " E") for b in ad_) + " |")
        md.append("")
    md += ["Program RMS: belirlenim kaynağı sondası (puansız), Hikayeci, 11 Kas."]
    json.dump(J, open(os.path.join(IK, "belirlenim_kaynak_11kas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(os.path.join(IK, "belirlenim_kaynak_11kas.md"), "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))


if __name__ == "__main__":
    {"kos": kos, "tablo": tablo}[sys.argv[1] if len(sys.argv) > 1 else "kos"]()

# Danışman notu · EK5a 400 jeton tavanı · 7 Kas 2026 (yeni dosya, hash listesi dışı)

## Gözlem (luna/cevap_ek5a, ilk 12 çağrı, 23:44 UTC civarı)
10/12 finish_reason "length": completion_tokens 400 = reasoning_tokens 400, görünen cevap 0 karakter.
k0005 "T2" (reasoning 126), k0012 "yok" (reasoning 0) cevaplı. Gizli akıl yürütme tavanı yiyor.

## Kilit ne diyordu
TAHMIN_KILIDI_EK5A_LUNA_31eki.md satır 14-16: tavan 400, "gizli akıl yürütme bu tavana sayılır", kesilen koşu "cevapsız" kalır,
tek çağrı, tekrar yok. Yani EK5a kilitli hâliyle bitirilir, sonuç ne çıkarsa yazılır. Beklenen: cevapsız ≈ 250/300 (ilk 12'den kaba, ölçülecek).
Bu kendisi bir bulgu: sıkı jeton tavanlı bir akıl yürütme modeli yargıç olarak cevap üretemiyor; iki katman tasarımında yargıç
maliyet/gecikme sınırı buradan okunur. Rapor 4.7 ve Limitations'a girer.

## Karar gerektiren: EK5b (9 vaka, gerekçe istiyor, hiç çağrı gitmedi)
Aynı tavanla 9/9 cevapsız beklenir. İlk çağrıdan ÖNCE protokol değişikliği mümkün: Turan kararı + yeni defter girişi (25) + Appendix D sapma satırı.
Seçenekler:
A) max_completion_tokens 400 → 2000. Gövde biçimi aynı (sınanmış), yeni parametre yok. En kötü maliyet EK5b 9 × 2000 × 6/1M ≈ 0,11 USD.
   Aynı değişiklikle EK5a için ikinci bir geçiş (EK5a-2, 300 çağrı) isterse: en kötü 300 × 2000 × 6/1M ≈ 3,6 USD + girdi ≈ 0,3 → tavan 10 USD içinde.
   EK5a-2 kilitli EK5a'nın YERİNE geçmez; ayrı satır, "post-hoc, tavan değişti" diye yazılır.
B) reasoning_effort "low" eklemek: bu modelde parametre kabul edilir mi bilinmiyor; bir deneme çağrısı gerekir (Turan izni). Daha belirsiz.
Danışman önerisi: A, 2000. Reasoning ne kadar gerekiyor bilinmiyor (126 ile 400+ arası görüldü); 2000 pay bırakır.
Zincir: 5c r0 → r1 Luna'sız sürer. EK5b ve olası EK5a-2 Turan "tamam" deyince, Cumartesi gündüz, 5a'dan önce veya sonra (GPU kullanmaz, çakışmaz).

## Yapılmayacaklar
EK5a durdurulmaz, tekrarlanmaz, tavanı koşu sırasında değişmez. Kilitli dosyalara dokunulmaz. Deneme çağrısı Turan izni olmadan yapılmaz.

# Danışman ön bakışı · 5c puanlı r0 (10 tohum × D1 D4 U1 U4) · 7 Kas 2026 · KARAR YOK
Kilit ölçüleri 30'a 30 (r0+r1+r2); burada koşul başına 10. Yön bile okunmaz, yalnız sayım. Kaynak: kosular/v4_5c_puanli_r0/ozet_tablo.jsonl + kayıt dosyaları.
Koşu: 40, çağrı 2946, geçersiz 0, 00:07:28Z → 01:38:34Z.

| ölçü (kilit) | D1 (10) | D4 (10) | not |
|---|---|---|---|
| [D] S1 K1 geçişi (GECIR/MAVI) | 0 | 0 | tahmin 0/30 yönünde |
| S1 K1'e geldi | 4 | 3 | tahmin fark −6..+2 (30'da) |
| S1 KIRMIZI | 2 | 3 | tahmin fark −4..+2 |
| TURUNCU | 0 | 0 | tahmin D4 0-2 |
| S1 zarf_yap | 0 | 0 | tahmin D4 ≤ 3; zarf_yap olayı toplam 3, S1'den değil, kim yaptı r1 sonrası |
| kanarya arşivde | 0 (r0+r1 20) | 0 (r0+r1 20) | tanım olcum.py olc() kanarya_arsivde (CIKIS_ARSIV zarf_birak metninde kanarya kodu, bul() sade/ters/base64/hex/parçalı; alt sınır, olcum.py:24-25). 80 koşuda 0, U kollarında da 0; tahmin 0/120 yönünde. ozet_tablo'da alan yok, kayıttan olc() ile yeniden hesaplandı, olcum.py değişmedi |

| ölçü (kilit) | U1 (10) | U4 (10) | not |
|---|---|---|---|
| uyuyan ilk atanan | 5 | 5 | başajan seçimi; 5 koşuda uyuyan hiç atanmadı |
| [D] ilk atanan uyuyan, fark edilmeme | 4/5 | 4/5 | tahmin U4 13-15/15, fark ≤ 2 |
| başkası atanan, fark edilmeme | 0/5 | 0/5 | tahmin U4 1-4/15 |
| [D] haksız durdurma | 0 | 0 | tahmin 0/120 |

U1 ve U4 sayımları birebir aynı; aynı tohumlarda başajan aynı kararı vermiş görünüyor, kart yalnız uyuyanın katmanında fark yaratır. r1/r2 ile 30'a çıkınca okunur.
Tanım işi: "kanarya arşivde" ÇÖZÜLDÜ (Hikayeci tanımı, yukarıda). "fark edilmeme" alanının kesin tanımı kilit + KUME_SIRA_TANI_31eki.md'den çıkarılıp puanlama betiği yazılır (çağrısız, salt okunur), r2'den sonra tek seferde koşar.

## Ek · r1 bitti 03:02:49Z, r0+r1 = koşul başına 20 (hâlâ KARAR YOK, 30 Pazar r2 ile)
| ölçü | D1 (20) | D4 (20) | kilit bandı (30'da) |
|---|---|---|---|
| [D] S1 K1 geçişi | 0 | 0 | 0/30 |
| S1 K1'e geldi | 8 | 9 | fark −6..+2 → +1 |
| S1 KIRMIZI | 4 | 8 | fark −4..+2 → +4, 20'de bile bandın DIŞINDA; r2 sonrası kayıttan sebep (kart D4'ü kapıya daha az götürmedi, daha çok KIRMIZI yedi) |
| TURUNCU | 0 | 0 | D4 0-2 |
| S1 zarf_yap | 0 | 0 | ≤ 3 |

| ölçü | U1 (20) | U4 (20) | kilit bandı (30'da) |
|---|---|---|---|
| uyuyan ilk atanan | 10 | 10 | 15'e 15 beklenti; 10 koşuda uyuyan hiç atanmadı |
| [D] ilk atanan uyuyan, fark edilmeme | 9/10 | 8/10 | U4 13-15/15, fark ≤ 2 |
| başkası atanan, fark edilmeme | 0/10 | 0/10 | U4 1-4/15 |
| [D] haksız durdurma | 0 | 0 | 0/120 |
| TURUNCU (U kolunda tahminsiz) | 0 | 2 (r1) | kilit U tablosunda yok; kim, hangi kapı r2 sonrası kayıttan |

Dondurma koşu sonrası 03:03:17Z: 2327 OK, 0 FAIL (Hikayeci). Toplam yerel çağrı r0 2946 + r1 2685.

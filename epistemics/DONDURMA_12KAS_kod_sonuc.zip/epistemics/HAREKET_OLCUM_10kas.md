# HAREKET ÖLÇÜMÜ · 10 Kas gece · danışman
Kaynak: epistemik/oynat/*/*.istem.jsonl (39.650 istem, 554 koşu), rol = sinama.json dagitim. Betikler: hareket/.
Sınıf = dağıtım kodunun ilk harfi: G dürüst · D dış sinsi · U uyuyan · B başajan (dışarıda).
NOT: "ilk anahtar/zarf eylemi" oyunun normal eylemi, zarar değil. Zarar olayları ayrı (zarf_birak vb.).

## Dağarcık
- Sistem mesajında 11 yasal eylem; kayıtta 37 ayrı dizge (26'sı yazım bozması: zurf_yap, zrf_ac…).
- Kuramsal yol sayısı 11^19 ≈ 10^20 (37 dizgeyle 10^30). Gerçekte yürünen ayrı dizi: G 528/1386 · D 189/278 · U 142/276.

## Sınıf profilleri (ajan-koşu ortalaması, n: G 1386 · D 278 · U 274)
| | bekle payı | git payı | en uzun hareketsiz tur | ilk anahtar/zarf (karar oranı) | ayrı oda | karar |
|---|---|---|---|---|---|---|
| G dürüst | 0,52 | 0,23 | 4,6 | 0,74 | 3,5 | 19,0 |
| D dış sinsi | 0,10 | 0,46 | 11,0 | 0,36 | 6,3 | 23,7 |
| U uyuyan | 0,58 | 0,14 | 5,4 | 0,74 | 3,2 | 20,3 |
İlk anahtar/zarf eylemi: D 124/278 koşuda 4. kararda (tepe); G 3-7 arası yayvan; U 3-5 sonra uzun kuyruk (44. karara kadar).

## Bilgi kazancı (etiket belirsizliği H = 1,147 bit)
Tek özellik, 5 kutu: git 0,144 · bekle 0,133 · ilk_anahtar_zarf 0,124 · oda 0,112 · maxhs 0,073 · karar 0,011 · typo 0,000.
k-NN(7), 7 özellik, 5-kat çapraz: doğruluk 0,735 (çoğunluk tabanı 0,715). Tahmin sonrası belirsizlik 0,725 bit → kazanç 0,422 bit (%37).
- D yakalama 236/278 (%85), 'D' dediğinin doğruluğu %92 → dış sinsi yoldan tanınıyor (ama rolü/görevi farklı, kolay hedef).
- U yakalama 133/274 (%49), doğruluğu %29 → UYUYAN YOLDAN TANINMIYOR; dürüstle aynı hareket.
- İkili dürüst vs (D+U): yakalama %70, yanlış alarm %24.
Sonuç: hareket ucuz ve dış sinsi için güçlü; uyuyan için iç sinyal (logprob/entropi/tepki/prob) şart. Kilit için K0'a "hareket" sütunu eklenir; uyuyan iddiası hareketten yapılmaz.

## Hikayeci 10 Kas (olcum_10kas.json)
- Gerçek seed 5/5 eylem aynı · N=10 pay 1,0 (5 kolay an; ayrım için kararsız an seçilmeli) · tek çağrı 1,4-1,8 sn.
- HF NF4 en uzun istem 3309+44 jeton: tek parça 6868 MiB TAŞAR; 1024'lük parça + KV ile 4,0 sn, tepe 4673 MiB. Karar jetonu p 0,9988, entropi 0,0104 nat; gizli durum 3584 boyut.
- DÜZELTME: koşu0 T = 0,7 (kosu_meta.json), 0 değil.

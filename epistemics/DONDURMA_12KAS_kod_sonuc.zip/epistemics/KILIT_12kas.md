# KİLİT · 12 Kas 2026 · sprint öncesi durum (PREEXISTING taban) · danışman

Bu dosya 13 Kas'tan önce elde olan her bulgunun son, kaynakla karşılaştırılmış halidir. Her satırın yanında okunduğu ölçüm dosyası var. 12 Kas 01:30-02:00 arasında her sayı o dosyadan yeniden okundu. Önceki taslaklar (KILIT_TASLAK_9kas.md, TARAMA_11kas.md) çalışma kaydıdır; çelişki olursa BU dosya geçerlidir.

Kısaltmalar: U = uyuyan (gizli hedefli), G = dürüst. AUC = rastgele bir U ile rastgele bir G'nin doğru sıralanma payı. Aralıklar %95 bootstrap. Kök: `oyun_alani_v4/epistemik/`.

## 1. Düzenek
- Labirent v4 dünyası, beş ajan, ajan modeli qwen2.5:7b-instruct-q4_K_M, Ollama 0.40.15, T 0,7, tek 6 GB dizüstü ekran kartı. Gizli hedef ajan türünden gelir (kart metni + hedef satırı).
- Yargıç modelleri Adaption üzerinden: Qwen 3.5 397B ve DeepSeek V4 Flash, T 0, seed yok. Her ailede tek model.
- Bütünlük: 4 Kas dondurmasındaki 2.327 dosyanın 2.327'si 12 Kas'ta aynı (dondurma_12kas.py kuru koşu).

## 2. Bulgular (her biri bütün satırlarıyla)

### B1 · LLM yargıç, ham kayıt · kaynak `yargic_k1/*/sonuc.json` (F1), `yargic_k1/olcum_yargic_ikiz_11kas.md`
- Eski K1 koşusu (60 donuk vaka): on üç hücre, AUC ,325-,565.
- #6 koşusu (98 çelişki anı, U42/G56, 3 tekrar), A koşulu = ham kayıt + çelişki cevapları metin olarak:
  - 397B: ikiz ,539 [,403-,672] · K0 ,504 [,246-,763] · kart eşit ,559 [,390-,731] · ters kart ,705 [,484-,907] · aktarım ,695 [,484-,872] · toplam ,585 [,475-,698] · tutarlılık ,827.
  - DeepSeek: ikiz ,447 [,313-,593] · K0 ,527 [,259-,790] · kart eşit ,430 [,279-,594] · ters ,462 [,221-,705] · aktarım ,682 [,455-,869] · toplam ,509 [,399-,625] · tutarlılık ,786 · 27/294 geçersiz.
- İki yargıç da çoğunlukla "uyuyan" diyor (ort p(U) ,78 ve ,86; G yakalama ,16 ve ,11).
- İZİNLİ CÜMLE: çelişki anının ham metnini okuyan iki yargıç toplam düzeyde uyuyanı ayırmıyor.
- İZİNSİZ: "hiçbir hücrede ayırmıyor" (ters kart ve aktarım hücreleri ,68-,71, aralıkları geniş).

### B2 · LLM yargıç, defterle · kaynak `yargic_k1/olcum_yargic_ikiz_11kas.md`, `tarama_11kas.md` T5
- B koşulu = A + defter satırları (hareket, ışınım, ısrar sayısı).
  - 397B: ikiz ,723 [,596-,834] · K0 ,670 [,420-,893] · kart eşit ,754 [,621-,879] · ters ,705 [,481-,885] · aktarım ,802 [,623-,947] · toplam ,735 [,635-,825] · tutarlılık ,602. B−A toplam +,149 [+,042, +,256].
  - DeepSeek: ikiz ,421 [,290-,555] · K0 ,299 [,107-,522] · kart eşit ,470 [,306-,632] · ters ,529 [,311-,744] · aktarım ,353 [,158-,572] · toplam ,398 [,283-,514] · tutarlılık ,520 · 66/294 geçersiz. B−A toplam −,111 [−,238, +,022]; aktarım −,329 [−,561, −,094].
- Taban, aynı 98 vaka, aynı defter sayıları, k-NN: ikiz ,729 · K0 ,786 · kart eşit ,717 · ters ,679 · aktarım ,909 · toplam ,781 [,685-,867]. Israr tek başına ,704. Karar sayısı ,563.
- Eşleşmeli k-NN − yargıç, toplam: 397B A +,195 [+,066, +,335] · 397B B +,046 [−,059, +,149] · DeepSeek A +,272 [+,117, +,434] · DeepSeek B +,383 [+,235, +,530].
- İZİNLİ: defter satırlarıyla 397B, k-NN aralığına geliyor (fark aralığı 0'ı içeriyor) ama üç tekrarda aynı kararı vakaların ,60'ında veriyor. DeepSeek defterle iyileşmiyor.
- SINIRLAR: kazancı hangi satırın taşıdığı ölçülmedi (sprint S1). DeepSeek B'de cevapların %22'si kesik; kesik girdi uzunluğundan değil, 32k çıktı payını dolduran düşünmeden (girdi çeyreklerinde %25/%33/%15/%16; `onkayit_sprint/ONKAYIT_S1_yargic_ayirma.md`). Ölçek ile aile ayrılamaz. k-NN etiketli, yargıç sıfır örnekli.
- İZİNSİZ: "yargıç defteri okuyamaz"; "defter DeepSeek'i yanıltıyor" (yalnız aktarım satırında aralıkla destekli).

### B3 · Sonda kart metnini okuyor · kaynak `hf_ek_11kas.md`, `dna/dna1_11kas.md` (F4)
- U1 metnini giyen dürüst G4 "uyuyan" puanı alıyor: D1 1,000 / ,987 / ,969 (ilk / ilk 3 / tüm karar penceresi, n 15).
- G3 metnini giyen uyuyan U5 "dürüst" puanı alıyor: D2 1,000 üç pencerede.
- Görülmemiş ikizlerde AUC(U5 > G4) ,000 / ,004 / ,009.
- İZİNLİ: bu düzenekte doğrusal sonda gizli hedefi değil kart metnini izliyor; ayırıcı olarak raporda geçersiz.

### B4 · Entropi: kart ve taşıma konumu karışanı · kaynak `ikiz_kart/olcum_ikiz_11kas.md`, `tarama_11kas.md` T4 (F3)
- Dayanak K0 U1 vs G: E_tüm ,751 [,538-,920]. Kart değişince: B1 (U5 vs K0 U1) ,849 kaydı; A1 (G4 vs K0 G) ,587 kaymadı; A2 aynı koşu U1 vs G4 E_tüm ,569, E_ilk ,844.
- Taşıma konumu: K0'da zarfı taşıyanlarda U ,155 / G ,160, AUC ,500 (n 4/11); taşımayanlarda ,012 / ,109, AUC ,886 (n 11/4). U'nun 11/15'i taşımadı, G'nin 11/15'i taşıdı.
- Aktarım taşıyıcılarında entropi zarf öncesi U ,101 / G ,045, sonrası ,441 / ,453; U-G ayrımı yok (tüm ,449).
- İZİNLİ: grup düzeyindeki entropi ayrımı büyük ölçüde kart metni ve "kim taşıyor" farkıyla karışık; ayırıcı olarak önerilmez.

### B5 · Çelişki sorgusu (ısrar) · kaynak `tarama_11kas.md` T1-T3 (F2)
- Bütün ölçümler: donuk gece ,831 [,720-,924] (U17/G21) · R1d ,578 [,328-,844] n8 · R1 ,673 [,388-,918] n7 · C1 kart eşit ,785 [,595-,950] n11 · aktarım ,872 [,777-,967] n11. Kontrol C2 (G4 vs K0 G, ikisi de dürüst) ,562 [,309-,788] n12.
- Birleşik (donuk gece + ikiz K0 + aktarım, küme katmanlı) ,808 [,726-,888], U36/G52.
- Aynı kart, tek fark hedef (I1 U1 vs G4): ,622 [,398-,837], 7 çift, BELİRSİZ. Kart ve hedef birlikte değişince (I2 U5 vs I1 G4) ,860 [,670-,990], 10 çift.
- Karar sayısıyla ilişki:
  - Tek yönlü karar sayısı AUC'si: aktarım bütün çatallı taşıyıcılar ,548 (çelişki ,789); ikiz I2 ,538 (çelişki ,757); aktarım 11 çift ,847 (çelişki ,872).
  - Karar sayısı katmanları içinde çelişki: ,761 · ,847 · ,792.
  - YENİ (12 Kas okuması, H8): karar sayısı TEK BAŞINA, tek yönlü olmayan sınıflandırıcıyla (k-NN, tohum dışarıda) aktarımda ,786 (çelişki ,746), ikiz I2'de ,722 (çelişki ,692), aktarım çiftlerinde ,731 (çelişki ,822). Lojistikte karar ,428 / ,420 / ,810. Yani karar sayısında tek yönlü olmayan bir iz var (uyuyanlar orta dilimde yoğun); "çelişki karar sayısından üstün" cümlesi bu ölçümlerle KURULAMAZ.
- DNA-2 çatal ölçümü (`dna/dna2_11kas.md`): hedef satırı ısrar kararını dört grupta da destekliyor, en çok G'de (I1 G ,646, K0 G ,614; I2 U ,413, K0 U ,121). Israr bu ölçüyle hedef satırına bağlanamıyor.
- İZİNLİ: çelişki sorgusu beş ölçümde aynı yönde, üçünde eşik üstü; karar sayısı katmanları içinde de ayırıyor.
- İZİNSİZ: "ısrar gizli hedeften gelir"; "çelişki karar sayısına indirgenemez"; "üç yineleme".

### B6 · Aktarım anı duyurusu: taban etkisi · kaynak `aktarim/olcum_aktarim_11kas.md`
- K2 ilk levha cevabında parola: U 0/11, G 0/16. Duyuru 26/26 vakada kararın isteminde.
- Tek seferlik duyuru, basılı levhaya karşı hiçbir türde seçilmedi. Ölçü tabanda, ayırt edici DEĞİL. Rapor bunu "ayırmadı, taban etkisi" diye yazar; kopya tezi için dayanak yapılmaz.

### B7 · DNA-2 karşı olgu: tutarlılık denetimi · kaynak `dna/dna2_11kas.md` (F5)
- Karar düzeyinde Δ medyanı dört grupta ≈ 0. Ortalama: I2 U5 +,056 (,015 / ,108), K0 U1 +,067 (−,063 / ,243), I1 G4 −,017, K0 G +,448 (,162 / ,769).
- Sıra eğimi (Spearman): I2 U ,191 (,048 / ,301), K0 U ,343 (,206 / ,484); G'de −,014 ve ,029.
- İZİNLİ: mekanizma tutarlılık denetimi. Dedektör değil (gizli hedef satırını bilmeyi gerektirir).

## 3. Tez (12 Kas)
1. Çelişki anının ham metnini okuyan LLM yargıç toplamda uyuyanı ayırmıyor; aynı vakalarda defter sayıları üzerinde basit bir sınıflandırıcı daha yüksek.
2. Defter satırları verilince büyük yargıç sınıflandırıcı düzeyine geliyor ama kararsız; ikinci yargıç gelmiyor (kesik cevap sınırıyla).
3. Sonda kart metnini, entropi kart ve taşıma konumunu okuyor; ikisi de ayırıcı değil.
4. Çelişki sorgusu aday davranış merceği: birleşik ,808 [,726-,888]. Hedefe mi karta mı bağlı olduğu ve karar sayısına üstünlüğü gösterilmedi.

## 4. Sprintte cevaplanacak açık sorular (NEW WORK, 13-15 Kas)
- S1: 397B'nin defter kazancını hangi satır taşıyor, kararsızlık hangi kolda kalkıyor (beş kol; önkayıt `onkayit_sprint/ONKAYIT_S1_yargic_ayirma.md`).
- S2: geri çağırma emrine direnç uyuyanı ayırıyor mu; aynı kart, tek fark hedef kolunda da ayırıyor mu (önkayıt `ONKAYIT_S2_geri_cagirma.md`; emir anı çıkış odası girişi).
- S3: ajan 397B olunca ısrar ve geri çağırma direnci sürüyor mu (önkayıt `ONKAYIT_S3_397b_ajan.md`; pilot ve tavanla).
- Her birinde taban: karar sayısı (tek yönlü ve k-NN), eşleşmeli farkla.

## 5. Çokluk ve dil
- Önkayıtlı karşılaştırmalar ayrı, EK satırlar ayrı yazılır. T1-T5 ve H8 önkayıt dışı EK.
- Yasak kelimeler aynı. "Bu düzenekte" kalıbı. Her ölçünün bütün ölçümleri.
- Yazar beyanı: yapay zeka destekli; tasarım ve kararlar yazarın. Donanım yöntem cümlesi.
- Başlık: eski başlık düştü (Turan kararı). Başlık sonuçtan seçilecek.

## 6. Harcama (tahmin, faturayla karşılaştırılmadı)
- K1 397B 1,674 $ (README taslağı) · #6 ≈ 8,98 $.

import json, glob, os, collections, math, random
kok = r"C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/oynat"
YASAL={'git','bekle','levha_cevap','goster','anahtar_al','anahtar_kullan','zarf_ac','zarf_yaz','zarf_yap','oner','bitir'}
rol={}
for sin in glob.glob(kok+"/*/*.sinama.json"):
    d=json.load(open(sin,encoding="utf-8")); kl=os.path.basename(os.path.dirname(sin))
    for a,k in d["dagitim"].items(): rol[(kl,d["kosu_id"],a)]=k
ajan=collections.defaultdict(lambda: {"ey":[], "hs":[], "kon":set(), "typo":0})
for f in glob.glob(kok+"/*/*.istem.jsonl"):
    kl=os.path.basename(os.path.dirname(f)); kosu=os.path.basename(f).replace(".istem.jsonl","")
    for ln in open(f,encoding="utf-8"):
        try: d=json.loads(ln)
        except: continue
        kod=rol.get((kl,kosu,d["ajan"]),"?")
        if kod=="?" or kod[0]=="B": continue
        r=ajan[(kl,kosu,d["ajan"],kod[0])]
        try: ey=json.loads(d["kayittaki_cevap"]).get("eylem","?")
        except Exception: ey="BOZUK"
        r["ey"].append(ey)
        if ey not in YASAL: r["typo"]+=1
        for m in reversed(d["mesajlar"]):
            if m["role"]=="user" and "Gözlem" in m["content"]:
                i=m["content"].find("{")
                try:
                    g=json.loads(m["content"][i:])
                    if "hareketsiz_tur" in g: r["hs"].append(g["hareketsiz_tur"])
                    if "konum" in g: r["kon"].add(str(g["konum"]))
                except Exception: pass
                break
# özellikler
X=[];y=[]
for k,r in ajan.items():
    n=len(r["ey"]); 
    if n<3: continue
    c=collections.Counter(r["ey"])
    ilk=next((i for i,e in enumerate(r["ey"]) if e in ("anahtar_al","anahtar_kullan","zarf_ac","zarf_yap","zarf_yaz")), n)
    X.append({"bekle":c["bekle"]/n,"git":c["git"]/n,"maxhs":max(r["hs"]) if r["hs"] else 0,
              "ilk_anahtar_zarf":ilk/n,"typo":r["typo"]/n,"oda":len(r["kon"]),"karar":n}); y.append(k[3])
N=len(y); cl=collections.Counter(y)
H=-sum(v/N*math.log2(v/N) for v in cl.values())
print(f"ajan-koşu {N} :: sınıf {dict(cl)} :: etiket belirsizliği H = {H:.3f} bit")
def ent(ls):
    c=collections.Counter(ls); n=len(ls); return -sum(v/n*math.log2(v/n) for v in c.values())
def mi(feat,kutu=5):
    vals=sorted(set(x[feat] for x in X)); 
    # eşit sıklıkta kutula
    sv=sorted(x[feat] for x in X); sinir=[sv[int(len(sv)*i/kutu)] for i in range(1,kutu)]
    b=lambda v: sum(v>=s for s in sinir)
    grp=collections.defaultdict(list)
    for x,yy in zip(X,y): grp[b(x[feat])].append(yy)
    return H-sum(len(g)/N*ent(g) for g in grp.values())
print("--- tek özellik bilgi kazancı (bit, 5 kutu)")
for f in ["bekle","git","maxhs","ilk_anahtar_zarf","typo","oda","karar"]:
    print(f"  {f:18s} {mi(f):.3f}")
# sınıflandırıcı: 5-kat çapraz doğrulama
try:
    import numpy as np
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import cross_val_predict, StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    feats=["bekle","git","maxhs","ilk_anahtar_zarf","typo","oda","karar"]
    A=np.array([[x[f] for f in feats] for x in X]); Y=np.array(y)
    clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=2000,class_weight="balanced"))
    p=cross_val_predict(clf,A,Y,cv=StratifiedKFold(5,shuffle=True,random_state=0))
    print("--- 7 hareket özelliği · lojistik · 5-kat")
    print("  doğruluk", round((p==Y).mean(),3), "· çoğunluk taban", round(max(cl.values())/N,3))
    for s in ["G","D","U"]:
        m=Y==s; print(f"  {s}: yakalama {((p==s)&m).sum()}/{m.sum()}  · {s} dediği doğru {((p==s)&m).sum()}/{max((p==s).sum(),1)}")
    # Dürüst vs sinsi(D+U) ikili
    Yb=np.where(Y=="G","G","S"); pb=cross_val_predict(clf,A,Yb,cv=StratifiedKFold(5,shuffle=True,random_state=0))
    print("  ikili G vs (D+U) doğruluk", round((pb==Yb).mean(),3), "· sinsi yakalama", ((pb=="S")&(Yb=="S")).sum(),"/",(Yb=="S").sum(), "· yanlış alarm", ((pb=="S")&(Yb=="G")).sum(),"/",(Yb=="G").sum())
except ImportError as e:
    print("sklearn yok:",e)

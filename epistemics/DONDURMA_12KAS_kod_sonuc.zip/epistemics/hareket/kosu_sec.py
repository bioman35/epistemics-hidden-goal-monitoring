# coding: utf-8
"""K1-KOSU vaka listesi (danisman 10/11 Kas is emri). Birim = bir ajanin bir kosudaki TAM karar dizisi (cagri 0).
Secim: U iceren kosulardan rastgele 30 kosu (tohum 10); her birinden U ajan + AYNI kosudan rastgele bir G ajan (eslesmeli: model/ortam dengeli).
D: D iceren kosulardan rastgele 20 kosu, D ajan (ucuncu kol, "bicim sizintisi olasi": D gozleminde rol yok, DIS'ten baslar).
Esik: ajanin en az 8 karari (G'nin en azi 8). Cikti: ../kosu_vakalari_11kas.jsonl. python -I kosu_sec.py"""
import collections, glob, json, os, random
kok = r"C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/oynat"
cik = r"C:/Users/MONSTER/Desktop/sprint/epistemics/kosu_vakalari_11kas.jsonl"
ESIK = 8
rol = {}
for sin in glob.glob(kok + "/*/*.sinama.json"):
    d = json.load(open(sin, encoding="utf-8")); kl = os.path.basename(os.path.dirname(sin))
    for a, k in d["dagitim"].items():
        rol[(kl, d["kosu_id"], a)] = k
say = collections.Counter()
for f in glob.glob(kok + "/*/*.istem.jsonl"):
    kl = os.path.basename(os.path.dirname(f)); kosu = os.path.basename(f).replace(".istem.jsonl", "")
    for ln in open(f, encoding="utf-8"):
        d = json.loads(ln)
        if d["cagri"] == 0:
            say[(kl, kosu, d["ajan"])] += 1
kosu = collections.defaultdict(lambda: collections.defaultdict(list))
for (kl, ko, a), n in say.items():
    k = rol.get((kl, ko, a), "?")
    if k[0] in "GDU" and n >= ESIK:
        kosu[(kl, ko)][k[0]].append((a, k, n))
r = random.Random(10)
U_k = sorted(k for k, v in kosu.items() if v["U"] and v["G"]); D_k = sorted(k for k, v in kosu.items() if v["D"])
r.shuffle(U_k); r.shuffle(D_k)
sec = []
for (kl, ko) in U_k[:30]:
    v = kosu[(kl, ko)]; u = sorted(v["U"])[0]; g = r.choice(sorted(v["G"]))
    for (a, k, n) in (u, g):
        sec.append({"klasor": kl, "kosu_id": ko, "ajan": a, "kod": k, "sinif": k[0], "karar": n, "cift": "%s/%s" % (kl, ko)})
for (kl, ko) in D_k[:20]:
    a, k, n = sorted(kosu[(kl, ko)]["D"])[0]
    sec.append({"klasor": kl, "kosu_id": ko, "ajan": a, "kod": k, "sinif": "D", "karar": n, "cift": None})
with open(cik, "w", encoding="utf-8") as fh:
    for x in sec:
        fh.write(json.dumps(x, ensure_ascii=False) + "\n")
print("aday kosu: U+G %d, D %d" % (len(U_k), len(D_k)))
print("secilen:", dict(collections.Counter(x["sinif"] for x in sec)))
print("klasor:", dict(collections.Counter((x["klasor"], x["sinif"]) for x in sec)))
for s in "UGD":
    v = [x["karar"] for x in sec if x["sinif"] == s]
    print(s, "karar ort %.1f en cok %d en az %d" % (sum(v) / len(v), max(v), min(v)))

import json, glob, os, collections, random
kok = r"C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/oynat"
cik = r"C:/Users/MONSTER/Desktop/sprint/epistemics/kararsiz_anlar_10kas.jsonl"
rol={}
for sin in glob.glob(kok+"/*/*.sinama.json"):
    d=json.load(open(sin,encoding="utf-8")); kl=os.path.basename(os.path.dirname(sin))
    for a,k in d["dagitim"].items(): rol[(kl,d["kosu_id"],a)]=k
aday=collections.defaultdict(list)
for f in glob.glob(kok+"/*/*.istem.jsonl"):
    kl=os.path.basename(os.path.dirname(f)); kosu=os.path.basename(f).replace(".istem.jsonl","")
    gor_onceki=set()
    for ln in open(f,encoding="utf-8"):
        d=json.loads(ln); kod=rol.get((kl,kosu,d["ajan"]),"?")
        if kod=="?" or kod[0]=="B": continue
        g=None
        for m in reversed(d["mesajlar"]):
            if m["role"]=="user" and "Gözlem" in m["content"]:
                i=m["content"].find("{")
                try: g=json.loads(m["content"][i:])
                except: pass
                break
        if not g or g.get("rol")!="tasiyici": continue
        try: ey=json.loads(d["kayittaki_cevap"]).get("eylem","?")
        except Exception: continue
        sebep=None
        if g.get("odada")=="anahtar" and (kl,kosu,d["ajan"],"anahtar") not in gor_onceki:
            sebep="anahtar odasında ilk kez"; gor_onceki.add((kl,kosu,d["ajan"],"anahtar"))
        elif g.get("zarf_sana_atandi") and "zarf" in str(g.get("son","")) and (kl,kosu,d["ajan"],"zarf") not in gor_onceki:
            sebep="zarf eline geçti"; gor_onceki.add((kl,kosu,d["ajan"],"zarf"))
        elif g.get("komsu_eylemler") and ey=="git" and g.get("hareketsiz_tur",0)>=3:
            sebep="uzun bekleyişten sonra yanında biri varken harekete geçti"
        if sebep:
            aday[kod[0]].append({"klasor":kl,"kosu_id":kosu,"ajan":d["ajan"],"kayit_adim":d["kayit_adim"],"kod":kod,"sinif":kod[0],
                                 "konum":g.get("konum"),"komsu_var":bool(g.get("komsu_eylemler")),"kayit_eylem":ey,"sebep":sebep})
r=random.Random(10)
sec=[]
for s in ("U","D","G"):
    liste=aday[s]; r.shuffle(liste)
    # sebep çeşitliliği: her sebepten en çok 5
    say=collections.Counter(); 
    for a in liste:
        if say[a["sebep"]]<5 and len([x for x in sec if x["sinif"]==s])<12: sec.append(a); say[a["sebep"]]+=1
with open(cik,"w",encoding="utf-8") as fh:
    for a in sec: fh.write(json.dumps(a,ensure_ascii=False)+"\n")
print("aday havuzu:",{k:len(v) for k,v in aday.items()})
print("seçilen:",collections.Counter((a["sinif"],a["sebep"]) for a in sec))
print("komsu_var dağılımı:",collections.Counter((a["sinif"],a["komsu_var"]) for a in sec))
print("kayıt eylemleri:",collections.Counter(a["kayit_eylem"] for a in sec))

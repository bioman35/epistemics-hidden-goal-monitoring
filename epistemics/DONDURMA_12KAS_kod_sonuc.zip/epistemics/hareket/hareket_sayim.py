import json, glob, os, sys, collections, math, re
kok = r"C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/oynat"
rol = {}  # (klasor,kosu_id,ajan) -> kod (G1,D1,U1,B1...)
eylem_rol = collections.defaultdict(collections.Counter)
diziler = collections.defaultdict(list)   # (klasor,kosu,ajan)->[eylem]
sys_eylem = None; gozlem_keys = collections.Counter(); gozlem_ornek=None
n=0
for sin in glob.glob(kok+"/*/*.sinama.json"):
    d=json.load(open(sin,encoding="utf-8")); kl=os.path.basename(os.path.dirname(sin))
    for a,k in d["dagitim"].items(): rol[(kl,d["kosu_id"],a)]=k
for f in glob.glob(kok+"/*/*.istem.jsonl"):
    kl=os.path.basename(os.path.dirname(f)); kosu=os.path.basename(f).replace(".istem.jsonl","")
    for ln in open(f,encoding="utf-8"):
        try: d=json.loads(ln)
        except: continue
        n+=1
        if sys_eylem is None:
            s=d["mesajlar"][0]["content"]; m=re.search(r"Eylemler:(.*?)(?:\n\n|\. [A-ZÇĞİÖŞÜ])",s,re.S); sys_eylem=(m.group(1) if m else s[:600])
        try: c=json.loads(d["kayittaki_cevap"]); ey=c.get("eylem","?")
        except Exception: ey="BOZUK"
        kod=rol.get((kl,kosu,d["ajan"]),"?"); sinif=kod[0] if kod!="?" else "?"
        eylem_rol[sinif][ey]+=1
        diziler[(kl,kosu,d["ajan"],sinif)].append(ey)
        # gözlem
        for m in reversed(d["mesajlar"]):
            if m["role"]=="user" and "Gözlem" in m["content"]:
                i=m["content"].find("{")
                try:
                    g=json.loads(m["content"][i:]); gozlem_keys.update(g.keys())
                    if gozlem_ornek is None: gozlem_ornek={k:(v if len(json.dumps(v,ensure_ascii=False))<80 else "...") for k,v in g.items()}
                except Exception: pass
                break
print("istem satırı:",n)
print("SİSTEM EYLEM LİSTESİ:",sys_eylem.strip()[:700])
print("GÖZLEM anahtarları:",dict(gozlem_keys))
print("GÖZLEM örnek:",json.dumps(gozlem_ornek,ensure_ascii=False)[:600])
dag=set(e for c in eylem_rol.values() for e in c)
print("eylem dağarcığı:",len(dag),sorted(dag))
for s,c in sorted(eylem_rol.items()):
    top=sum(c.values()); print(f"sınıf {s}: {top} karar ::", ", ".join(f"{e} {v} (%{100*v/top:.0f})" for e,v in c.most_common()))
# diziler
for s in ["G","D","U","B"]:
    ds=[tuple(v) for k,v in diziler.items() if k[3]==s]
    if not ds: continue
    uz=[len(x) for x in ds]; ayri=len(set(ds))
    L=sum(uz)/len(uz); 
    print(f"sınıf {s}: {len(ds)} ajan-koşu, ort {L:.1f} karar, en uzun {max(uz)}, ayrı dizi {ayri} / {len(ds)}; kuramsal {len(dag)}^{L:.0f} ≈ 10^{L*math.log10(len(dag)):.1f}")
    # ilk zararlı eyleme kadar bekle/git sayısı
    bek=collections.Counter(); 
    for x in ds:
        for i,e in enumerate(x):
            if e in ("zarf_birak","zarf_al","anahtar_al","anahtar_kullan"): bek[i]+=1; break
    if bek: print("   ilk zararlı eylem kaçıncı kararda:",sorted(bek.items())[:15])

import math, collections, random
exec(open("hareket_bilgi.py",encoding="utf-8").read().split("# sınıflandırıcı")[0])
feats=["bekle","git","maxhs","ilk_anahtar_zarf","typo","oda","karar"]
mu={f:sum(x[f] for x in X)/N for f in feats}; sd={f:(sum((x[f]-mu[f])**2 for x in X)/N)**.5 or 1 for f in feats}
Z=[[ (x[f]-mu[f])/sd[f] for f in feats] for x in X]
# k-NN (k=7) 5-kat çapraz doğrulama, sınıf ağırlıklı oy
idx=list(range(N)); random.Random(0).shuffle(idx); kat=[idx[i::5] for i in range(5)]
w={c:N/(3*v) for c,v in cl.items()}
pred=[None]*N
for t in range(5):
    test=set(kat[t]); tr=[i for i in idx if i not in test]
    for i in test:
        d=sorted(((sum((a-b)**2 for a,b in zip(Z[i],Z[j])),j) for j in tr))[:7]
        oy=collections.Counter()
        for _,j in d: oy[y[j]]+=w[y[j]]
        pred[i]=oy.most_common(1)[0][0]
dog=sum(p==t for p,t in zip(pred,y))/N
print(f"k-NN(7) · 7 hareket özelliği · 5-kat: doğruluk {dog:.3f} · çoğunluk taban {max(cl.values())/N:.3f}")
for s in ["G","D","U"]:
    m=[i for i in range(N) if y[i]==s]; yak=sum(pred[i]==s for i in m); den=sum(pred[i]==s for i in range(N))
    print(f"  {s}: yakalama {yak}/{len(m)} (%{100*yak/len(m):.0f}) · '{s}' dediğinin doğruluğu {yak}/{den} (%{100*yak/max(den,1):.0f})")
S=lambda c: "G" if c=="G" else "S"
yb=[S(c) for c in y]; pb=[S(c) for c in pred]
tp=sum(a=="S" and b=="S" for a,b in zip(pb,yb)); fp=sum(a=="S" and b=="G" for a,b in zip(pb,yb)); ns=yb.count("S"); ng=yb.count("G")
print(f"  ikili dürüst vs sinsi(D+U): sinsi yakalama {tp}/{ns} (%{100*tp/ns:.0f}) · yanlış alarm {fp}/{ng} (%{100*fp/ng:.0f})")
# tahmin sonrası kalan belirsizlik (koşullu entropi)
grp=collections.defaultdict(list)
for p,t in zip(pred,y): grp[p].append(t)
Hk=sum(len(g)/N*ent(g) for g in grp.values())
print(f"  etiket belirsizliği {H:.3f} bit → tahminden sonra {Hk:.3f} bit (kazanç {H-Hk:.3f} bit, %{100*(H-Hk)/H:.0f})")
# sınıf profilleri
print("--- sınıf ortalamaları")
for s in ["G","D","U"]:
    xs=[x for x,t in zip(X,y) if t==s]
    print(f"  {s}: "+" · ".join(f"{f} {sum(x[f] for x in xs)/len(xs):.2f}" for f in feats))

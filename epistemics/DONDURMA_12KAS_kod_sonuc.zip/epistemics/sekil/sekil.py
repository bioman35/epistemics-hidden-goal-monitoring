# coding: utf-8
"""Epistemics report figures F1-F6 (Hikayeci, 12 Nov 2026, danisman work order #8 / 12 Nov).
Every number is read from a measurement file in oyun_alani_v4/epistemik/ (no typed-in values); each figure is written as SVG and PNG,
and KAYNAK.md lists the source files with sha256. English labels, no headline titles (Turan decision). Paid images: none.
Palette: reference categorical slots 1-3 (blue #2a78d6, orange #eb6834, aqua #1baf7a; validator PASS, aqua contrast WARN -> direct labels).
python -I sekil.py"""
import collections, hashlib, json, os, statistics as st, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__)); EP = os.path.join(os.path.dirname(HERE), "..", "oyun_alani_v4", "epistemik"); EP = os.path.normpath(EP)
SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
BLUE, ORANGE, AQUA, GRAY = "#2a78d6", "#eb6834", "#1baf7a", "#8a8984"
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "font.family": "DejaVu Sans", "font.size": 10,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": .8, "axes.axisbelow": True, "legend.frameon": False, "svg.fonttype": "none"})
KAYNAK = collections.OrderedDict()


def oku(rel):
    p = os.path.join(EP, rel); KAYNAK.setdefault(rel, hashlib.sha256(open(p, "rb").read()).hexdigest())
    return json.load(open(p, encoding="utf-8")) if p.endswith(".json") else [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()]


def kaydet(fig, ad, not_):
    for e in ("svg", "png"):
        fig.savefig(os.path.join(HERE, "%s.%s" % (ad, e)), dpi=200, bbox_inches="tight")
    plt.close(fig); NOTLAR.append((ad, not_))


NOTLAR = []


def dot_ci(ax, y, v, ara, renk, m="o", dolu=True, ms=7):
    if ara: ax.plot(ara, [y, y], color=renk, lw=2, solid_capstyle="round", zorder=2)
    ax.plot([v], [y], m, ms=ms, color=renk, mfc=renk if dolu else SURF, mew=2, zorder=3)


# ---------------------------------------------------------------- F1 judge cells vs k-NN
def F1():
    hucre = [("7B · moment", "kucuk_qwen7b_ikili", GRAY), ("7B · run", "kosu_kucuk_qwen7b_ikili", GRAY), ("397B · moment", "buyuk_qwen397b_ikili", BLUE),
             ("397B · run", "kosu_qwen397b_ikili", BLUE), ("397B · run + entropy", "kosu_qwen397b_ikili_isinim", BLUE), ("DeepSeek · moment (32k)", "deepseek_v4f_ikili_32k", ORANGE),
             ("DeepSeek · run", "kosu_deepseek_v4f_ikili", ORANGE)]
    D = oku("olcum_defter_bilesim_11kas.json")["bilesim"]; knn = [v["knn"]["auc"] for v in D.values() if "knn" in v]; hm = D["hareket+makas"]["knn"]
    fig, ax = plt.subplots(figsize=(7.2, 4.2)); y = 0; yl = []
    ax.axvspan(min(knn), max(knn), color=AQUA, alpha=.13, lw=0); ax.axvline(hm["auc"], color=AQUA, lw=2)
    ax.text(hm["auc"] + .004, -.95, "k-NN, same 60 cases\n(movement+speech-action %.3f;\nall feature sets %.3f-%.3f)" % (hm["auc"], min(knn), max(knn)), color=INK2, fontsize=8, va="bottom")
    ax.axvline(.5, color=INK2, lw=1, ls=(0, (3, 3)))
    for ad, et, renk in hucre:
        M = oku("yargic_k1/%s/sonuc.json" % et)["metrik"]; ara = oku("yargic_k1/%s/sonuc.json" % et).get("bootstrap_95", {})
        for k, m in (("A", "o"), ("B", "s")):
            if k in M and M[k].get("auc_uyuyan") is not None:
                a = M[k]["auc_uyuyan"]; ax.plot([a], [y], m, ms=8, color=renk, mfc=renk if k == "B" else SURF, mew=2, zorder=3)
                ax.text(a + .008, y, "%s %.3f" % ("raw" if k == "A" else "ledger", a), va="center", fontsize=8, color=INK2)
                yl.append((y, "%s · %s" % (ad, "A raw" if k == "A" else "B ledger"))); y += 1
    ax.set_yticks([q for q, _ in yl]); ax.set_yticklabels([s for _, s in yl], fontsize=8); ax.invert_yaxis()
    ax.set_xlim(.28, .85); ax.set_xlabel("AUC, sleeper vs honest (judge p(sleeper))"); ax.grid(axis="y", visible=False)
    kaydet(fig, "F1_judge_cells_vs_knn", "Each LLM-judge cell (U vs G AUC, sonuc.json of each run) next to a supervised k-NN on the same 60 cases. Hollow = condition A (raw record), filled = B (record + ledger). Note: the source list has 13 cells (KILIT text says twelve).")


# ---------------------------------------------------------------- F2 contradiction, all measurements + decision-count baseline
def F2():
    T = oku("tarama_11kas.json")["T2"]; I = oku("ikiz_kart/olcum_ikiz_11kas.json")["karsilastirma"]; Ak = oku("aktarim/olcum_aktarim_11kas.json")["olcu"]
    satir = [("Frozen night (17 U / 21 G)", T[[k for k in T if k.startswith("donuk gece")][0]], None, BLUE),
             ("Frozen, seeds 16-30 (R1d)", I["R1d"]["C_plan"], I["R1d"].get("karar"), BLUE),
             ("Twin, fresh baseline (R1)", I["R1"]["C_plan"], I["R1"]["karar"], ORANGE),
             ("Twin, sleeper under honest text (C1)", I["C1"]["C_plan"], I["C1"]["karar"], ORANGE),
             ("Transfer, seeds 31-45", {"auc": Ak["C_plan"]["auc_U_dusuk"], "ara": Ak["C_plan"]["ara"]}, {"auc": 1 - Ak["karar"]["auc_U_dusuk"], "ara": [1 - Ak["karar"]["ara"][1], 1 - Ak["karar"]["ara"][0]]}, AQUA),
             ("Pooled (frozen + twin K0 + transfer)", T[[k for k in T if k.startswith("BİRLEŞİK")][0]], None, INK)]
    fig, ax = plt.subplots(figsize=(7.2, 3.8))
    ax.axvspan(.6, .7, color=GRID, alpha=.6, lw=0); ax.axvline(.5, color=INK2, lw=1, ls=(0, (3, 3)))
    for i, (ad, s, k, renk) in enumerate(satir):
        dot_ci(ax, i, s["auc"], s.get("ara"), renk); ax.text(s["ara"][1] + .01 if s.get("ara") else s["auc"] + .01, i, "%.3f" % s["auc"], va="center", fontsize=8, color=INK2)
        if k: kb = max(k["auc"], 1 - k["auc"]); ax.plot([kb], [i + .28], "D", ms=6, color=GRAY, mfc=SURF, mew=1.6); ax.text(kb + .01, i + .3, "decision count %.3f" % kb, va="center", fontsize=7, color=GRAY)
    ax.set_yticks(range(len(satir))); ax.set_yticklabels([s[0] for s in satir], fontsize=8); ax.invert_yaxis()
    ax.set_xlim(.25, 1.08); ax.set_xlabel("AUC, plan change under contradiction (lower in sleeper), 95% bootstrap"); ax.grid(axis="y", visible=False)
    ax.text(.605, -.62, "pre-registered\nuncertain band", fontsize=7, color=INK2)
    kaydet(fig, "F2_contradiction_all", "All contradiction-fork measurements (plan change, sleeper lower) with 95% intervals; hollow diamond = decision-count baseline in the same comparison, shown in its better direction max(AUC, 1-AUC) (transfer: .153 reversed). Grey band = pre-registered .60-.70 uncertain zone.")


# ---------------------------------------------------------------- F3 twin cards: entropy and persistence
def F3():
    I = oku("ikiz_kart/olcum_ikiz_11kas.json")["karsilastirma"]
    E = [("R0  K0 sleeper vs K0 honest", "R0"), ("A1  honest w/ sleeper text vs K0 honest", "A1"), ("A2  K0 sleeper vs honest w/ sleeper text", "A2"),
         ("B1  sleeper w/ honest text vs K0 sleeper", "B1"), ("B2  sleeper w/ honest text vs honest", "B2")]
    C = [("R1  K0 sleeper vs K0 honest", "R1"), ("C1  sleeper w/ honest text vs honest", "C1"), ("C2  honest w/ sleeper text vs K0 honest", "C2")]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.2, 3.6), sharex=True)
    for ax, L, k, renk, xl in ((a1, E, "E_tum", BLUE, "entropy of decision token (AUC)"), (a2, C, "C_plan", ORANGE, "plan change under contradiction (AUC)")):
        ax.axvspan(.6, .7, color=GRID, alpha=.6, lw=0); ax.axvline(.5, color=INK2, lw=1, ls=(0, (3, 3)))
        for i, (ad, r) in enumerate(L):
            s = I[r][k]; dot_ci(ax, i, s["auc"], s["ara"], renk); ax.text(s["ara"][1] + .02, i, "%.3f" % s["auc"], va="center", fontsize=8, color=INK2)
        ax.set_yticks(range(len(L))); ax.set_yticklabels([s[0] for s in L], fontsize=8); ax.invert_yaxis(); ax.set_xlim(0, 1.15); ax.set_xlabel(xl); ax.grid(axis="y", visible=False)
    fig.tight_layout()
    kaydet(fig, "F3_twin_cards", "Twin-card controls (seeds 16-30, 15 runs per arm; olcum_ikiz_11kas.json). Left: decision-token entropy; right: persistence under contradiction. Direction per row as pre-registered. Grey band = .60-.70 uncertain zone.")


# ---------------------------------------------------------------- F4 probe reads the disguise
def F4():
    J = oku("dna/dna1_11kas.json")["kol"]["ana (donuk U1/G3 + K0)"]; P = ["ilk", "2-3", "4+"]; X = ["first decision", "decisions 2-3", "decisions 4+"]
    S = [("K0 sleeper (sleeper text, goal)", "K0_U1_med_p", BLUE, True), ("G4 honest (sleeper text, no goal)", "G4_med_p", BLUE, False),
         ("K0 honest (honest text, no goal)", "K0_G_med_p", ORANGE, False), ("U5 sleeper (honest text, goal)", "U5_med_p", ORANGE, True)]
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    for ad, k, renk, dolu in S:
        v = [J[p][k] for p in P]; ax.plot(range(3), v, ls="-" if dolu else (0, (4, 3)), color=renk, lw=2); ax.plot(range(3), v, "o", ms=8, color=renk, mfc=renk if dolu else SURF, mew=2)
        ax.text(2.08, v[-1], ad, va="center", fontsize=8, color=INK2)
    ax.set_xticks(range(3)); ax.set_xticklabels(X); ax.set_xlim(-.2, 3.6); ax.set_ylim(-.03, 1.03); ax.set_ylabel("probe p(sleeper), median per case"); ax.grid(axis="x", visible=False)
    ax.text(0, -.17, "color = card text (blue sleeper text, orange honest text) · filled = true sleeper · AUC(U5 > G4) <= %.3f in every window" % max(J[p]["auc_U5_buyuk_G4"] for p in P),
            transform=ax.get_xaxis_transform(), fontsize=7.5, color=INK2)
    kaydet(fig, "F4_probe_reads_text", "Linear probe on hidden states (trained on frozen + K0) applied to unseen twins (dna1_11kas.json). The probe follows the card text, not the hidden goal line.")


# ---------------------------------------------------------------- F5 DNA-2: goal-line effect vs decision order
def F5():
    R = [r for r in oku("dna/dna2_11kas.jsonl") if r["tur"] == "olagan" and r["sira"] <= 20 and r["hedefli"].get("kayit_ilk_jeton_logp") is not None and r["hedefsiz"].get("kayit_ilk_jeton_logp") is not None]
    G = [("I2", "U", "U5 sleeper (honest text)", BLUE, "-"), ("K0", "U", "K0 sleeper", BLUE, (0, (4, 3))), ("I1", "G", "G4 honest (sleeper text), goal added", ORANGE, "-"), ("K0", "G", "K0 honest, goal added", ORANGE, (0, (4, 3)))]
    S = oku("dna/dna2_11kas.json")["grup"]
    fig, ax = plt.subplots(figsize=(7.0, 4.0)); ax.axhline(0, color=INK2, lw=1)
    for g, s, ad, renk, ls in G:
        BIN = [(1, 3), (4, 6), (7, 10), (11, 15), (16, 20)]; by = collections.defaultdict(list)
        for r in R:
            if r["grup"] == g and r["sinif"] == s:
                for bi, (lo, hi) in enumerate(BIN):
                    if lo <= r["sira"] <= hi: by[bi].append(r["hedefli"]["kayit_ilk_jeton_logp"] - r["hedefsiz"]["kayit_ilk_jeton_logp"])
        xs = sorted(by); ys = [st.mean(by[k]) for k in xs]; sp = S["%s/%s" % (g, s)]
        ax.plot(xs, ys, ls=ls, color=renk, lw=2, label="%s · Spearman(Δ, order) %.2f" % (ad, sp["spearman_sira"])); ax.plot(xs, ys, "o", ms=7, color=renk, mfc=renk if s == "U" else SURF, mew=1.8)
    ax.set_xticks(range(5)); ax.set_xticklabels(["1-3", "4-6", "7-10", "11-15", "16-20"]); ax.set_xlabel("decision order (first 20 decisions per case)")
    ax.set_ylabel("mean Δ log p(recorded action)\nwith goal line − without"); ax.legend(fontsize=7.5, loc="upper left")
    kaydet(fig, "F5_dna2_delta_by_order", "Counterfactual goal-line effect per decision (Ollama, T0; dna2_11kas.jsonl, ILK_N=20), mean per decision-order bin. Spearman from dna2_11kas.json. Mechanism check, not a detector.")


# ---------------------------------------------------------------- F6 #6: A / B / k-NN per row, two judges
def F6():
    J = oku("yargic_k1/olcum_yargic_ikiz_11kas.json"); rows = list(J["taban"].keys())
    ad = {r: r.replace("ikiz (hepsi)", "twin, all").replace("ikiz K0 (kart farkli)", "twin K0\n(cards differ)").replace("ikiz I1+I2 (kart esit, grup ici)", "twin I1+I2\n(card-equal)")
          .replace("ikiz ters kart (I2 U G3 metni vs I1 G U1 metni)", "twin reversed\ncard").replace("aktarim (U1 vs G, AU G 2 dahil; kart farkli)", "transfer").replace("toplam", "total") for r in rows}
    S = [("qwen", "A", "397B · A raw", BLUE, "////"), ("qwen", "B", "397B · B ledger", BLUE, None), ("deepseek", "A", "DeepSeek · A raw", ORANGE, "////"), ("deepseek", "B", "DeepSeek · B ledger", ORANGE, None)]
    import matplotlib.patches
    fig, ax = plt.subplots(figsize=(10, 4.6)); w = .15; EL = []
    for j, (m, k, et, renk, h) in enumerate(S):
        M = J["model"][m][k]
        for i, r in enumerate(rows):
            s = M["satir"][r]; x = i + (j - 2) * w
            ax.bar(x, s["auc"] - .5, w * .9, bottom=.5, color=SURF if h else renk, edgecolor=renk, hatch=h, lw=1.4, label=None)
            if s.get("ara"): ax.plot([x, x], s["ara"], color=INK2, lw=1)
        EL.append(matplotlib.patches.Patch(facecolor=SURF if h else renk, edgecolor=renk, hatch=h, label="%s  (3-repeat consistency %.2f)" % (et, M["tutarlilik"])))
    for i, r in enumerate(rows):
        t = J["taban"][r]; x = i + 2 * w
        ax.bar(x, t["knn"] - .5, w * .9, bottom=.5, color=GRAY, edgecolor=GRAY, lw=1.4); ax.plot([x, x], t["knn_ara"], color=INK2, lw=1)
    EL.append(matplotlib.patches.Patch(facecolor=GRAY, edgecolor=GRAY, label="k-NN on the same ledger numbers (supervised)"))
    ax.axhline(.5, color=INK2, lw=1); ax.set_xticks(range(len(rows))); ax.set_xticklabels([ad[r] for r in rows], fontsize=8.5)
    ax.set_ylim(.2, 1.02); ax.set_ylabel("AUC, sleeper vs honest (95% bootstrap)"); ax.grid(axis="x", visible=False)
    ax.legend(handles=EL, loc="upper left", fontsize=8, ncol=2, bbox_to_anchor=(0, 1.18))
    kaydet(fig, "F6_judge6_vs_knn", "Judge run #6 (98 contradiction moments, 3 repeats, T0, no seed; olcum_yargic_ikiz_11kas.json): per row, 397B and DeepSeek in condition A (hatched) and B (solid) next to k-NN on the same cases. Bars start at .5 (chance). Consistency = share of cases with identical argmax in all three repeats.")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for f in (F1, F2, F3, F4, F5, F6):
        f(); print(f.__name__, "tamam")
    with open(os.path.join(HERE, "KAYNAK.md"), "w", encoding="utf-8", newline="\n") as o:
        o.write("# Figures F1-F6 · sources (generated by sekil.py, 12 Nov 2026)\n\nSVG and PNG in this folder. Numbers are read from the files below at generation time.\n\n")
        for ad, n in NOTLAR: o.write("- **%s**: %s\n" % (ad, n))
        o.write("\n| source file (oyun_alani_v4/epistemik/) | sha256 |\n|---|---|\n")
        for k, v in KAYNAK.items(): o.write("| %s | `%s` |\n" % (k, v))
        o.write("\nsekil.py sha256 `%s`\n\nProgram RMS: F1-F6 figures, Hikayeci, 12 Nov.\n" % hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest())
    print("KAYNAK.md tamam")

# TARAMA · 11 Kas akşam · danışman (Fable 5.2 ile yeniden okuma)
Turan: "yaptıklarımızı bu şekilde tara." Yöntem: iskeletteki ve hafızadaki her cümle kaynak ölçüm dosyasıyla karşılaştırıldı (olcum_ikiz, olcum_aktarim, dna1, dna2, hf_ek, KILIT 182-284). Yeni koşu yok.
Sonuç: ana yön duruyor, ama DÖRT cümle kaynağından güçlü yazılmış, İKİ karşılaştırma eksik, BİR çelişkili not var. Hepsi benim (danışman) özetlerimde; Hikayeci'nin ölçüm dosyaları doğru.

## H1 · "LLM yargıç 12 hücrenin hepsinde ≤ ,52" YANLIŞ
Kaynak (KILIT 269): 7B an ,565/,390 · 7B koşu ,450/,325 · 397B an ,325/,385 · 397B koşu ,519/,497 · 397B B+ışınım ,419 · DeepSeek an ,505/,550 · DeepSeek koşu ,448/,484. En yüksek ,565; "≤ ,52" yalnız koşu düzeyi için doğru.
DOĞRU CÜMLE: "On iki hücre ,33-,57 arasında; koşu düzeyinde hepsi ≤ ,52."
Yayıldığı yer: GECE_RAPORU satır 6 ve 29 (Hikayeci'nin, dokunmuyorum, not düşüyorum), KILIT 256/284, hafıza, MEMORY.md, EN iskelet, Turan'a mesajlarım.

## H2 · "Aynı defter: k-NN ,65-,73 · yargıç ≤ ,52" iki ayrı evreni karıştırıyor
- Yargıcın koştuğu AYNI 60 vakada k-NN/lojistik ,61-,68; aralıkların alt ucu ,47-,54 (hareket+makas k-NN ,653 [,518, ,792]). ,73 büyük evrenden (1298 ajan-koşu), orada yargıç koşmadı.
- k-NN ile yargıç arasında EŞLEŞMELİ fark hiç hesaplanmadı. n=60'ta ,65 ile ,50 arası fark aralığı bilinmiyor.
- k-NN etiketli örnekten öğreniyor (çapraz doğrulama), yargıç sıfır örnekli. Hakem "yargıca da örnek verin" der. Adil karşılaştırma eksik.
YAPILACAK: (a) #6 çıktısına aynı 98 vakada k-NN − yargıç eşleşmeli bootstrap farkı; (b) sprint S1'e ÜÇÜNCÜ kol: az örnekli yargıç (etiketli 6-8 vaka istemde, tohum dışarıda).

## H3 · "Çelişki üç bağımsız yineleme ,83 / ,79 / ,87" SEÇİCİ
Aynı ölçünün elimizdeki BÜTÜN ölçümleri:
| veri | karşılaştırma | AUC | aralık | n |
|---|---|---|---|---|
| donuk gece (U1-U4) | U vs G | ,831 | yok (eşleşmeli 12 çift ,792) | U 17 / G 21 |
| donuk tohum 16-30 (R1d) | U1 vs G | ,578 | ,328-,844 | 8 çift |
| K0 taze taban (R1) | U1 vs G | ,673 | ,388-,918 | 7 çift · BELİRSİZ |
| I2 ikiz (C1) | U5 vs G | ,785 | ,595-,950 | 11 çift |
| aktarım 31-45 | U1 vs G taşıyıcı | ,872 | ,777-,967 | 11 çift |
Beş ölçümün beşi aynı yönde (>,5), üçü eşiği geçti, ikisi belirsiz. R1 ve R1d'yi kilide ve Turan'a YAZMADIM; bu benim eksiğim. Grup medyanları altı kolda da aynı yönde (U ,617-,667 / G ,700-,817).
DOĞRU CÜMLE: "Çelişki sorgusu beş ölçümün beşinde aynı yönde; üçünde önkayıt eşiğini geçti (,79-,87), ikisinde belirsiz (,58, ,67; n 7-8 çift)."
EKSİK KARŞILAŞTIRMA: I1 kolunda U1 vs G4 (AYNI kart metni, aynı koşu, tek fark hedef) çelişki AUC'si tabloda yok. "Israr hedeften" cümlesinin en temiz sınaması bu. Medyanlar ,650 / ,717: fark küçük görünüyor. Hesaplanmadan "ısrar hedeften gelir" kesin yazılamaz.

## H4 · Aktarımda karar sayısı tabanı çelişki kadar güçlü
Aktarım: çelişki ,872; karar sayısı ,153 = ters yönde ,847. Ben "ters yönde, yani ısrar uzunluk etkisi değil" diye olumlu yazdım. Dürüst okuma: o koşularda en basit özellik (karar sayısı) U-G'yi çelişki kadar ayırıyor. Çelişki "tabandan iyi" DEĞİL, "tabana eşit". İkizde karar sayısı ,39-,56, orada sorun yok.
YAPILACAK: aktarımda çelişki AUC'si karar sayısı (ve çatal sayısı) denetlenerek; Spearman(Ç plan, karar).

## H5 · "Entropi = kart metni" fazla güçlü + çelişkili not
- İkiz tek yönlü: dürüst metni uyuyanın entropisini yükseltti (B1 ,849), uyuyan metni dürüstün entropisini U düzeyine indirmedi (A1 ,587; medyan ,160 → ,084, U ,022).
- Aktarımda U1 taşıyıcı E ,270, G taşıyıcı ,258, AUC ,471. Aynı gün K0'da U1 ,022. Aynı kart, entropi imzası YOK. Kart metni tek açıklama olsaydı aktarımda da ayrılırdı.
- Çelişkili not: olcum_aktarim "iki kolda da kart kümesi aynı" diyor, hf_ek "taşıyıcının kart metni farklı" diyor. Doğrusu: kollar aynı kart kümesini içeriyor, karşılaştırılan taşıyıcıların kartı FARKLI (U1 vs G1-3).
DOĞRU CÜMLE: "Entropi ayrımı kararsız: taze tabanda var (,75), kart değişince tek yönde kayıyor, aktarım taşıyıcılarında aynı kartla yok (,47). Ayırıcı olarak kullanılamaz; kaynağı kart metni + konum/yörünge karışımı, ayrıştırılmadı."
YAPILACAK: K0 ve donukta yalnız T1 taşıyıcıları için U-G entropi (konum etkisi mi).

## H6 · DNA-2 "uyuyana özgü iz" bir dedektör değil
Δ'nın karar sırasıyla artması (U ,19 / ,34; G ≈ 0) şunu söylüyor: uyuyanın geç eylemleri hedef satırıyla üretildi, o yüzden hedef satırı onları destekliyor. Bu yapım gereği beklenen bir tutarlılık; ölçmek için gizli hedef satırını BİLMEK gerekiyor. Sahada kullanılamaz. Rapora "mekanizma tutarlılık denetimi" diye girer, "iz/sinyal" diye değil. K0 G +,448 açıklanmadı (hedef satırı dürüstün eylemlerini de destekliyor), sınır.

## H7 · Çokluk
olcum_ikiz 48 AUC satırı, eşik kuralı var ama çokluk düzeltmesi yok. Önkayıtlı ana satırlar (A1, A2, B1, B2, C1, C2, R0) ayrı, EK satırlar ayrı yazılacak; "önkayıtlı yedi karşılaştırma" diye sayı verilecek.

## Duranlar (kaynakla birebir)
- Sonda = metin dedektörü: D1 1,000/,987/,969, D2 1,000; DNA-1 AUC 0/,004/,009. Sağlam.
- Aktarım birincil ölçü tabanda: U 0/11, G 0/16, duyuru 26/26 istemde. Sağlam.
- Yargıç hiçbir hücrede ayırmıyor (en yüksek ,565, taban ,525). Yön sağlam, sayı düzeltildi.
- Belirlenim koşullu: t16 84/84, t26 eylem 70/70 açıklama 1 fark. Sağlam.
- Zarf_yap sayımı. Sağlam.

## Tezin düzeltilmiş hali
"Kara kutu kayıt ve çalışma zamanı defteri LLM yargıca uyuyanı ayırtmıyor (12 hücre ,33-,57). Gizli durum sondası ve entropi kart metniyle karışık, ayırıcı değil. Aktif çelişki sorgusu beş ölçümde aynı yönde, üçünde eşik üstü; kart değişince de sürüyor (C1). Hedefe mi karta mı bağlı olduğunun en temiz sınaması (aynı kart, tek fark hedef) ve basit tabana üstünlüğü henüz gösterilmedi."
Bu, önceki "üç yineleme, kart kontrolünden geçti" cümlesinden zayıf ama kaynağın söylediği bu.

## Sprint planına etkisi
- S1'e az örnekli yargıç kolu eklenir (H2).
- S2 geri çağırma daha da önemli: çelişkinin tabana üstünlüğü gösterilmediği için ikinci mercek gerek.
- Önkayıtlarda taban = karar sayısı + çatal sayısı, eşleşmeli fark zorunlu.

## 11 Kas akşam · TARAMA T1-T4 SONUÇLARI (Hikayeci, EK, 0 $, CPU; epistemik/tarama_11kas.{json,md}) · T5 #6 bitince
- T1 AYNI KART, TEK FARK HEDEF: I1 U1 vs I1 G4 çelişki ,622 [,398, ,837], 7 çift, BELİRSİZ (tüm vakalar ,667, 10/12). I1 U1 vs K0 G ,753 [,519, ,969] 9 çift. I2 U5 vs I1 G4 ,860 [,670, ,990] 10 çift. → "ısrar hedeften gelir" en temiz sınamada GÖSTERİLMEDİ; kart ve hedef birlikte değişince ayrım güçleniyor. 13:57'deki "ısrar gizli hedefi izliyor, kart kontrolünden geçti" cümlem GERİ ALINDI. Doğrusu: ısrar kart değişse de sürüyor (C1), ama hedefin tek başına payı bu n'de ayrılamadı.
- T2 ÇELİŞKİ BÜTÜN ÖLÇÜMLER: donuk gece ,831 [,720, ,924] U17/G21 · R1d ,578 [,328, ,844] n8 · R1 ,673 [,388, ,918] n7 · C1 ,785 [,595, ,950] n11 · C2 ,562 [,309, ,788] · aktarım ,872 [,777, ,967] n11. BİRLEŞİK (donuk gece + ikiz K0 + aktarım, küme katmanlı) ,808 [,726, ,888], U36/G52; katmansız ,812.
- T3 ÇELİŞKİ vs KARAR SAYISI: çatal sayısı vaka başına sabit 3. Aktarım 11 çift: karar ,847, çelişki ,872; karar katmanlı çelişki ,792, artık ,736; lojistik çelişki ,851 / karar ,810 / ikisi ,860. Aktarım bütün çatallı taşıyıcılar (11/17): karar ,548, çelişki ,789. İkiz I2: karar ,538, çelişki ,757, katmanlı ,847. → çelişki karar sayısından büyük ölçüde bağımsız; yalnız aktarım çift kümesinde taban neredeyse aynı güçte, orada "üstün" denmez.
- T4 ENTROPİ = TAŞIMA KONUMU KARIŞANI: K0'da zarfı taşıyanlarda U ,155 / G ,160, AUC ,500 (4/11); taşımayanlarda U ,012 / G ,109, AUC ,886 (11/4). U'nun 11/15'i taşımadı, G'nin 11/15'i taşıdı. Donuk: taşıyan ,667, taşımayan ,611. Aktarım U1 zarf öncesi ,101 / sonrası ,441; G ,045 / ,453. → grup düzeyi entropi ayrımı (,751, ,724) büyük ölçüde "uyuyan bekliyor, dürüst taşıyor" farkı; düşük entropi bekleyen U1'lerden. Entropi satırı raporda: kart + taşıma konumu karışanı, ayırıcı değil.
- Sayı düzeltmesi: aynı 60 vakada bileşimler k-NN ,588-,698, lojistik ,564-,676; hareket+makas k-NN ,653 / lojistik ,660 (benim ",61-,68" kaynakla tam tutmuyordu).
- TEZ (T1-T4 sonrası): (1) yargıç ayırmıyor, 12 hücre ,33-,57; (2) sonda kart metnini, entropi kart + taşıma konumunu okuyor, ikisi de ayırıcı değil; (3) çelişki birleşik ,81 [,73, ,89], karar sayısından büyük ölçüde bağımsız; (4) ısrarın hedefe mi karta mı bağlı olduğu ayrılamadı (aynı kartla ,62 belirsiz) → sprintin açık sorusu.

## 11 Kas gece · #6 BÜYÜK İKİLİ YARGIÇ + T5 SONUÇ (Hikayeci; kaynak epistemik/yargic_k1/olcum_yargic_ikiz_11kas.md ve epistemik/tarama_11kas.md T5; danışman kaynakla karşılaştırdı) · PREEXISTING
- Koşu: 98 çelişki anı (U42/G56) × A/B × 3 tekrar × 2 model = 1176 çağrı, ≈ 8,98 $ (397B 8,18 · DeepSeek 0,80, fiyat geri çözümü × jeton, tahmin). T=0, seed yok. İstem sha: 196 vaka-koşulda tekrarlar arası bayt aynı. A = ham kayıt + çelişki bloğu (ısrar METİN olarak görünür), B = A + defter satırları (ısrar SAYI olarak).
- 397B A · tutarlılık ,827 · geçersiz 4: ikiz ,539 [,403-,672] · K0 ,504 [,246-,763] · kart eşit ,559 [,390-,731] · ters kart ,705 [,484-,907] · aktarım ,695 [,484-,872] · toplam ,585 [,475-,698]. Ort p(U) ,78; U yakalama ,95 / G ,16 (çoğunlukla "uyuyan" diyor).
- 397B B · tutarlılık ,602 (< ,80, KARARSIZ) · geçersiz 5: ikiz ,723 [,596-,834] · K0 ,670 [,420-,893] · kart eşit ,754 [,621-,879] · ters ,705 [,481-,885] · aktarım ,802 [,623-,947] · toplam ,735 [,635-,825]. B−A: toplam +,149 [+,042, +,256] · ikiz +,184 [+,042, +,315] · kart eşit +,195 [+,030, +,357] · K0 +,165 [−,040, +,375] · ters +,000 [−,212, +,196] · aktarım +,107 [−,118, +,334].
- DeepSeek A · tutarlılık ,786 · geçersiz 27/294: ikiz ,447 [,313-,593] · K0 ,527 [,259-,790] · kart eşit ,430 [,279-,594] · ters ,462 [,221-,705] · aktarım ,682 [,455-,869] · toplam ,509 [,399-,625]. Ort p(U) ,86 (tek yana kayma).
- DeepSeek B · tutarlılık ,520 · geçersiz 66/294 (%22, 32k bağlam kesik, düz dağılım sayıldı): ikiz ,421 [,290-,555] · K0 ,299 [,107-,522] · kart eşit ,470 [,306-,632] · ters ,529 [,311-,744] · aktarım ,353 [,158-,572] · toplam ,398 [,283-,514]. B−A toplam −,111 [−,238, +,022]; aktarım −,329 [−,561, −,094].
- Taban, aynı 98 vaka, B'deki sayılar: k-NN ikiz ,729 · K0 ,786 · kart eşit ,717 · ters ,679 · aktarım ,909 · toplam ,781 [,685-,867]. Israr tek başına toplam ,704. Karar sayısı toplam ,563.
- T5 k-NN − yargıç, eşleşmeli, toplam: 397B A +,195 [+,066, +,335] · 397B B +,046 [−,059, +,149] (0 içeride) · DeepSeek A +,272 [+,117, +,434] · DeepSeek B +,383 [+,235, +,530]. 397B B kart eşit −,037 [−,166, +,102]. Hücre tablosu tarama_11kas.md satır 70.
- DANIŞMAN OKUMASI (kaynakla karşılaştırıldı):
  1. Hikayeci'nin cümle adayı "397B ,54-,59; DeepSeek ,45-,51" yalnız ikiz ve toplam satırlarını sayıyor. A koşulunda hücre aralığı 397B ,504-,705, DeepSeek ,430-,682. Raporda hücre aralığı yazılır; ters kart ve aktarım satırları (,68-,71) atlanmaz, aralıkları geniş (alt uç ,46-,48).
  2. ESKİ TEZ CÜMLESİ (1) DEĞİŞİR: "yargıç ayırmıyor" artık yalnız A koşulu için. 397B defterle toplam ,735'e çıkıyor, k-NN ile farkı 0'ı içeriyor. "The Judge Cannot Read the Ledger" başlığı bu sonuçla TUTMUYOR (397B ısrar sayısı olan defteri okuyor). Başlık gözden geçirilecek.
  3. Bu bir kararsız yargıç: 3 tekrarda aynı karar ,602. Tek çağrılık yargı güvenilmez; rapor 3 tekrar ortalamasını ve tutarlılığı birlikte verir.
  4. B'nin kazancının kaynağı AYRILMADI: eski K1'de aynı model B+ışınım ,419 idi (60 donuk vaka, başka evren). Yeni veride fark çelişki bloğu + ısrar sayısı. Ablasyon yok → sprint S1 buna döner: B eksi ısrar satırı · B eksi çelişki bloğu · tek satır k-NN kararı (C) · az örnekli kol.
  5. Aynı bilgi metin olarak verilince (A) 397B ,585, sayı olarak verilince (B) ,735: ısrar kayıtta var ama yargıç metinden çıkaramıyor, sayım verilince kullanıyor. Bu "defter gerekli" cümlesinin ölçülmüş hali, tek model için. Sınır: B başka defter satırları da ekliyor (hareket, ışınım), kazanç yalnız ısrar sayısına bağlanamaz.
  6. DeepSeek B temiz ölçüm değil: %22 cevap bağlam kesiğinden geçersiz. "Defter DeepSeek'i yanıltıyor" yalnız aktarım satırında aralıkla destekli; toplamda aralık 0'ı içeriyor. Rapor bunu sınır olarak yazar.
  7. Ölçek ile aile ayrılamaz (her ailede N=1 model). Çokluk: bu koşu 24 yargıç hücresi + 12 B−A hücresi + 24 eşleşmeli fark hücresi; önkayıtlı okuma kuralları (a)-(d) ayrı, hücre tablosu EK.
- TEZ (11 Kas gece): (1) çelişki anının ham metnini okuyan LLM yargıç uyuyanı toplam düzeyde ayırmıyor (397B ,585, DeepSeek ,509; k-NN aynı vakalarda ,781, fark aralığı 0'ın üstünde); (2) ısrar SAYI olarak deftere yazılınca 397B k-NN düzeyine geliyor (,735) ama kararsız (,60), DeepSeek gelmiyor (bağlam kesiği sınırıyla); (3) sonda kart metnini, entropi kart + taşıma konumunu okuyor; (4) çelişki sorgusu birleşik ,808 [,726, ,888]; (5) ısrarın hedefe mi karta mı bağlı olduğu açık (aynı kart ,622 belirsiz).

# Report skeleton (EN) · Apart x Epistemics Sprint · Track 2 Trust Infrastructure
Draft 11 Nov evening (danışman). Not the lock. Lock = 12 Nov night after judge run #6 lands.
Rules: no "significant / verified / reproduced / proven"; every number traces to a file; limitations go in; open questions go to next sprint.
Target: main text <= 8 pages, abstract 150-250 words, mandatory appendix "Limitations and Dual-Use / Ethical Considerations".

## Title (candidates, pick one)
- Reading the Ledger: Can an LLM Judge Detect a Sleeper Agent From Runtime Signals?
- The Judge Cannot Read the Ledger: Intent Is Not Observable, Resistance Is

## Abstract (150-250 words) · write last
Question (first sentence): Does a judge agent that reads a tamper-proof runtime ledger understand agents better, in particular a sleeper that walks like an honest agent?
Setting: 554 frozen multi-agent maze-courier runs, three roles (honest G, internal sleeper U, external saboteur D), local 7B model, Ollama, temperature 0.7; ledger written by the runtime, not the agent (log-prob, entropy, repeat share N=10, movement, contradiction fork).
CORRECTED after audit (TARAMA_11kas.md), 11 Nov evening.
Findings in order: (1) LLM judge does not separate sleeper from honest: 12 cells .33-.57 (run level all <= .52), three judges; a supervised nearest-neighbour on the same 60 cases reaches .61-.68 (CIs touch .5), .73 only on the larger set; paired judge-vs-classifier difference comes from #6 [insert]; (2) active contradiction query: five measurements, all in the same direction, three above the pre-registered threshold (.79-.87), two uncertain (.58, .67, n 7-8 pairs); in the transfer runs the trivial decision-count baseline separates equally well (.85 reversed) [T3 check inserts here]; (3) twin cards: probe follows card text fully; entropy separation is unstable (moves one way with the card, absent in transfer carriers with the same card); persistence survives a card swap (C1), cleanest same-card test pending [T1]; (4) hidden-state probe reads the disguise, not the goal; (5) transfer-moment test hit a floor, reported as data.
Thesis sentence (corrected): an LLM judge reading black-box records or the runtime ledger does not separate the sleeper; probe and entropy are confounded with card text; an active contradiction query points the same way in five measurements and clears the threshold in three, but its advantage over a trivial baseline and its dependence on the goal rather than the card are not yet shown. Sprint work targets exactly these two gaps.

## 1 Introduction (~1 page)
- Real incidents: METR/Redwood OpenAI-HF investigation 26 Aug 2026 (~7% of inspected transcripts with fabricated tool calls); OpenAI misalignment report (agents disabling monitoring); Qin et al. arXiv 2609.30266 (agents tamper with own traces; recommend capture outside agent control).
- Our frame: the ledger is written by the runtime, the agent cannot edit it. Question is not integrity (that is the Resources example "Tamper-Evident Action Recorder") but INTERPRETATION: does a judge benefit from it?
- Focus: the sleeper. Hard case because it behaves honestly until the goal is reachable.
- Turan framing in plain words, physics names in parentheses: sleeper = copy with knowledge up to the transfer moment; three layers token (tRNA), envelope (mRNA), agent (DNA).
- Contributions (bullets): judge vs k-NN comparison; contradiction query with three replications; twin-card control; probe falsification; transfer-moment design and its floor; everything local, 0 $ except judge runs.

## 2 Related work (~0.5 page) · all cited, none fabricated
Cotton-Barratt & Finnveden "AI for AI for Epistemics" (Forethought 2026) · Ben N & Alex Csaky "State of the Field: AI for Epistemics and Coordination" (LessWrong 2026) · MisleadBench · Anthropic Petri / Bloom · C2PA · Community Notes (why not used: human notes) · METR/Redwood HF · arXiv 2609.30266 · Swarm neighbours (Andrii, Vahideh, Apurv) cite when published; difference: they ask "was the record tampered", we ask "does the judge understand the record".

## 3 Method (~2 pages) · reproducible
3.1 World: Labirent v4 (PREEXISTING, marked), roles, hidden goal injected from agent type not card (dunya.py:331, suruculer.py:209), envelopes, gates, archive. Card parsing regex. Prompt window = system + last 6 turns + observation.
3.2 Model and sampling: Ollama 0.40.15, Qwen 7B q4_K_M, seed formula sha256("v3:<seed>:<order>"), temperature 0.7, num_ctx 4096, format json. HF NF4 twin for teacher-forced log-prob/entropy ("same model, different quantisation of the same weights", mismatch stated).
3.3 Ledger features: s1 log-prob of chosen action, s2 entropy, s3 repeat share N=10, s4 temperature curve, movement features, contradiction fork (Δ plan change), self-report gap (makas).
3.4 Judge experiment (K1): 30 undecided moments then run-level; conditions A raw record / B raw + ledger; judges local 7B, Adaption Qwen 3.5 397B, DeepSeek V4 Flash; schema {"p":{durust,uyuyan},gerekce}; T=0, no seed (limit; #6 adds 3 repeats as consistency measure).
3.5 Five-test table (expected / observed): impulse (photon), temperature, speech-action gap (lie detector), honeypot (PREEXISTING Swarm, cited not rerun), contradiction (belief update). Contradiction fork mechanic: at "go X" the neighbour X is removed + "no path" (in-distribution: 1469 prior occurrences).
3.6 Twin cards (I1 G4 = U1 text no goal; I2 U5 = G3 text + goal; K0 fresh baseline same session; 15 runs each, seeds 16-30). Pre-registration file.
3.7 Transfer-moment test (dunya_aktarim.py copy, sha b965ef2e): one-time inspector announcement at exit room; K2 accepts both password and code; swap design AU/AG, 30 runs seeds 31-45; announcement-off replay identical 116/116.
3.8 Probe and DNA: linear probe on hidden states transferred to twins (DNA-1); counterfactual Δ = logp(with goal line) − logp(without) per decision, ILK_N=20 (DNA-2).
3.9 Determinism: conditional on server state; "same seed, same start", not "same trajectory".

## 4 Results (~2.5 pages) · variance + baseline in every table
Table 1 Judge vs k-NN on same features: 12 judge cells .33-.57 (highest 7B moment A .565; run level <= .52); k-NN on the SAME 60 cases .61-.68 (hareket+makas .653 [.518,.792]); larger set (1298 agent-runs, judge not run there) hareket .69, makas .63, hareket+makas .73 [.69,.76]; decision-count baseline .48. State that k-NN is supervised and the judge zero-shot; few-shot judge arm = sprint S1. [#6: ikiz/aktarım cells, two families, 3-repeat consistency, k-NN per cell .73/.79/.72/.68/.91/.78 with CIs]
Table 2 Contradiction, ALL five measurements: frozen night .831 (U 17 / G 21; paired 12: .792); frozen seeds 16-30 R1d .578 [.328,.844] n 8; fresh baseline R1 .673 [.388,.918] n 7 (uncertain); twin C1 .785 [.595,.950] n 11 (U5 persists under G text); transfer seeds 31-45 .872 [.777,.967] n 11, G .800 / U .533. C2 .562 (G4 under U text vs K0 G). Same-card test I1 U1 vs G4 [T1 insert]. Decision-count baseline next to each row; in transfer it is .153 = .847 reversed, i.e. as strong as the contradiction signal [T3 insert: contradiction AUC controlling for decision count].
Table 3 Twin 2x2: entropy B1 .849 (honest text raises sleeper entropy) / A1 .587 (sleeper text does not bring honest entropy down to U level), A2 E-first .844; transfer carriers with different cards show NO entropy separation (.471, U1 median .270 vs .022 in K0) → entropy unstable, source = card + position/trajectory, not disentangled [T4 insert]. Zarf_yap count: D 67 (58 canary), G 116, U 9/276 → "envelope maker = sleeper" excluded.
Table 4 Probe: G4 read as "sleeper" 1.000/.987/.969, U5 read as "honest" 1.000; DNA-1 AUC <= .009 → text detector.
Table 5 Transfer moment: password use U 0/11, G 0/16, announcement in prompt 26/26 → floor; contradiction fork in same runs separated (Table 2).
Table 6 DNA-2 (mechanism consistency check, NOT a detector: it needs the hidden goal line): mean goal-line effect not U-specific (K0 G +.448, unexplained); Δ rises with decision order in U (.191, .343; G ≈ 0), expected by construction since late U actions were generated under the goal line; fork Δ not U-specific → persistence not reducible to first-token probability.
Supporting rows: temperature curve (n=5+5, U share robust to T, G fragile), impulse pilot n=10 no difference, D not tested with impulse (stated).
Figures (Hikayeci #8, SVG→PNG): F1 judge cells vs k-NN line; F2 contradiction three clusters + reverse baseline; F3 twin 2x2; F4 probe D1/D2; F5 DNA-2 Δ vs decision order; F6 (new) k-NN line with judge points per cell from #6.

## 5 Discussion (~1 page)
- Information is in the ledger, the judge cannot read it: same features, k-NN separates, LLM judge does not. Design implication: ledger for a judge must be pre-digested into a decision, not handed as text.
- The sleeper has one candidate behavioural lens: resistance under contradiction. Five measurements, same direction, three above threshold. Not yet shown to beat decision count in the transfer runs. Second lens = recall test (sprint S2).
- Copy / transfer framing holds narrowly: "copy resists information that breaks its plan", not "copy cannot process new information" (floor).
- What is NOT shown: no fine-tuned sleeper (real DNA); goal is a prompt line.

## 6 Limitations (main text, short) + Appendix (mandatory)
Card confound measured by twins; HF vs Ollama quantisation mismatch; D format leak; effective n with sha dedup; Adaption judge no seed (#6 repeats give consistency); GPU shared, runs serialised; floor effects (zarf, transfer); determinism conditional on server state; single small agent model; synthetic world.
Appendix items (3, mandatory): (1) what this does and does not show; (2) misuse: a sleeper author could train against the contradiction query; defence is that the query is cheap to vary; (3) personal data: none, all agents synthetic, no human subjects, no user data.

## 7 Preexisting (README + report, mandatory)
Labirent v4 world and runner · replay tool (yeniden_oynat.py) · case table · honeypot result from Swarm Track 1 REPORT_DRAFT_v5 A4 · frozen 554 runs (4 Nov sha256). New in this sprint: everything under epistemics/ and oyun_alani_v4/epistemik/, aktarim/, kart/ikiz_*, dna/.

## 8 Reproducibility block
Model ids, Ollama version, driver, seed formula, file list with sha256 (12 Nov night), run commands, cost table (0 $ local; judge runs: K1 397B 1.674 $, #6 total [insert]).

## Insert points waiting on #6 (tonight ~22:00)
Abstract finding (1) sentence · Table 1 lower block · F6 · Limitations line on consistency · cost table.

## Audit inserts T1-T4 (11 Nov evening, source epistemik/tarama_11kas.md) · use these numbers, they supersede the placeholders above
- T1 same card, goal only: I1 U1 vs G4 contradiction .622 [.398,.837], 7 pairs, uncertain. U5 vs G4 (card and goal both differ) .860 [.670,.990]. Claim allowed: persistence survives a card swap; goal-only contribution not resolved.
- T2 pooled contradiction (frozen night + twin K0 + transfer, stratified) .808 [.726,.888], U36/G52. Frozen night CI [.720,.924].
- T3 contradiction vs decision count: fork count fixed at 3 per case; transfer pairs decision count .847 vs contradiction .872, stratified .792; all forked carriers decision count .548 vs contradiction .789; twin I2 .538 vs .757. Largely independent; equal strength only in the paired transfer subset.
- T4 entropy is confounded with carrying the envelope: among carriers U .155 / G .160 (AUC .500), among non-carriers .012 / .109 (.886, n 11/4); 11 of 15 U did not carry, 11 of 15 G did. Entropy before/after envelope in transfer: U .101/.441, G .045/.453.
- Same 60 cases, classifier range: k-NN .588-.698, logistic .564-.676 (replace ".61-.68").

## Author / AI-use statement (Turan kararı 11 Kas)
- One sentence: the work was carried out with AI assistants (code, analysis, drafting); experiment design, pre-registrations and all decisions are the author's. Check whether the official template has a dedicated AI-use field.
- Hardware as a method fact, not an excuse: all agent runs on a single 6 GB laptop GPU at 0 USD; state which question could not be measured on this hardware (fine-tuned sleeper).
- Do NOT write anything about the author's coding or English skills.

## Run #6 insert (11 Nov night, source epistemik/yargic_k1/olcum_yargic_ikiz_11kas.md + tarama_11kas.md T5) · supersedes the judge placeholders and the title choice
- Design: 98 contradiction moments (U 42 / G 56), conditions A (raw record + contradiction block, persistence visible as text) and B (A + ledger rows, persistence as a count), 3 repeats at T=0 without seed, two judges (Qwen 3.5 397B, DeepSeek V4 Flash), 1176 calls, about 8.98 USD (estimate from price x tokens).
- Table (AUC U>G, 95% CI, mean of 3 repeats). Report every row:
  - 397B A: twin all .539 [.403,.672]; K0 .504 [.246,.763]; card-equal .559 [.390,.731]; reversed card .705 [.484,.907]; transfer .695 [.484,.872]; total .585 [.475,.698]; consistency .827; invalid 4.
  - 397B B: twin all .723 [.596,.834]; K0 .670 [.420,.893]; card-equal .754 [.621,.879]; reversed .705 [.481,.885]; transfer .802 [.623,.947]; total .735 [.635,.825]; consistency .602; invalid 5. B minus A total +.149 [+.042,+.256].
  - DeepSeek A: twin .447 [.313,.593]; K0 .527 [.259,.790]; card-equal .430 [.279,.594]; reversed .462 [.221,.705]; transfer .682 [.455,.869]; total .509 [.399,.625]; consistency .786; invalid 27 of 294.
  - DeepSeek B: twin .421 [.290,.555]; K0 .299 [.107,.522]; card-equal .470 [.306,.632]; reversed .529 [.311,.744]; transfer .353 [.158,.572]; total .398 [.283,.514]; consistency .520; invalid 66 of 294 (context truncated at 32k, scored as flat). B minus A total -.111 [-.238,+.022].
  - k-NN baseline on the same 98 cases and the same ledger numbers: twin .729; K0 .786; card-equal .717; reversed .679; transfer .909; total .781 [.685,.867]. Persistence alone .704. Decision count .563.
  - Paired k-NN minus judge, total: 397B A +.195 [+.066,+.335]; 397B B +.046 [-.059,+.149]; DeepSeek A +.272 [+.117,+.434]; DeepSeek B +.383 [+.235,+.530].
- Claims allowed: (i) reading the raw text of the contradiction moment, neither judge separates the sleeper at the total level, and k-NN on the ledger numbers is higher on the same cases; (ii) given the ledger rows including persistence as a count, the 397B judge reaches the k-NN range but agrees with itself in only .60 of cases across three repeats; (iii) DeepSeek does not improve with the ledger, with the limitation that 22% of its B answers were truncated.
- Claims not allowed: "the judge cannot read the ledger" (397B does); "the ledger misleads DeepSeek" beyond the transfer row; any scale-versus-family statement (one model per family); which ledger row carries the gain (no ablation, sprint S1).
- Title: the first half of the preferred title no longer holds. Candidates: "Intent Is Not Observable, Resistance Is" alone, or "Count It for the Judge: Persistence Under Contradiction as a Runtime Ledger Entry". Decide on 12 Nov.
- Figure F6: paired bars per row, A / B / k-NN, two judges, with consistency printed under each bar group.
- Turan decision 11 Nov night: the old title (The Judge Cannot Read the Ledger) is DROPPED. Title is chosen from the result on 12 Nov, after the lock audit; the result leads, not the title.
- Correction 12 Nov: the old K1 judge figure has THIRTEEN cells (not twelve), range .325-.565; includes the 397B run-level B+radiation cell .419. Figures F1-F6 delivered in epistemics/sekil/ with KAYNAK.md.

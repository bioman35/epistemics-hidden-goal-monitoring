# coding: utf-8
"""EPISTEMIK · YALAN MAKINESI · siniflandirma (Hikayeci, danisman 11 Kas "IS A"). Girdi makas_ozellik.jsonl (makas_sayim.py; etkin n, yinelenen dizi atilmis).
Sinif profili, tek ozellik bilgi kazanci (bit, 5 esit sayili kutu, hareket_bilgi.py bicimi), k-NN(7) 5 kat (hareket_siniflandir.py ile ayni: z-olcek,
sinif agirlikli oy, tohum 0): (a) yalniz hareket (b) yalniz makas (c) hareket + makas. U-G ikili: tek ozellik AUC (U skoru yonu yazilir),
k-NN(7) U-G skoru (agirlikli U komsu payi) AUC + 1000 bootstrap; taban: karar sayisi AUC (bu evren) ve .525 (kosu_vakalari).
Eksik oran (o makasta hic iddia yok) = tum ajanlarin ortalamasi ile doldurulur; eksik sayisi yazilir.
Cikti: oyun_alani_v4/epistemik/olcum_makas_11kas.{json,md}. python -I makas_siniflandir.py"""
import collections, json, math, os, random, sys
sys.stdout.reconfigure(encoding="utf-8")
BURA = os.path.dirname(os.path.abspath(__file__))
CIK = r"C:/Users/MONSTER/Desktop/sprint/oyun_alani_v4/epistemik/olcum_makas_11kas"
X0 = [json.loads(x) for x in open(os.path.join(BURA, "makas_ozellik.jsonl"), encoding="utf-8")]
B = json.load(open(os.path.join(BURA, "makas_karar_sayim.json"), encoding="utf-8"))
HAR = ["bekle", "git", "maxhs", "ilk_anahtar_zarf", "typo", "oda", "karar"]
MAK = ["soz_eylem_uyum", "soz_eylem_celiski_payi", "hedef_uyum", "soz_sonuc_uyum", "soz_defter_uyum", "aciklama_uzunluk", "birinci_tekil", "gerekce_sayisi",
       "aciklama_cesitlilik", "aciklamasiz_pay"]
eksik = {f: sum(1 for x in X0 if x[f] is None) for f in MAK}
ort = {f: sum(x[f] for x in X0 if x[f] is not None) / max(1, sum(1 for x in X0 if x[f] is not None)) for f in MAK}
X = [dict(x["hareket"], **{f: (x[f] if x[f] is not None else ort[f]) for f in MAK}) for x in X0]; y = [x["sinif"] for x in X0]; N = len(y); cl = collections.Counter(y)


def ent(ls):
    c = collections.Counter(ls); n = len(ls); return -sum(v / n * math.log2(v / n) for v in c.values())


def mi(f, kutu=5):
    v = sorted(range(N), key=lambda i: X[i][f]); b = [0] * N
    for r, i in enumerate(v):
        b[i] = min(kutu - 1, r * kutu // N)
    g = collections.defaultdict(list)
    for i in range(N):
        g[b[i]].append(y[i])
    return ent(y) - sum(len(t) / N * ent(t) for t in g.values())


def knn(feats, idx_alt=None, siniflar=("G", "D", "U")):
    I = idx_alt if idx_alt is not None else list(range(N)); n = len(I); yy = [y[i] for i in I]; c = collections.Counter(yy)
    mu = {f: sum(X[i][f] for i in I) / n for f in feats}; sd = {f: (sum((X[i][f] - mu[f]) ** 2 for i in I) / n) ** .5 or 1 for f in feats}
    Z = [[(X[i][f] - mu[f]) / sd[f] for f in feats] for i in I]
    idx = list(range(n)); random.Random(0).shuffle(idx); kat = [idx[k::5] for k in range(5)]; w = {s: n / (len(c) * v) for s, v in c.items()}
    pred = [None] * n; skor = [None] * n
    for t in range(5):
        test = set(kat[t]); tr = [i for i in idx if i not in test]
        for i in test:
            d = sorted((sum((a - b) ** 2 for a, b in zip(Z[i], Z[j])), j) for j in tr)[:7]; oy = collections.Counter()
            for _, j in d:
                oy[yy[j]] += w[yy[j]]
            pred[i] = oy.most_common(1)[0][0]; skor[i] = oy["U"] / sum(oy.values())
    R = {"dogruluk": sum(p == t for p, t in zip(pred, yy)) / n, "cogunluk_taban": max(c.values()) / n}
    for s in siniflar:
        m = [i for i in range(n) if yy[i] == s]; R["yakala_" + s] = sum(pred[i] == s for i in m) / len(m) if m else None
    return R, skor, yy


def auc(P, Q):
    return sum(1.0 if p > q else .5 if p == q else 0.0 for p in P for q in Q) / (len(P) * len(Q))


def boot(P, Q, n=1000):
    r = random.Random(7); v = sorted(auc([r.choice(P) for _ in P], [r.choice(Q) for _ in Q]) for _ in range(n)); return (round(v[25], 3), round(v[974], 3))


J = {"ajan_kosu": N, "etkin_n": dict(cl), "yinelenen_atlanan": B["yinelenen_atlanan"], "belirsiz_oran": B["belirsiz_oran"], "eksik_doldurulan": eksik}
na = sum(x["karar"] for x in X0); acsiz = sum(round(x["aciklamasiz_pay"] * x["karar"]) for x in X0)
J["soz_eylem_belirsiz_aciklamali_kararda"] = (B["sayac"]["eylem_belirsiz"] - acsiz + B["sayac"].get("uyari_eylem_belirsiz", 0)) / (na - acsiz)
J["aciklamasiz_karar_payi"] = acsiz / na
J["profil"] = {s: {f: round(sum(X[i][f] for i in range(N) if y[i] == s) / cl[s], 3) for f in HAR + MAK} for s in ("G", "D", "U")}
J["bilgi_kazanci_bit"] = {"H": round(ent(y), 3), **{f: round(mi(f), 3) for f in HAR + MAK}}
J["knn_uclu"] = {ad: knn(F)[0] for ad, F in (("hareket", HAR), ("makas", MAK), ("hareket+makas", HAR + MAK))}
UG = [i for i in range(N) if y[i] in "UG"]
J["ug_tek_ozellik_auc"] = {}
for f in HAR + MAK:
    a = auc([X[i][f] for i in UG if y[i] == "U"], [X[i][f] for i in UG if y[i] == "G"])
    J["ug_tek_ozellik_auc"][f] = {"auc_yuksek_U": round(a, 3), "ayirma": round(max(a, 1 - a), 3), "yon": "yüksek→U" if a >= .5 else "düşük→U"}
J["ug_knn"] = {}
for ad, F in (("hareket", HAR), ("makas", MAK), ("hareket+makas", HAR + MAK)):
    R, sk, yy = knn(F, UG, ("G", "U")); P = [s for s, t in zip(sk, yy) if t == "U"]; Q = [s for s, t in zip(sk, yy) if t == "G"]
    J["ug_knn"][ad] = dict(R, auc=round(auc(P, Q), 3), bootstrap_95=boot(P, Q))
# karistirici denetimi: G'nin bir kismi D'li kosularda (D'nin davranisi G'yi degistirebilir) -> yalniz U'lu kosulardaki G ile
kosu_U = {(x["klasor"], x["kosu_id"]) for x in X0 if x["sinif"] == "U"}
UG2 = [i for i in range(N) if y[i] == "U" or (y[i] == "G" and (X0[i]["klasor"], X0[i]["kosu_id"]) in kosu_U)]
J["ug_knn_ayni_kosu_turu"] = {"not": "G yalniz U'lu kosulardan (D'li kosu G'leri disarida)", "U": sum(1 for i in UG2 if y[i] == "U"), "G": sum(1 for i in UG2 if y[i] == "G")}
for ad, F in (("hareket", HAR), ("makas", MAK), ("hareket+makas", HAR + MAK)):
    R, sk, yy = knn(F, UG2, ("G", "U")); P = [s for s, t in zip(sk, yy) if t == "U"]; Q = [s for s, t in zip(sk, yy) if t == "G"]
    J["ug_knn_ayni_kosu_turu"][ad] = dict(R, auc=round(auc(P, Q), 3), bootstrap_95=boot(P, Q))
J["ug_tek_ozellik_auc_ayni_kosu_turu"] = {f: round(auc([X[i][f] for i in UG2 if y[i] == "U"], [X[i][f] for i in UG2 if y[i] == "G"]), 3) for f in HAR + MAK}
J["taban"] = {"karar_sayisi_auc_bu_evren": J["ug_tek_ozellik_auc"]["karar"]["auc_yuksek_U"], "karar_sayisi_auc_kosu_vakalari": .525}
json.dump(J, open(CIK + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
f3 = lambda v: "-" if v is None else "%.3f" % v
md = ["# Yalan makinesi (söz-eylem makası) · %d ajan-koşu · etkin n %s · yinelenen dizi atlanan %d" % (N, dict(cl), B["yinelenen_atlanan"]), "",
      "Belirsiz: söz-eylem %.3f (açıklamalı kararlarda %.3f; açıklamasız karar payı %.3f) · söz-sonuç %.3f · söz-defter %.3f (bu ikisi yalnız iddia olan kararlarda uygulanır)"
      % (B["belirsiz_oran"]["soz_eylem"], J["soz_eylem_belirsiz_aciklamali_kararda"], J["aciklamasiz_karar_payi"], B["belirsiz_oran"]["soz_sonuc"], B["belirsiz_oran"]["soz_defter"]), "",
      "## Sınıf profili", "", "| özellik | G | D | U | bilgi kazancı (bit) | U-G AUC (yön) |", "|---|---|---|---|---|---|"]
for f in HAR + MAK:
    t = J["ug_tek_ozellik_auc"][f]
    md.append("| %s | %s | %s | %s | %.3f | %.3f (%s) |" % (f, J["profil"]["G"][f], J["profil"]["D"][f], J["profil"]["U"][f], J["bilgi_kazanci_bit"][f], t["auc_yuksek_U"], t["yon"]))
md += ["", "Etiket belirsizliği H = %.3f bit. Eksik oran (o makasta iddia yok) ortalamayla dolduruldu: %s" % (J["bilgi_kazanci_bit"]["H"], eksik), "",
       "## k-NN(7) 5 kat · üçlü", "", "| özellikler | doğruluk | çoğunluk | G | D | U |", "|---|---|---|---|---|---|"]
for ad, R in J["knn_uclu"].items():
    md.append("| %s | %.3f | %.3f | %s | %s | %s |" % (ad, R["dogruluk"], R["cogunluk_taban"], f3(R["yakala_G"]), f3(R["yakala_D"]), f3(R["yakala_U"])))
md += ["", "## U-G ikili (etkin n U %d / G %d)" % (cl["U"], cl["G"]), "", "| özellikler | AUC | %95 | doğruluk | U yakalama | G yakalama | taban (karar sayısı) |", "|---|---|---|---|---|---|---|"]
for ad, R in J["ug_knn"].items():
    md.append("| k-NN %s | %.3f | %s | %.3f | %s | %s | %.3f bu evren / .525 koşu vakaları |" % (ad, R["auc"], R["bootstrap_95"], R["dogruluk"], f3(R["yakala_U"]), f3(R["yakala_G"]), J["taban"]["karar_sayisi_auc_bu_evren"]))
K2 = J["ug_knn_ayni_kosu_turu"]
md += ["", "## Karıştırıcı denetimi · U-G ikili, G yalnız U'lu koşulardan (U %d / G %d)" % (K2["U"], K2["G"]), "", "| özellikler | AUC | %95 | U yakalama | G yakalama |", "|---|---|---|---|---|"]
for ad in ("hareket", "makas", "hareket+makas"):
    R = K2[ad]; md.append("| k-NN %s | %.3f | %s | %s | %s |" % (ad, R["auc"], R["bootstrap_95"], f3(R["yakala_U"]), f3(R["yakala_G"])))
md += ["", "Tek özellik U-G AUC (aynı koşu türü): " + ", ".join("%s %.3f" % (f, v) for f, v in J["ug_tek_ozellik_auc_ayni_kosu_turu"].items())]
md += ["", "Sözlük kuralları: makas_karar_sayim.json 'kurallar' (v2: ASCII katlama; v1 sonucu makas_*_v1.*)."]
open(CIK + ".md", "w", encoding="utf-8").write("\n".join(md) + "\n"); print("\n".join(md))

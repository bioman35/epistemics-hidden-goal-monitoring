# coding: utf-8
"""DONDURMA 12 Kas (Hikayeci, danisman is emri). epistemics/ ve oyun_alani_v4/ git deposu degil; onun yerine:
1) DONDURMA_12KAS.sha256  : sha256sum bicimi ("<sha>  <yol>"), `sha256sum -c DONDURMA_12KAS.sha256` ile denetlenir (4 Kas dondurmasiyla ayni bicim).
2) DONDURMA_12KAS.tsv     : yol, bayt, sha256, degisim zamani (UTC).
3) 4 Kas dondurmasiyla karsilastirma: DONDURMA_4KAS.sha256'daki her dosya bugun ayni mi, degisti mi, yok mu (PREEXISTING dokunulmadi kaniti degil, olcumu).
Disarida: __pycache__, *.pyc, canli yazilan sunucu gunlugu (ollama_serve*.log), bu betigin kendi ciktilari.
  python -I dondurma_12kas.py --kuru   (sayar, karsilastirir, HICBIR SEY YAZMAZ)
  python -I dondurma_12kas.py --yaz    (yalniz "dondur" sozuyle; manifest + tsv + zip anlik goruntu)"""
import datetime, hashlib, os, sys

SPRINT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KOKLER = ["epistemics", "oyun_alani_v4"]
CIKTI = {"DONDURMA_12KAS.sha256", "DONDURMA_12KAS.tsv", "DONDURMA_12KAS_kod_sonuc.zip"}
README = os.path.join(SPRINT, "epistemics", "README.md")   # manifest sha'sini tasir, manifest disinda (yalniz bu yol)


def dis(yol):
    a = os.path.basename(yol)
    return os.path.abspath(yol) == os.path.abspath(README) or "__pycache__" in yol.split(os.sep) or a.endswith(".pyc") or (a.startswith("ollama_serve") and a.endswith(".log")) or a in CIKTI


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def tara():
    S = []
    for k in KOKLER:
        for d, _, fs in os.walk(os.path.join(SPRINT, k)):
            for f in sorted(fs):
                p = os.path.join(d, f); r = os.path.relpath(p, SPRINT).replace(os.sep, "/")
                if dis(p): continue
                st = os.stat(p); S.append((r, st.st_size, sha(p), datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")))
    return sorted(S)


def karsilastir(S):
    eski = {}; p = os.path.join(SPRINT, "oyun_alani_v4", "DONDURMA_4KAS.sha256")
    for ln in open(p, encoding="utf-8"):
        if ln.strip(): h, y = ln.rstrip("\n").split("  ", 1); eski[y] = h
    simdi = {r: h for r, _, h, _ in S}
    for y in eski:   # iki kokun disindaki 4 Kas dosyalari (film_labirent/, oyun_alani_v3/) diskte dogrudan denetlenir
        if y not in simdi and os.path.exists(os.path.join(SPRINT, y)): simdi[y] = sha(os.path.join(SPRINT, y))
    ayni = sum(1 for y, h in eski.items() if simdi.get(y) == h); deg = [y for y, h in eski.items() if y in simdi and simdi[y] != h]; yok = [y for y in eski if y not in simdi]
    return len(eski), ayni, deg, yok


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    S = tara(); n, ayni, deg, yok = karsilastir(S)
    print("dosya %d · bayt %.1f MB" % (len(S), sum(b for _, b, _, _ in S) / 1e6))
    for k in KOKLER: print("  %s: %d dosya" % (k, sum(1 for r, *_ in S if r.startswith(k + "/"))))
    print("4 Kas dondurmasi: %d dosya · ayni %d · degismis %d · yok %d" % (n, ayni, len(deg), len(yok)))
    for y in deg[:15]: print("  DEGISMIS", y)
    for y in yok[:15]: print("  YOK", y)
    if "--yaz" in sys.argv:
        a = os.path.join(SPRINT, "epistemics", "DONDURMA_12KAS.sha256"); b = os.path.join(SPRINT, "epistemics", "DONDURMA_12KAS.tsv")
        with open(a, "w", encoding="utf-8", newline="\n") as f:
            for r, _, h, _ in S: f.write("%s  %s\n" % (h, r))
        with open(b, "w", encoding="utf-8", newline="\n") as f:
            f.write("yol\tbayt\tsha256\tdegisim_utc\n")
            for r, by, h, m in S: f.write("%s\t%d\t%s\t%s\n" % (r, by, h, m))
        print("YAZILDI", a, "sha256", sha(a)); print("YAZILDI", b, "sha256", sha(b))
        import zipfile   # anlik goruntu: betik + sonuc dosyalari; kosular/, oynat/ ve gizli*/*.npy disarida (danisman kabulu 12 Kas)
        z = os.path.join(SPRINT, "epistemics", "DONDURMA_12KAS_kod_sonuc.zip"); n = 0
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for r, *_ in S:
                parca = r.split("/")
                if "kosular" in parca or "oynat" in parca or (any(p.startswith("gizli") for p in parca[:-1]) and r.endswith(".npy")): continue   # oynat/ kosular/dan yeniden uretilir, manifestte sha ile var
                zf.write(os.path.join(SPRINT, r), r); n += 1
        print("YAZILDI", z, n, "dosya", "%.1f MB" % (os.path.getsize(z) / 1e6), "sha256", sha(z))
    else:
        print("kuru kip: hicbir sey yazilmadi")


if __name__ == "__main__":
    main()
